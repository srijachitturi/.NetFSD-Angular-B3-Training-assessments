function renderCartPage() {
  const cart = getCart();

  if (cart.length === 0) {
    $("#cartItemsContainer").html(`
      <div class="empty-state">
        <h3 class="fw-bold mb-2">Your cart is empty</h3>
        <p class="text-muted">Add products and they will appear here.</p>
        <a href="products.html" class="btn btn-dark mt-2">Browse Products</a>
      </div>
    `);
    $("#summaryItems").text("0");
    $("#summaryAmount").text("₹0");
    $("#checkoutLink").addClass("disabled");
    return;
  }

  let totalItems = 0;

  const html = cart.map(function(item) {
    totalItems += item.quantity;

    return `
      <div class="cart-card mb-3">
        <div class="row align-items-center g-3">
          <div class="col-md-2">
            <img src="${item.image}" alt="${item.name}" class="cart-img">
          </div>
          <div class="col-md-4">
            <h5 class="fw-bold mb-1">${item.name}</h5>
            <div class="text-muted">${formatPrice(item.price)} each</div>
          </div>
          <div class="col-md-3">
            <div class="qty-controls">
              <button class="qty-btn" data-id="${item.id}" data-change="-1">-</button>
              <strong>${item.quantity}</strong>
              <button class="qty-btn" data-id="${item.id}" data-change="1">+</button>
            </div>
          </div>
          <div class="col-md-3 text-md-end">
            <div class="fw-bold mb-2">${formatPrice(item.price * item.quantity)}</div>
            <button class="btn btn-danger btn-sm remove-btn" data-id="${item.id}">Remove</button>
          </div>
        </div>
      </div>
    `;
  }).join("");

  $("#cartItemsContainer").html(html);
  $("#summaryItems").text(totalItems);
  $("#summaryAmount").text(formatPrice(getCartTotal()));
  $("#checkoutLink").removeClass("disabled");

  $(".remove-btn").on("click", function() {
    removeFromCart(Number($(this).data("id")));
    renderCartPage();
  });

  $(".qty-btn").on("click", function() {
    updateCartQuantity(Number($(this).data("id")), Number($(this).data("change")));
    renderCartPage();
  });
}

$(function() {
  renderCartPage();
});