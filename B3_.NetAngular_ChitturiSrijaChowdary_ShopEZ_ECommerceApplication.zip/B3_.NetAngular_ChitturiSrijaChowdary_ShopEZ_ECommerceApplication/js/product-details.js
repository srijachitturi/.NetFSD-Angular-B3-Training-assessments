$(async function() {
  const params = new URLSearchParams(window.location.search);
  const id = Number(params.get("id"));
  const product = await getProductById(id);

  if (!product) {
    $("#productDetailsContainer").html(`
      <div class="empty-state">
        <h3 class="fw-bold">Product not found</h3>
        <a href="products.html" class="btn btn-dark mt-3">Back to Products</a>
      </div>
    `);
    return;
  }

  const html = `
    <div class="row g-4 align-items-stretch">
      <div class="col-lg-6">
        <img src="${product.image}" alt="${product.name}" class="details-image">
      </div>
      <div class="col-lg-6">
        <div class="details-panel">
          <div class="product-category">${product.category}</div>
          <h2 class="fw-bold mb-3">${product.name}</h2>
          ${getStockBadge(product.stock)}
          <div class="details-price mt-3">${formatPrice(product.price)}</div>
          <p class="details-text mt-3">${product.description}</p>
          <div class="mt-4 d-flex gap-2 flex-wrap">
            <button id="detailAddBtn" class="btn btn-dark px-4" ${product.stock === 0 ? "disabled" : ""}>Add to Cart</button>
            <a href="products.html" class="btn btn-outline-dark px-4">Back to Products</a>
          </div>
        </div>
      </div>
    </div>
  `;

  $("#productDetailsContainer").html(html);

  $("#detailAddBtn").on("click", function() {
    addToCart(product);
  });
});