const PRODUCTS_FILE = "./json/products.json";
const PRODUCTS_STORAGE_KEY = "shopez_products";

async function getProducts() {
  const localProducts = getLocalProducts();

  if (localProducts.length > 0) {
    return localProducts;
  }

  try {
    const response = await fetch(PRODUCTS_FILE);
    if (!response.ok) {
      throw new Error("Failed to load products.");
    }

    const products = await response.json();

    if (!getLocalProducts().length) {
      saveProducts(products);
    }

    return products;
  } catch (error) {
    console.error(error);
    return [];
  }
}

function getLocalProducts() {
  const raw = localStorage.getItem(PRODUCTS_STORAGE_KEY);
  return raw ? JSON.parse(raw) : [];
}

function saveProducts(products) {
  localStorage.setItem(PRODUCTS_STORAGE_KEY, JSON.stringify(products));
}

function generateProductId(products) {
  if (!products.length) return 1;
  return Math.max.apply(null, products.map(function(product) {
    return Number(product.id) || 0;
  })) + 1;
}

async function getProductById(id) {
  const products = await getProducts();
  return products.find(function(product) {
    return product.id === id;
  });
}

function formatPrice(price) {
  return "₹" + Number(price).toLocaleString("en-IN");
}

function getStockBadge(stock) {
  if (stock === 0) {
    return '<span class="stock-badge out-stock">Out of Stock</span>';
  }
  if (stock <= 3) {
    return '<span class="stock-badge low-stock">Only ' + stock + ' left</span>';
  }
  return '<span class="stock-badge in-stock">In Stock</span>';
}

function createProductCard(product) {
  return `
    <div class="col-md-6 col-lg-4">
      <div class="product-card">
        <img src="${product.image}" alt="${product.name}" class="product-img">
        <div class="product-body">
          <div class="product-category">${product.category}</div>
          <h5 class="product-name">${product.name}</h5>
          ${getStockBadge(product.stock)}
          <div class="product-price mt-3">${formatPrice(product.price)}</div>
          <div class="d-flex gap-2 flex-wrap">
            <a href="product-details.html?id=${product.id}" class="btn btn-outline-dark">View Details</a>
            <button class="btn btn-dark add-to-cart-btn" data-id="${product.id}" ${product.stock === 0 ? "disabled" : ""}>
              Add to Cart
            </button>
          </div>
        </div>
      </div>
    </div>
  `;
}
