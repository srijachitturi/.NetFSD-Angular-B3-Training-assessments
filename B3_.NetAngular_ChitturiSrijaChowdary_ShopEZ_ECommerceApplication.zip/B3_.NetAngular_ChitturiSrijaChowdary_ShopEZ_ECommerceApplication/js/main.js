$(async function() {
  const products = await getProducts();

  const featured = products.slice(0, 6);
  $("#featuredProducts").html(featured.map(createProductCard).join(""));

  const categoryIcons = {
    Electronics: "🎧",
    Accessories: "🧩",
    Drinkware: "🥤",
    Stationery: "📝",
    Lighting: "💡",
    Home: "🏠",
    Decor: "✨",
    Comfort: "🛋️"
  };

  const categoryMap = {};

  products.forEach(function(product) {
    categoryMap[product.category] = (categoryMap[product.category] || 0) + 1;
  });

  const categoryHtml = Object.keys(categoryMap).map(function(category) {
    return `
      <div class="col-md-6 col-lg-3">
        <div class="category-card">
          <div class="category-icon">${categoryIcons[category] || "🛍️"}</div>
          <h5 class="fw-bold">${category}</h5>
          <p class="text-muted mb-0">${categoryMap[category]} products available</p>
        </div>
      </div>
    `;
  }).join("");

  $("#categoryHighlights").html(categoryHtml);

  $(document).on("click", ".add-to-cart-btn", async function() {
    const id = Number($(this).data("id"));
    const product = await getProductById(id);
    addToCart(product);
  });
});