const CART_KEY = "shopez_cart";

function getCart() {
  const raw = localStorage.getItem(CART_KEY);
  return raw ? JSON.parse(raw) : [];
}

function saveCart(cart) {
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
  updateCartCount();
}

function updateCartCount() {
  const total = getCart().reduce(function(sum, item) {
    return sum + item.quantity;
  }, 0);
  $("#cartCount").text(total);
}

function addToCart(product) {
  if (!product || product.stock === 0) {
    alert("This product is out of stock.");
    return;
  }

  const cart = getCart();
  const existing = cart.find(function(item) {
    return item.id === product.id;
  });

  if (existing) {
    if (existing.quantity >= product.stock) {
      alert("Maximum available stock reached.");
      return;
    }
    existing.quantity += 1;
  } else {
    cart.push({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      stock: product.stock,
      quantity: 1
    });
  }

  saveCart(cart);
  alert(product.name + " added to cart.");
}

function removeFromCart(productId) {
  const filtered = getCart().filter(function(item) {
    return item.id !== productId;
  });
  saveCart(filtered);
}

function updateCartQuantity(productId, change) {
  const cart = getCart();
  const item = cart.find(function(product) {
    return product.id === productId;
  });

  if (!item) return;

  const newQuantity = item.quantity + change;

  if (newQuantity <= 0) {
    removeFromCart(productId);
    return;
  }

  if (newQuantity > item.stock) {
    alert("Cannot exceed available stock.");
    return;
  }

  item.quantity = newQuantity;
  saveCart(cart);
}

function getCartTotal() {
  return getCart().reduce(function(total, item) {
    return total + (item.price * item.quantity);
  }, 0);
}

function clearCart() {
  localStorage.removeItem(CART_KEY);
  updateCartCount();
}

$(function() {
  updateCartCount();
});