let deleteProductId = null;
let deleteModal = null;

function showAdminMessage(message, type) {
  $("#adminMessage").html('<div class="alert alert-' + type + '">' + message + "</div>");
}

function resetAdminForm() {
  $("#productId").val("");
  $("#productName").val("");
  $("#productCategory").val("");
  $("#productPrice").val("");
  $("#productStock").val("");
  $("#productImage").val("");
  $("#productDescription").val("");
  $("#formTitle").text("Add Product");
  $("#cancelEditBtn").hide();
}

function fillAdminForm(product) {
  $("#productId").val(product.id);
  $("#productName").val(product.name);
  $("#productCategory").val(product.category);
  $("#productPrice").val(product.price);
  $("#productStock").val(product.stock);
  $("#productImage").val(product.image);
  $("#productDescription").val(product.description);
  $("#formTitle").text("Edit Product");
  $("#cancelEditBtn").show();
  window.scrollTo({ top: 0, behavior: "smooth" });
}

async function renderAdminProducts() {
  const products = await getProducts();
  const search = $("#adminSearchInput").val().trim().toLowerCase();

  const filtered = products.filter(function(product) {
    return product.name.toLowerCase().includes(search) ||
           product.category.toLowerCase().includes(search);
  });

  $("#adminProductCount").text(products.length);

  if (!filtered.length) {
    $("#adminProductsTableWrap").html('<div class="empty-state"><h5 class="fw-bold mb-2">No products found</h5><p class="text-muted mb-0">Try another search or add a new product.</p></div>');
    return;
  }

  const rows = filtered.map(function(product) {
    return `
      <tr>
        <td>${product.id}</td>
        <td>
          <div class="admin-product-cell">
            <img src="${product.image}" alt="${product.name}" class="admin-thumb">
            <div>
              <div class="fw-bold">${product.name}</div>
              <small class="text-muted">${product.category}</small>
            </div>
          </div>
        </td>
        <td>${formatPrice(product.price)}</td>
        <td>${product.stock}</td>
        <td class="text-nowrap">
          <button class="btn btn-outline-dark btn-sm edit-product-btn" data-id="${product.id}">Edit</button>
          <button class="btn btn-danger btn-sm delete-product-btn" data-id="${product.id}">Delete</button>
        </td>
      </tr>
    `;
  }).join("");

  $("#adminProductsTableWrap").html(`
    <table class="table align-middle admin-table">
      <thead>
        <tr>
          <th>ID</th>
          <th>Product</th>
          <th>Price</th>
          <th>Stock</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>${rows}</tbody>
    </table>
  `);
}

async function saveAdminProduct(event) {
  event.preventDefault();

  const id = Number($("#productId").val());
  const name = $("#productName").val().trim();
  const category = $("#productCategory").val().trim();
  const price = Number($("#productPrice").val());
  const stock = Number($("#productStock").val());
  const image = $("#productImage").val().trim();
  const description = $("#productDescription").val().trim();

  if (!name || !category || !image || !description || isNaN(price) || isNaN(stock) || price < 0 || stock < 0) {
    showAdminMessage("Please enter valid product details in all fields.", "danger");
    return;
  }

  const products = await getProducts();

  if (id) {
    const index = products.findIndex(function(product) {
      return product.id === id;
    });

    if (index === -1) {
      showAdminMessage("Product not found for editing.", "danger");
      return;
    }

    products[index] = {
      id: id,
      name: name,
      category: category,
      price: price,
      stock: stock,
      image: image,
      description: description
    };

    saveProducts(products);
    showAdminMessage("Product updated successfully.", "success");
  } else {
    products.push({
      id: generateProductId(products),
      name: name,
      category: category,
      price: price,
      stock: stock,
      image: image,
      description: description
    });

    saveProducts(products);
    showAdminMessage("Product added successfully.", "success");
  }

  resetAdminForm();
  renderAdminProducts();
}

async function deleteAdminProduct(productId) {
  const products = await getProducts();
  const updated = products.filter(function(product) {
    return product.id !== productId;
  });

  saveProducts(updated);

  const cart = getCart().filter(function(item) {
    return item.id !== productId;
  });
  saveCart(cart);

  showAdminMessage("Product deleted successfully.", "success");
  renderAdminProducts();
}

async function editAdminProduct(productId) {
  const product = await getProductById(productId);
  if (!product) {
    showAdminMessage("Product not found.", "danger");
    return;
  }
  fillAdminForm(product);
}

async function resetDefaultProducts() {
  localStorage.removeItem(PRODUCTS_STORAGE_KEY);
  const cart = getCart().filter(function(item) {
    return item && item.id;
  });
  saveCart(cart);
  resetAdminForm();
  showAdminMessage("Default JSON products restored successfully.", "success");
  renderAdminProducts();
}

$(async function() {
  $("#cancelEditBtn").hide();
  deleteModal = new bootstrap.Modal(document.getElementById("deleteConfirmModal"));
  await getProducts();
  renderAdminProducts();

  $("#adminProductForm").on("submit", saveAdminProduct);

  $("#cancelEditBtn").on("click", function() {
    resetAdminForm();
    $("#adminMessage").html("");
  });

  $("#adminSearchInput").on("input", function() {
    renderAdminProducts();
  });

  $("#resetProductsBtn").on("click", function() {
    resetDefaultProducts();
  });

  $(document).on("click", ".edit-product-btn", function() {
    editAdminProduct(Number($(this).data("id")));
  });

  $(document).on("click", ".delete-product-btn", function() {
    deleteProductId = Number($(this).data("id"));
    deleteModal.show();
  });

  $("#confirmDeleteBtn").on("click", function() {
    if (deleteProductId !== null) {
      deleteAdminProduct(deleteProductId);
      deleteProductId = null;
      deleteModal.hide();
    }
  });
});
