let allProducts = [];

function populateCategoryFilter(products) {
  const categories = Array.from(
    new Set(
      products.map(function(product) {
        return product.category.trim();
      })
    )
  ).sort(function(a, b) {
    return a.localeCompare(b);
  });

  const options = categories.map(function(category) {
    return `<option value="${category}">${category}</option>`;
  }).join("");

  $("#categoryFilter").html(`
    <option value="all">All Categories</option>
    ${options}
  `);
}

function getFilteredProducts() {
  const search = $("#productSearchInput").val().trim().toLowerCase();
  const selectedCategory = $("#categoryFilter").val().trim().toLowerCase();
  const sort = $("#sortFilter").val();

  let filtered = allProducts.filter(function(product) {
    const productName = product.name.trim().toLowerCase();
    const productCategory = product.category.trim().toLowerCase();

    const matchesSearch =
      productName.includes(search) || productCategory.includes(search);

    const matchesCategory =
      selectedCategory === "all" || productCategory === selectedCategory;

    return matchesSearch && matchesCategory;
  });

  if (sort === "price-low") {
    filtered.sort(function(a, b) {
      return a.price - b.price;
    });
  } else if (sort === "price-high") {
    filtered.sort(function(a, b) {
      return b.price - a.price;
    });
  } else if (sort === "name-asc") {
    filtered.sort(function(a, b) {
      return a.name.localeCompare(b.name);
    });
  } else if (sort === "name-desc") {
    filtered.sort(function(a, b) {
      return b.name.localeCompare(a.name);
    });
  }

  return filtered;
}

function renderProducts() {
  const filteredProducts = getFilteredProducts();

  if (!filteredProducts.length) {
    $("#productsContainer").html(`
      <div class="col-12">
        <div class="empty-state">
          <h3 class="fw-bold mb-2">No products found</h3>
          <p class="text-muted mb-0">Try another search, category, or sort option.</p>
        </div>
      </div>
    `);
    return;
  }

  $("#productsContainer").html(filteredProducts.map(createProductCard).join(""));
}

$(async function() {
  allProducts = await getProducts();

  populateCategoryFilter(allProducts);
  renderProducts();

  $("#productSearchInput, #categoryFilter, #sortFilter").on("input change", function() {
    renderProducts();
  });

  $(document).on("click", ".add-to-cart-btn", async function() {
    const id = Number($(this).data("id"));
    const product = await getProductById(id);
    addToCart(product);
  });
});
