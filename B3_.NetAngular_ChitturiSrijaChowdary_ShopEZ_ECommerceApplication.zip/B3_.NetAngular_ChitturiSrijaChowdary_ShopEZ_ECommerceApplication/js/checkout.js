const ORDERS_KEY = "shopez_orders";

function getOrders() {
  const raw = localStorage.getItem(ORDERS_KEY);
  return raw ? JSON.parse(raw) : [];
}

function saveOrders(orders) {
  localStorage.setItem(ORDERS_KEY, JSON.stringify(orders));
}

function renderCheckoutSummary() {
  const cart = getCart();

  if (cart.length === 0) {
    $("#checkoutSummary").html('<p class="text-muted mb-0">No items in order summary.</p>');
    $("#checkoutTotal").text("₹0");
    return;
  }

  const html = cart.map(function(item) {
    return `
      <div class="order-line">
        <span>${item.name} x ${item.quantity}</span>
        <strong>${formatPrice(item.price * item.quantity)}</strong>
      </div>
    `;
  }).join("");

  $("#checkoutSummary").html(html);
  $("#checkoutTotal").text(formatPrice(getCartTotal()));
}

function renderOrderHistory() {
  const orders = getOrders();

  if (!orders.length) {
    $("#orderHistoryContainer").html('<p class="text-muted mb-0">No orders placed yet.</p>');
    return;
  }

  const html = orders.slice().reverse().map(function(order) {
    return `
      <div class="order-history-item">
        <div class="d-flex justify-content-between align-items-start gap-2 mb-2 flex-wrap">
          <strong>${order.orderId}</strong>
          <span class="text-muted small">${order.date}</span>
        </div>
        <div class="small text-muted mb-2">${order.name} • ${order.email}</div>
        <div class="small mb-2">${order.items.map(function(item) { return item.name + ' x ' + item.quantity; }).join(', ')}</div>
        <div class="fw-bold">${formatPrice(order.total)}</div>
      </div>
    `;
  }).join("");

  $("#orderHistoryContainer").html(html);
}

function markFieldValidity(element, isValid) {
  $(element).toggleClass("is-invalid", !isValid);
  $(element).toggleClass("is-valid", isValid);
}

function validateCheckoutForm() {
  const name = $("#customerName").val().trim();
  const email = $("#customerEmail").val().trim();
  const address = $("#customerAddress").val().trim();

  const nameValid = /^[A-Za-z ]{3,}$/.test(name);
  const emailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  const addressValid = address.length >= 10;

  markFieldValidity("#customerName", nameValid);
  markFieldValidity("#customerEmail", emailValid);
  markFieldValidity("#customerAddress", addressValid);

  return nameValid && emailValid && addressValid;
}

$(function() {
  renderCheckoutSummary();
  renderOrderHistory();

  $("#customerName, #customerEmail, #customerAddress").on("input", function() {
    validateCheckoutForm();
  });

  $("#checkoutForm").on("submit", function(event) {
    event.preventDefault();

    const cart = getCart();
    const name = $("#customerName").val().trim();
    const email = $("#customerEmail").val().trim();
    const address = $("#customerAddress").val().trim();

    if (cart.length === 0) {
      $("#checkoutMessage").html('<div class="alert alert-danger">Your cart is empty.</div>');
      return;
    }

    if (!validateCheckoutForm()) {
      $("#checkoutMessage").html('<div class="alert alert-danger">Please correct the highlighted fields before placing the order.</div>');
      return;
    }

    const orders = getOrders();
    orders.push({
      orderId: "ORD" + Date.now(),
      date: new Date().toLocaleString("en-IN"),
      name: name,
      email: email,
      address: address,
      items: cart,
      total: getCartTotal()
    });
    saveOrders(orders);

    $("#checkoutMessage").html('<div class="alert alert-success">Your order has been placed successfully. Thank you for shopping with ShopEZ.</div>');
    clearCart();
    renderCheckoutSummary();
    renderOrderHistory();
    this.reset();
    $(".form-control").removeClass("is-valid is-invalid");
  });
});
