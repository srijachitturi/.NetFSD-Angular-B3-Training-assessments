﻿using ShopEZ.Api.Models;

namespace ShopEZ.Api.Repositories.Interfaces
{
    public interface IOrderRepository
    {
        Task<User?> GetUserByIdAsync(int userId);
        Task<List<Product>> GetProductsByIdsAsync(List<int> productIds);
        Task<List<Order>> GetAllAsync();
        Task<Order?> GetByIdAsync(int id);
        Task AddAsync(Order order);
        Task SaveChangesAsync();
    }
}
