﻿using ShopEZ.Api.DTOs;
using ShopEZ.Api.Exceptions;
using ShopEZ.Api.Models;
using ShopEZ.Api.Repositories.Interfaces;
using ShopEZ.Api.Services.Interfaces;

namespace ShopEZ.Api.Services
{
    public class OrderService : IOrderService
    {
        private readonly IOrderRepository _orderRepository;

        public OrderService(IOrderRepository orderRepository)
        {
            _orderRepository = orderRepository;
        }

        public async Task<OrderReadDto> CreateOrderAsync(int userId, CreateOrderDto dto)
        {
            if (dto.Items == null || dto.Items.Count == 0)
                throw new BadRequestException("Cart cannot be empty.");

            var user = await _orderRepository.GetUserByIdAsync(userId);
            if (user == null)
                throw new NotFoundException($"User with ID {userId} not found.");

            var productIds = dto.Items.Select(i => i.ProductId).Distinct().ToList();
            var products = await _orderRepository.GetProductsByIdsAsync(productIds);

            if (products.Count != productIds.Count)
                throw new BadRequestException("One or more products do not exist.");

            foreach (var item in dto.Items)
            {
                if (item.Quantity <= 0)
                    throw new BadRequestException($"Quantity for product ID {item.ProductId} must be greater than zero.");
            }

            foreach (var item in dto.Items)
            {
                var product = products.First(p => p.ProductId == item.ProductId);

                if (item.Quantity > product.Stock)
                    throw new BadRequestException($"Insufficient stock for product '{product.Name}'. Available stock: {product.Stock}.");
            }

            var orderItems = new List<OrderItem>();

            foreach (var item in dto.Items)
            {
                var product = products.First(p => p.ProductId == item.ProductId);

                orderItems.Add(new OrderItem
                {
                    ProductId = product.ProductId,
                    Quantity = item.Quantity,
                    Price = product.Price
                });

                product.Stock -= item.Quantity;
            }

            decimal totalAmount = orderItems.Sum(x => x.Price * x.Quantity);

            var order = new Order
            {
                UserId = userId,
                OrderDate = DateTime.UtcNow,
                TotalAmount = totalAmount,
                OrderItems = orderItems
            };

            await _orderRepository.AddAsync(order);
            await _orderRepository.SaveChangesAsync();

            var savedOrder = await _orderRepository.GetByIdAsync(order.OrderId);

            if (savedOrder == null)
                throw new NotFoundException("Order could not be loaded after creation.");

            return new OrderReadDto
            {
                OrderId = savedOrder.OrderId,
                UserId = savedOrder.UserId,
                CustomerName = savedOrder.User?.Name ?? string.Empty,
                OrderDate = savedOrder.OrderDate,
                TotalAmount = savedOrder.TotalAmount,
                Items = savedOrder.OrderItems.Select(oi => new OrderItemReadDto
                {
                    OrderItemId = oi.OrderItemId,
                    ProductId = oi.ProductId,
                    ProductName = oi.Product?.Name ?? string.Empty,
                    Quantity = oi.Quantity,
                    Price = oi.Price,
                    LineTotal = oi.Price * oi.Quantity
                }).ToList()
            };
        }

        public async Task<List<OrderReadDto>> GetAllOrdersAsync()
        {
            var orders = await _orderRepository.GetAllAsync();

            return orders.Select(order => new OrderReadDto
            {
                OrderId = order.OrderId,
                UserId = order.UserId,
                CustomerName = order.User?.Name ?? string.Empty,
                OrderDate = order.OrderDate,
                TotalAmount = order.TotalAmount,
                Items = order.OrderItems.Select(oi => new OrderItemReadDto
                {
                    OrderItemId = oi.OrderItemId,
                    ProductId = oi.ProductId,
                    ProductName = oi.Product?.Name ?? string.Empty,
                    Quantity = oi.Quantity,
                    Price = oi.Price,
                    LineTotal = oi.Price * oi.Quantity
                }).ToList()
            }).ToList();
        }

        public async Task<OrderReadDto> GetOrderByIdAsync(int id)
        {
            var order = await _orderRepository.GetByIdAsync(id);

            if (order == null)
                throw new NotFoundException($"Order with ID {id} not found.");

            return new OrderReadDto
            {
                OrderId = order.OrderId,
                UserId = order.UserId,
                CustomerName = order.User?.Name ?? string.Empty,
                OrderDate = order.OrderDate,
                TotalAmount = order.TotalAmount,
                Items = order.OrderItems.Select(oi => new OrderItemReadDto
                {
                    OrderItemId = oi.OrderItemId,
                    ProductId = oi.ProductId,
                    ProductName = oi.Product?.Name ?? string.Empty,
                    Quantity = oi.Quantity,
                    Price = oi.Price,
                    LineTotal = oi.Price * oi.Quantity
                }).ToList()
            };
        }
    }
}
