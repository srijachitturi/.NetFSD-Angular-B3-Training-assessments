﻿using ShopEZ.Api.DTOs;

namespace ShopEZ.Api.Services.Interfaces
{
    public interface IProductService
    {
        Task<List<ProductReadDto>> GetAllAsync();
        Task<ProductReadDto> GetByIdAsync(int id);
        Task<ProductReadDto> CreateAsync(ProductCreateDto dto);
        Task<ProductReadDto> UpdateAsync(int id, ProductUpdateDto dto);
        Task DeleteAsync(int id);
    }
}