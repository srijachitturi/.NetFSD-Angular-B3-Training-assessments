﻿using ShopEZ.Api.DTOs;

namespace ShopEZ.Api.Services.Interfaces
{
    public interface IOrderService
    {
        Task<OrderReadDto> CreateOrderAsync(int userId, CreateOrderDto dto);
        Task<List<OrderReadDto>> GetAllOrdersAsync();
        Task<OrderReadDto> GetOrderByIdAsync(int id);
    }
}