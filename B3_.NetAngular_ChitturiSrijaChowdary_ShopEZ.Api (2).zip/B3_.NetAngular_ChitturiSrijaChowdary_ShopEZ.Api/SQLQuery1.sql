-- 1) Create Database
CREATE DATABASE ShopEZDb;
GO

-- 2) Use Database
USE ShopEZDb;
GO

-- 3) Create Users Table
CREATE TABLE Users
(
    UserId INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(100) NOT NULL,
    Email NVARCHAR(150) NOT NULL UNIQUE,
    Password NVARCHAR(100) NOT NULL,
    Role NVARCHAR(50) NOT NULL
);
GO

-- 4) Create Products Table
CREATE TABLE Products
(
    ProductId INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(150) NOT NULL,
    Description NVARCHAR(500) NOT NULL,
    Price DECIMAL(18,2) NOT NULL CHECK (Price > 0),
    ImageUrl NVARCHAR(500) NOT NULL,
    Stock INT NOT NULL CHECK (Stock >= 0)
);
GO

-- 5) Create Orders Table
CREATE TABLE Orders
(
    OrderId INT IDENTITY(1,1) PRIMARY KEY,
    UserId INT NOT NULL,
    OrderDate DATETIME NOT NULL DEFAULT GETDATE(),
    TotalAmount DECIMAL(18,2) NOT NULL DEFAULT 0,
    CONSTRAINT FK_Orders_Users FOREIGN KEY (UserId)
        REFERENCES Users(UserId)
);
GO

-- 6) Create OrderItems Table
CREATE TABLE OrderItems
(
    OrderItemId INT IDENTITY(1,1) PRIMARY KEY,
    OrderId INT NOT NULL,
    ProductId INT NOT NULL,
    Quantity INT NOT NULL CHECK (Quantity > 0),
    Price DECIMAL(18,2) NOT NULL CHECK (Price > 0),

    CONSTRAINT FK_OrderItems_Orders FOREIGN KEY (OrderId)
        REFERENCES Orders(OrderId)
        ON DELETE CASCADE,

    CONSTRAINT FK_OrderItems_Products FOREIGN KEY (ProductId)
        REFERENCES Products(ProductId)
);
GO

-- 7) Insert Users
INSERT INTO Users (Name, Email, Password, Role)
VALUES
('Srija Chowdary', 'srija@gmail.com', 'Pass@123', 'Customer'),
('Rahul Sharma', 'rahul@gmail.com', 'Pass@123', 'Customer'),
('Admin User', 'admin@gmail.com', 'Admin@123', 'Admin');
GO

-- 8) Insert Products
INSERT INTO Products (Name, Description, Price, ImageUrl, Stock)
VALUES

('Wireless Mouse', 'Ergonomic wireless mouse with USB receiver and smooth scrolling.', 799.00, 'https://images.unsplash.com/photo-1527864550417-7fd91fc51a46', 25),
('Mechanical Keyboard', 'Compact mechanical keyboard with RGB backlight and tactile keys.', 2499.00, 'https://images.unsplash.com/photo-1511467687858-23d96c32e4ae', 18),
('Bluetooth Headphones', 'Over-ear wireless headphones with deep bass and long battery life.', 3499.00, 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e', 12),
('USB-C Charger', 'Fast charging USB-C wall adapter for smartphones and tablets.', 999.00, 'https://images.unsplash.com/photo-1583863788434-e58a36330cf0', 40),
('Laptop Stand', 'Adjustable aluminum laptop stand for better posture and cooling.', 1499.00, 'https://images.unsplash.com/photo-1623251606108-512c7c4a3507?q=80&w=774&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', 20),
('Smart Watch', 'Fitness smartwatch with heart-rate monitoring and step tracking.', 2999.00, 'https://images.unsplash.com/photo-1523275335684-37898b6baf30', 15),
('Portable SSD', 'High-speed portable SSD with 512GB storage capacity.', 4599.00, 'https://images.unsplash.com/photo-1591488320449-011701bb6704', 10),
('Webcam HD', '1080p HD webcam ideal for online meetings and classes.', 1899.00, 'https://images.unsplash.com/photo-1614588876378-b2ffa4520c22?q=80&w=860&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', 22);
GO

-- 9) Insert Orders
INSERT INTO Orders (UserId, OrderDate, TotalAmount)
VALUES
(1, GETDATE(), 5097.00),
(2, GETDATE(), 2798.00);
GO

-- 10) Insert OrderItems
INSERT INTO OrderItems (OrderId, ProductId, Quantity, Price)
VALUES
(1, 1, 2, 799.00),   -- Wireless Mouse x 2 = 1598
(1, 3, 1, 3499.00),  -- Bluetooth Headphones x 1 = 3499
(2, 4, 1, 999.00),   -- USB-C Charger x 1 = 999
(2, 5, 1, 1499.00),  -- Laptop Stand x 1 = 1499
(2, 1, 1, 799.00);   -- Wireless Mouse x 1 = 799
GO

-- 11) View Data
SELECT * FROM Users;
SELECT * FROM Products;
SELECT * FROM Orders;
SELECT * FROM OrderItems;
GO