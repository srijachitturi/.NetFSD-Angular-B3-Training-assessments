﻿using Microsoft.EntityFrameworkCore;
using ShopEZ.Api.Models;

namespace ShopEZ.Api.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<User> Users => Set<User>();
        public DbSet<Product> Products => Set<Product>();
        public DbSet<Order> Orders => Set<Order>();
        public DbSet<OrderItem> OrderItems => Set<OrderItem>();

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<User>()
                .HasMany(u => u.Orders)
                .WithOne(o => o.User)
                .HasForeignKey(o => o.UserId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Order>()
                .HasMany(o => o.OrderItems)
                .WithOne(oi => oi.Order)
                .HasForeignKey(oi => oi.OrderId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Product>()
                .HasMany(p => p.OrderItems)
                .WithOne(oi => oi.Product)
                .HasForeignKey(oi => oi.ProductId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<User>().HasData(
                new User
                {
                    UserId = 1,
                    Name = "Srija Chowdary",
                    Email = "srija@gmail.com",
                    Password = "Pass@123",
                    Role = "Customer"
                },
                new User
                {
                    UserId = 2,
                    Name = "Rahul Sharma",
                    Email = "rahul@gmail.com",
                    Password = "Pass@123",
                    Role = "Customer"
                },
                new User
                {
                    UserId = 3,
                    Name = "Admin User",
                    Email = "admin@gmail.com",
                    Password = "Admin@123",
                    Role = "Admin"
                }
            );

            modelBuilder.Entity<Product>().HasData(
                new Product
                {
                    ProductId = 1,
                    Name = "Wireless Mouse",
                    Description = "Ergonomic wireless mouse with USB receiver and smooth scrolling.",
                    Price = 799.00m,
                    ImageUrl = "https://images.unsplash.com/photo-1527864550417-7fd91fc51a46",
                    Stock = 25
                },
                new Product
                {
                    ProductId = 2,
                    Name = "Mechanical Keyboard",
                    Description = "Compact mechanical keyboard with RGB backlight and tactile keys.",
                    Price = 2499.00m,
                    ImageUrl = "https://images.unsplash.com/photo-1511467687858-23d96c32e4ae",
                    Stock = 18
                },
                new Product
                {
                    ProductId = 3,
                    Name = "Bluetooth Headphones",
                    Description = "Over-ear wireless headphones with deep bass and long battery life.",
                    Price = 3499.00m,
                    ImageUrl = "https://images.unsplash.com/photo-1505740420928-5e560c06d30e",
                    Stock = 12
                },
                new Product
                {
                    ProductId = 4,
                    Name = "USB-C Charger",
                    Description = "Fast charging USB-C wall adapter for smartphones and tablets.",
                    Price = 999.00m,
                    ImageUrl = "https://images.unsplash.com/photo-1583863788434-e58a36330cf0",
                    Stock = 40
                },
                new Product
                {
                    ProductId = 5,
                    Name = "Laptop Stand",
                    Description = "Adjustable aluminum laptop stand for better posture and cooling.",
                    Price = 1499.00m,
                    ImageUrl = "https://images.unsplash.com/photo-1623251606108-512c7c4a3507?q=80&w=774&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
                    Stock = 20
                },
                new Product
                {
                    ProductId = 6,
                    Name = "Smart Watch",
                    Description = "Fitness smartwatch with heart-rate monitoring and step tracking.",
                    Price = 2999.00m,
                    ImageUrl = "https://images.unsplash.com/photo-1523275335684-37898b6baf30",
                    Stock = 15
                },
                new Product
                {
                    ProductId = 7,
                    Name = "Portable SSD",
                    Description = "High-speed portable SSD with 512GB storage capacity.",
                    Price = 4599.00m,
                    ImageUrl = "https://images.unsplash.com/photo-1591488320449-011701bb6704",
                    Stock = 10
                },
                new Product
                {
                    ProductId = 8,
                    Name = "Webcam HD",
                    Description = "1080p HD webcam ideal for online meetings and classes.",
                    Price = 1899.00m,
                    ImageUrl = "https://images.unsplash.com/photo-1614588876378-b2ffa4520c22?q=80&w=860&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
                    Stock = 22
                }
            );
        }
    }
}
