import { HttpClient } from '@angular/common/http';
import { isPlatformBrowser } from '@angular/common';
import { Injectable, signal } from '@angular/core';
import { PLATFORM_ID, inject } from '@angular/core';
import { Observable, tap } from 'rxjs';
import { ApiProduct, Product, ProductWriteDto } from '../models/product.model';

@Injectable({ providedIn: 'root' })
export class ProductService {
  private readonly platformId = inject(PLATFORM_ID);
  private readonly apiBase = isPlatformBrowser(this.platformId) ? '/api' : 'http://localhost:5073/api';
  private readonly apiUrl = `${this.apiBase}/Products`;
  private readonly hiddenProductNames = new Set(['tumbler', 'unauthorized product']);
  private readonly fallbackProducts: Product[] = [
    {
      id: 1,
      name: 'Wireless Mouse',
      category: 'Electronics',
      description: 'Ergonomic wireless mouse with USB receiver and smooth scrolling.',
      price: 799,
      image: 'https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?auto=format&fit=crop&w=900&q=80',
      stock: 25,
      rating: 4.3,
      reviewCount: 1383
    },
    {
      id: 2,
      name: 'Mechanical Keyboard',
      category: 'Electronics',
      description: 'Compact mechanical keyboard with RGB backlight and tactile keys.',
      price: 2499,
      image: 'https://images.unsplash.com/photo-1511467687858-23d96c32e4ae?auto=format&fit=crop&w=900&q=80',
      stock: 18,
      rating: 4.4,
      reviewCount: 1920
    },
    {
      id: 3,
      name: 'Bluetooth Headphones',
      category: 'Audio',
      description: 'Over-ear wireless headphones with deep bass and long battery life.',
      price: 3499,
      image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=900&q=80',
      stock: 12,
      rating: 4.6,
      reviewCount: 2457
    },
    {
      id: 4,
      name: 'USB-C Charger',
      category: 'Accessories',
      description: 'Fast charging USB-C wall adapter for smartphones and tablets.',
      price: 999,
      image: 'https://images.unsplash.com/photo-1583863788434-e58a36330cf0?auto=format&fit=crop&w=900&q=80',
      stock: 40,
      rating: 4.2,
      reviewCount: 1164
    },
    {
      id: 5,
      name: 'Laptop Stand',
      category: 'Accessories',
      description: 'Adjustable aluminum laptop stand for better posture and cooling.',
      price: 1499,
      image: 'https://images.unsplash.com/photo-1623251606108-512c7c4a3507?auto=format&fit=crop&w=900&q=80',
      stock: 20,
      rating: 4.5,
      reviewCount: 984
    },
    {
      id: 6,
      name: 'Smart Watch',
      category: 'Wearables',
      description: 'Fitness smartwatch with heart-rate monitoring and step tracking.',
      price: 2999,
      image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=900&q=80',
      stock: 15,
      rating: 4.7,
      reviewCount: 3011
    },
    {
      id: 7,
      name: 'Portable SSD',
      category: 'Accessories',
      description: 'High-speed portable SSD with 512GB storage capacity.',
      price: 4599,
      image: 'https://images.unsplash.com/photo-1591488320449-011701bb6704?auto=format&fit=crop&w=900&q=80',
      stock: 10,
      rating: 4.4,
      reviewCount: 1630
    },
    {
      id: 8,
      name: 'Webcam HD',
      category: 'Camera',
      description: '1080p HD webcam ideal for online meetings and classes.',
      price: 1899,
      image: 'https://images.unsplash.com/photo-1614588876378-b2ffa4520c22?auto=format&fit=crop&w=900&q=80',
      stock: 22,
      rating: 4.4,
      reviewCount: 1268
    }
  ];

  readonly products = signal<Product[]>([]);
  readonly loading = signal(false);
  readonly usingFallback = signal(false);

  constructor(private readonly http: HttpClient) {}

  loadProducts(): Observable<ApiProduct[]> {
    this.loading.set(true);
    this.usingFallback.set(false);

    return this.http.get<ApiProduct[]>(this.apiUrl).pipe(
      tap({
        next: (products) => {
          this.products.set(
            this.uniqueProducts(
              products
                .map((product) => this.mapApiProduct(product))
                .filter((product) => !this.hiddenProductNames.has(product.name.trim().toLowerCase()))
            )
          );
          this.usingFallback.set(false);
          this.loading.set(false);
        },
        error: () => {
          this.products.set(this.fallbackProducts);
          this.usingFallback.set(true);
          this.loading.set(false);
        }
      })
    );
  }

  createProduct(product: ProductWriteDto, headers: Record<string, string>): Observable<ApiProduct> {
    return this.http.post<ApiProduct>(this.apiUrl, product, { headers });
  }

  updateProduct(id: number, product: ProductWriteDto, headers: Record<string, string>): Observable<ApiProduct> {
    return this.http.put<ApiProduct>(`${this.apiUrl}/${id}`, product, { headers });
  }

  deleteProduct(id: number, headers: Record<string, string>): Observable<unknown> {
    return this.http.delete(`${this.apiUrl}/${id}`, { headers });
  }

  toWriteDto(product: Product): ProductWriteDto {
    return {
      name: product.name,
      description: product.description,
      price: Number(product.price),
      imageUrl: product.image,
      stock: Number(product.stock)
    };
  }

  private mapApiProduct(product: ApiProduct): Product {
    const id = this.firstNumber(product.productId, product.ProductId);
    const name = this.firstString(product.name, product.Name);
    const description = this.firstString(product.description, product.Description);
    const price = this.firstNumber(product.price, product.Price);
    const image = this.normalizeImageUrl(this.firstString(product.imageUrl, product.ImageUrl));
    const stock = this.firstNumber(product.stock, product.Stock);

    return this.withStoreMeta({
      id,
      name,
      category: this.inferCategory(name, description),
      description,
      price,
      image,
      stock
    });
  }

  private withStoreMeta(product: Product): Product {
    const discountPercent = product.discountPercent ?? this.discountFor(product.id);
    const originalPrice =
      product.originalPrice ?? Math.max(product.price + 1, Math.round(product.price / (1 - discountPercent / 100)));

    return {
      ...product,
      discountPercent,
      originalPrice,
      rating: product.rating ?? this.ratingFor(product.id),
      reviewCount: product.reviewCount ?? this.reviewCountFor(product.id)
    };
  }

  private uniqueProducts(products: Product[]): Product[] {
    const seen = new Set<string>();
    return products.filter((product) => {
      const key = product.name.trim().toLowerCase();
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }

  private firstString(...values: Array<string | undefined>): string {
    return values.find((value) => typeof value === 'string' && value.trim().length > 0)?.trim() ?? '';
  }

  private firstNumber(...values: Array<number | undefined>): number {
    return Number(values.find((value) => typeof value === 'number') ?? 0);
  }

  private normalizeImageUrl(url: string): string {
    if (!url) {
      return 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?auto=format&fit=crop&w=900&q=80';
    }

    if (url.includes('images.unsplash.com') && !url.includes('?')) {
      return `${url}?auto=format&fit=crop&w=900&q=80`;
    }

    return url;
  }

  private discountFor(id: number): number {
    const discounts = [10, 15, 23, 8, 12, 18, 20, 25];
    return discounts[Math.abs(id) % discounts.length] ?? 10;
  }

  private ratingFor(id: number): number {
    return Number((4.2 + (Math.abs(id) % 7) * 0.1).toFixed(1));
  }

  private reviewCountFor(id: number): number {
    return 846 + Math.abs(id) * 537;
  }

  private inferCategory(name: string, description: string): string {
    const text = `${name} ${description}`.toLowerCase();
    if (text.includes('earbud') || text.includes('headphone') || text.includes('speaker')) return 'Audio';
    if (text.includes('watch') || text.includes('fitness band')) return 'Wearables';
    if (text.includes('charger') || text.includes('ssd') || text.includes('stand')) return 'Accessories';
    if (text.includes('camera') || text.includes('webcam')) return 'Camera';
    if (text.includes('tablet') || text.includes('ipad')) return 'Tablets';
    if (text.includes('gaming') || text.includes('console')) return 'Gaming';
    if (text.includes('keyboard') || text.includes('mouse') || text.includes('laptop') || text.includes('phone')) {
      return 'Electronics';
    }
    return 'Electronics';
  }
}
