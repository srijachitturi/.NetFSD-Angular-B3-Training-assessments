import { HttpClient } from '@angular/common/http';
import { isPlatformBrowser } from '@angular/common';
import { Injectable, PLATFORM_ID, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { CreateOrderDto, OrderRead } from '../models/order.model';

@Injectable({ providedIn: 'root' })
export class OrderService {
  private readonly platformId = inject(PLATFORM_ID);
  private readonly apiBase = isPlatformBrowser(this.platformId) ? '/api' : 'http://localhost:5073/api';
  private readonly apiUrl = `${this.apiBase}/Orders`;

  constructor(private readonly http: HttpClient) {}

  createOrder(order: CreateOrderDto, headers: Record<string, string>): Observable<OrderRead> {
    return this.http.post<OrderRead>(this.apiUrl, order, { headers });
  }

  getOrders(headers: Record<string, string>): Observable<OrderRead[]> {
    return this.http.get<OrderRead[]>(this.apiUrl, { headers });
  }
}
