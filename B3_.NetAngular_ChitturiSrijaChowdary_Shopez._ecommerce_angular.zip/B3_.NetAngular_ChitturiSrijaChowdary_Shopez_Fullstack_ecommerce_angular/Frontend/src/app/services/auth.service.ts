import { isPlatformBrowser } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Injectable, PLATFORM_ID, computed, inject, signal } from '@angular/core';
import { Observable, tap } from 'rxjs';
import { LoginRequest, LoginResponse, RegisterRequest } from '../models/auth.model';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly http = inject(HttpClient);
  private readonly platformId = inject(PLATFORM_ID);
  private readonly isBrowser = isPlatformBrowser(this.platformId);
  private readonly apiBase = this.isBrowser ? '/api' : 'http://localhost:5073/api';
  private readonly tokenKey = 'shopez_token';
  private readonly userKey = 'shopez_user';
  private readonly roleKey = 'shopez_role';

  readonly token = signal('');
  readonly userName = signal('');
  readonly role = signal('');
  readonly isAdmin = computed(() => this.role() === 'Admin');
  readonly isLoggedIn = computed(() => Boolean(this.token()));

  restoreSession(): void {
    if (!this.isBrowser) return;
    this.token.set(localStorage.getItem(this.tokenKey) ?? '');
    this.userName.set(localStorage.getItem(this.userKey) ?? '');
    this.role.set(localStorage.getItem(this.roleKey) ?? '');
  }

  login(credentials: LoginRequest): Observable<LoginResponse> {
    return this.http.post<LoginResponse>(`${this.apiBase}/Auth/login`, credentials).pipe(
      tap((response) => this.storeSession(response))
    );
  }

  register(details: RegisterRequest): Observable<LoginResponse> {
    return this.http.post<LoginResponse>(`${this.apiBase}/Auth/register`, details).pipe(
      tap((response) => this.storeSession(response))
    );
  }

  logout(): void {
    this.token.set('');
    this.userName.set('');
    this.role.set('');
    if (this.isBrowser) {
      localStorage.removeItem(this.tokenKey);
      localStorage.removeItem(this.userKey);
      localStorage.removeItem(this.roleKey);
    }
  }

  authHeaders(): Record<string, string> {
    return { Authorization: `Bearer ${this.token()}` };
  }

  private storeSession(response: LoginResponse): void {
    this.token.set(response.token);
    this.userName.set(response.user);
    this.role.set(response.role);
    if (!this.isBrowser) return;
    localStorage.setItem(this.tokenKey, response.token);
    localStorage.setItem(this.userKey, response.user);
    localStorage.setItem(this.roleKey, response.role);
  }
}
