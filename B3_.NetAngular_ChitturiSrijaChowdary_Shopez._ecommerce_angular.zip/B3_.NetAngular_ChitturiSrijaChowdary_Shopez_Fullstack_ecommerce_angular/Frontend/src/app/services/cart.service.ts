import { isPlatformBrowser } from '@angular/common';
import { Injectable, PLATFORM_ID, computed, inject, signal } from '@angular/core';
import { CartItem } from '../models/cart.model';
import { Product } from '../models/product.model';

@Injectable({ providedIn: 'root' })
export class CartService {
  private readonly platformId = inject(PLATFORM_ID);
  private readonly isBrowser = isPlatformBrowser(this.platformId);
  private readonly cartKey = 'shopez_cart';

  readonly cart = signal<CartItem[]>([]);
  readonly cartCount = computed(() => this.cart().reduce((total, item) => total + item.quantity, 0));
  readonly cartTotal = computed(() => this.cart().reduce((total, item) => total + item.price * item.quantity, 0));

  restoreCart(): void {
    if (!this.isBrowser) return;
    const raw = localStorage.getItem(this.cartKey);
    this.cart.set(raw ? JSON.parse(raw) : []);
  }

  addToCart(product: Product): 'added' | 'out-of-stock' | 'stock-limit' {
    if (product.stock === 0) return 'out-of-stock';

    const cart = [...this.cart()];
    const existing = cart.find((item) => item.id === product.id);
    if (existing) {
      if (existing.quantity >= product.stock) return 'stock-limit';
      existing.quantity += 1;
    } else {
      cart.push({ ...product, quantity: 1 });
    }

    this.saveCart(cart);
    return 'added';
  }

  updateQuantity(productId: number, change: number): 'updated' | 'removed' | 'stock-limit' | 'missing' {
    const cart = [...this.cart()];
    const item = cart.find((cartItem) => cartItem.id === productId);
    if (!item) return 'missing';

    const quantity = item.quantity + change;
    if (quantity <= 0) {
      this.removeFromCart(productId);
      return 'removed';
    }
    if (quantity > item.stock) return 'stock-limit';

    item.quantity = quantity;
    this.saveCart(cart);
    return 'updated';
  }

  removeFromCart(productId: number): void {
    this.saveCart(this.cart().filter((item) => item.id !== productId));
  }

  clearCart(): void {
    this.saveCart([]);
  }

  private saveCart(cart: CartItem[]): void {
    this.cart.set(cart);
    if (this.isBrowser) {
      localStorage.setItem(this.cartKey, JSON.stringify(cart));
    }
  }
}
