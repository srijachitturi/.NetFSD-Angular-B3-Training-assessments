import { Injectable } from '@angular/core'; 
import { Observable, delay, of } from 'rxjs';
import { PaymentDetails, PaymentReceipt } from '../models/payment.model';

@Injectable({ providedIn: 'root' })
export class PaymentService {
  processPayment(payment: PaymentDetails, amount: number): Observable<PaymentReceipt> {
    const methodLabels: Record<string, string> = {
      card: 'Credit / Debit Card',
      upi: 'UPI',
      netbanking: 'Net Banking',
      cod: 'Cash on Delivery'
    };

    return of({
      method: methodLabels[payment.method],
      transactionId: payment.method === 'cod' ? 'COD-' + Date.now() : 'TXN-' + Date.now(),
      paidAt: new Date().toLocaleString('en-IN'),
      status: payment.method === 'cod' ? 'Payable on delivery' : 'Payment successful',
      amount
    }).pipe(delay(650));
  }
}
