import { CommonModule, isPlatformBrowser } from '@angular/common';
import { Component, OnInit, PLATFORM_ID, ViewEncapsulation, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { NavigationEnd, Router, RouterOutlet } from '@angular/router';
import { filter } from 'rxjs';
import { CartItemComponent } from './components/cart-item/cart-item.component';
import { FooterComponent } from './components/footer/footer.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { ProductCardComponent } from './components/product-card/product-card.component';
import { CheckoutDetails, OrderRead, OrderSuccessDetails } from './models/order.model';
import { PaymentDetails } from './models/payment.model';
import { Product } from './models/product.model';
import { AuthService } from './services/auth.service';
import { CartService } from './services/cart.service';
import { OrderService } from './services/order.service';
import { PaymentService } from './services/payment.service';
import { ProductService } from './services/product.service';

type ViewName = 'home' | 'products' | 'cart' | 'checkout' | 'register' | 'admin' | 'success';
type SortMode = 'default' | 'price-low' | 'price-high' | 'name-asc';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterOutlet, NavbarComponent, FooterComponent, ProductCardComponent, CartItemComponent],
  templateUrl: './app.html',
  styleUrl: './app.css',
  encapsulation: ViewEncapsulation.None
})
export class AppComponent implements OnInit {
  private readonly platformId = inject(PLATFORM_ID);
  private readonly isBrowser = isPlatformBrowser(this.platformId);
  private readonly productsApi = inject(ProductService);
  private readonly cartApi = inject(CartService);
  private readonly authApi = inject(AuthService);
  private readonly orderApi = inject(OrderService);
  private readonly paymentApi = inject(PaymentService);
  private readonly router = inject(Router);

  readonly products = this.productsApi.products;
  readonly loading = this.productsApi.loading;
  readonly usingFallback = this.productsApi.usingFallback;
  readonly cart = this.cartApi.cart;
  readonly cartCount = this.cartApi.cartCount;
  readonly cartTotal = this.cartApi.cartTotal;
  readonly token = this.authApi.token;
  readonly userName = this.authApi.userName;
  readonly role = this.authApi.role;
  readonly isAdmin = this.authApi.isAdmin;
  readonly isLoggedIn = this.authApi.isLoggedIn;

  view = signal<ViewName>('home');
  orders = signal<OrderRead[]>([]);
  orderSuccess = signal<OrderSuccessDetails | null>(null);
  paymentProcessing = signal(false);
  message = signal('');
  messageType = signal<'success' | 'danger' | 'info'>('info');

  search = signal('');
  selectedCategories = signal<string[]>([]);
  minPrice = signal('');
  maxPrice = signal('');
  minRating = signal('0');
  sort = signal<SortMode>('default');
  selectedProduct = signal<Product | null>(null);
  adminSearch = signal('');
  login = { email: 'admin@gmail.com', password: 'Admin@123' };
  customerLogin = { email: 'srija@gmail.com', password: 'Pass@123' };
  register = { name: '', email: '', password: '' };
  checkout: CheckoutDetails = { name: '', email: '', phone: '', address: '' };
  payment: PaymentDetails = {
    method: 'card',
    cardName: '',
    cardNumber: '',
    expiry: '',
    cvv: '',
    upiId: '',
    bank: 'State Bank of India'
  };
  formProduct: Product = this.emptyProduct();
  editingId: number | null = null;

  private readonly categoryOrder = ['Electronics', 'Audio', 'Wearables', 'Accessories', 'Camera', 'Tablets', 'Gaming'];

  categories = computed(() =>
    [...new Set(this.products().map((product) => product.category))].sort((a, b) => {
      const aIndex = this.categoryOrder.indexOf(a);
      const bIndex = this.categoryOrder.indexOf(b);
      if (aIndex === -1 && bIndex === -1) return a.localeCompare(b);
      if (aIndex === -1) return 1;
      if (bIndex === -1) return -1;
      return aIndex - bIndex;
    })
  );
  featuredProducts = computed(() => this.products().slice(0, 4));
  totalProducts = computed(() => this.products().length);

  filteredProducts = computed(() => {
    const query = this.search().trim().toLowerCase();
    const selectedCategories = this.selectedCategories();
    const minPrice = Number(this.minPrice()) || 0;
    const maxPrice = Number(this.maxPrice()) || Number.MAX_SAFE_INTEGER;
    const minRating = Number(this.minRating()) || 0;
    const selectedSort = this.sort();
    let list = this.products().filter((product) => {
      const matchesSearch =
        !query ||
        product.name.toLowerCase().includes(query) ||
        product.category.toLowerCase().includes(query) ||
        product.description.toLowerCase().includes(query);
      const matchesCategory = !selectedCategories.length || selectedCategories.includes(product.category);
      const matchesPrice = product.price >= minPrice && product.price <= maxPrice;
      const matchesRating = (product.rating ?? 0) >= minRating;
      return matchesSearch && matchesCategory && matchesPrice && matchesRating;
    });

    if (selectedSort === 'price-low') list = [...list].sort((a, b) => a.price - b.price);
    if (selectedSort === 'price-high') list = [...list].sort((a, b) => b.price - a.price);
    if (selectedSort === 'name-asc') list = [...list].sort((a, b) => a.name.localeCompare(b.name));
    return list;
  });

  filteredAdminProducts = computed(() => {
    const query = this.adminSearch().trim().toLowerCase();
    return this.products().filter(
      (product) =>
        !query ||
        product.name.toLowerCase().includes(query) ||
        product.category.toLowerCase().includes(query)
    );
  });

  categoryCounts = computed(() => {
    return this.products().reduce<Record<string, number>>((counts, product) => {
      counts[product.category] = (counts[product.category] ?? 0) + 1;
      return counts;
    }, {});
  });

  ngOnInit(): void {
    this.authApi.restoreSession();
    this.cartApi.restoreCart();
    this.syncViewWithUrl(this.router.url);
    this.router.events
      .pipe(filter((event): event is NavigationEnd => event instanceof NavigationEnd))
      .subscribe((event) => this.syncViewWithUrl(event.urlAfterRedirects));
    this.loadProducts();
  }

  setView(view: ViewName, updateUrl = true): void {
    this.view.set(view);
    this.message.set('');
    if (view === 'admin' && this.isAdmin()) {
      this.loadOrders();
    }
    if (updateUrl && this.router.url !== this.routeForView(view)) {
      void this.router.navigateByUrl(this.routeForView(view));
    }
  }

  loadProducts(): void {
    this.productsApi.loadProducts().subscribe({
      error: () => this.showMessage('We are showing featured products while the live catalog refreshes.', 'info')
    });
  }

  addToCart(product: Product): void {
    const result = this.cartApi.addToCart(product);
    if (result === 'out-of-stock') this.showMessage('This product is out of stock.', 'danger');
    if (result === 'stock-limit') this.showMessage('Maximum available stock reached.', 'danger');
    if (result === 'added') this.showMessage(`${product.name} added to cart.`, 'success');
  }

  updateQuantity(productId: number, change: number): void {
    const result = this.cartApi.updateQuantity(productId, change);
    if (result === 'stock-limit') this.showMessage('Cannot exceed available stock.', 'danger');
  }

  removeFromCart(productId: number): void {
    this.cartApi.removeFromCart(productId);
  }

  clearFilters(): void {
    this.search.set('');
    this.selectedCategories.set([]);
    this.minPrice.set('');
    this.maxPrice.set('');
    this.minRating.set('0');
    this.sort.set('default');
  }

  selectCategory(category: string): void {
    this.search.set('');
    this.selectedCategories.set([category]);
    this.sort.set('default');
    this.setView('products');
  }

  isCategorySelected(category: string): boolean {
    return this.selectedCategories().includes(category);
  }

  toggleCategory(category: string, event: Event): void {
    const checked = (event.target as HTMLInputElement).checked;
    const selected = this.selectedCategories();
    this.selectedCategories.set(
      checked ? [...selected, category] : selected.filter((item) => item !== category)
    );
  }

  viewProduct(product: Product): void {
    this.selectedProduct.set(product);
  }

  closeProductDetails(): void {
    this.selectedProduct.set(null);
  }

  addViewedProductToCart(product: Product): void {
    this.addToCart(product);
    if (product.stock > 0) this.closeProductDetails();
  }

  placeOrder(): void {
    if (!this.isLoggedIn()) {
      this.showMessage('Please login as a customer on the checkout page before placing the order.', 'danger');
      return;
    }
    if (!this.cart().length) {
      this.showMessage('Your cart is empty.', 'danger');
      return;
    }
    if (!this.isCustomerDetailsValid()) {
      this.showMessage('Please complete valid customer details before placing the order.', 'danger');
      return;
    }
    if (!this.isPaymentDetailsValid()) {
      this.showMessage('Please complete valid payment details for the selected payment method.', 'danger');
      return;
    }

    const cartSnapshot = this.cart().map((item) => ({ ...item }));
    const customerSnapshot = { ...this.checkout };
    this.paymentProcessing.set(true);

    this.paymentApi.processPayment(this.payment, this.cartTotal()).subscribe({
      next: (paymentReceipt) => {
        const body = {
          userId: 0,
          items: cartSnapshot.map((item) => ({ productId: item.id, quantity: item.quantity }))
        };

        this.orderApi.createOrder(body, this.authApi.authHeaders()).subscribe({
          next: (order) => {
            this.orderSuccess.set({
              order,
              customer: customerSnapshot,
              cartItems: cartSnapshot,
              payment: paymentReceipt
            });
            this.paymentProcessing.set(false);
            this.cartApi.clearCart();
            this.checkout = { name: '', email: '', phone: '', address: '' };
            this.resetPayment();
            this.showMessage('My order placed successfully with complete order details.', 'success');
            this.setView('success');
            this.loadOrders();
            this.loadProducts();
          },
          error: () => {
            this.paymentProcessing.set(false);
            this.showMessage('Payment completed, but order confirmation failed. Please login again and try once more.', 'danger');
          }
        });
      },
      error: () => {
        this.paymentProcessing.set(false);
        this.showMessage('Payment failed. Please verify payment details.', 'danger');
      }
    });
  }

  loginUser(): void {
    this.authApi.login(this.login).subscribe({
      next: (response) => {
        this.showMessage(`Logged in as ${response.user}.`, 'success');
        if (response.role === 'Admin') this.loadOrders();
      },
      error: (error) => {
        const message =
          error.status === 401
            ? 'Invalid email or password.'
            : 'Admin login failed. Please check that the store service is running and try again.';
        this.showMessage(message, 'danger');
      }
    });
  }

  loginCustomer(): void {
    this.authApi.login(this.customerLogin).subscribe({
      next: (response) => {
        this.showMessage(`Logged in as ${response.user}. You can place your order now.`, 'success');
        if (!this.checkout.email) this.checkout.email = this.customerLogin.email;
        if (!this.checkout.name) this.checkout.name = response.user;
      },
      error: (error) => {
        const message =
          error.status === 401
            ? 'Invalid customer email or password.'
            : 'Customer login failed. Please check that the store service is running and try again.';
        this.showMessage(message, 'danger');
      }
    });
  }

  registerCustomer(): void {
    if (!this.isRegisterDetailsValid()) {
      this.showMessage('Please enter a valid name, email, and password with at least 6 characters.', 'danger');
      return;
    }

    this.authApi.register(this.register).subscribe({
      next: (response) => {
        this.checkout.name = response.user;
        this.checkout.email = this.register.email;
        this.showMessage(`Account created for ${response.user}. You can place your order now.`, 'success');
        this.register = { name: '', email: '', password: '' };
        this.setView(this.cart().length ? 'checkout' : 'products');
      },
      error: (error) => {
        const message =
          error.status === 409
            ? 'An account with this email already exists. Please login instead.'
            : 'Registration failed. Please check that the store service is running and try again.';
        this.showMessage(message, 'danger');
      }
    });
  }

  logout(): void {
    this.authApi.logout();
    this.showMessage('Logged out successfully.', 'success');
  }

  saveProduct(): void {
    if (!this.isAdmin()) {
      this.showMessage('Admin login is required to manage products.', 'danger');
      return;
    }
    if (!this.formProduct.name || !this.formProduct.description || !this.formProduct.image || this.formProduct.price <= 0) {
      this.showMessage('Please enter valid product details.', 'danger');
      return;
    }

    const body = this.productsApi.toWriteDto(this.formProduct);
    const request =
      this.editingId === null
        ? this.productsApi.createProduct(body, this.authApi.authHeaders())
        : this.productsApi.updateProduct(this.editingId, body, this.authApi.authHeaders());

    request.subscribe({
      next: () => {
        this.showMessage(this.editingId === null ? 'Product added successfully.' : 'Product updated successfully.', 'success');
        this.resetForm();
        this.loadProducts();
      },
      error: () => this.showMessage('Product save failed. Please login as admin and try again.', 'danger')
    });
  }

  editProduct(product: Product): void {
    this.editingId = product.id;
    this.formProduct = { ...product };
    if (this.isBrowser) window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  deleteProduct(productId: number): void {
    if (!this.isAdmin()) {
      this.showMessage('Admin login is required to delete products.', 'danger');
      return;
    }
    if (this.isBrowser && !confirm('Delete this product?')) return;

    this.productsApi.deleteProduct(productId, this.authApi.authHeaders()).subscribe({
      next: () => {
        this.showMessage('Product deleted successfully.', 'success');
        this.cartApi.removeFromCart(productId);
        this.loadProducts();
      },
      error: () => this.showMessage('Product delete failed. Please login as admin and try again.', 'danger')
    });
  }

  resetForm(): void {
    this.editingId = null;
    this.formProduct = this.emptyProduct();
  }

  formatPrice(price: number): string {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(Number(price));
  }

  paymentMethodLabel(method: string): string {
    const labels: Record<string, string> = {
      card: 'Credit / Debit Card',
      upi: 'UPI',
      netbanking: 'Net Banking',
      cod: 'Cash on Delivery'
    };
    return labels[method] ?? method;
  }

  private loadOrders(): void {
    if (!this.isLoggedIn()) return;
    this.orderApi.getOrders(this.authApi.authHeaders()).subscribe({
      next: (orders) => this.orders.set(orders),
      error: () => this.orders.set([])
    });
  }

  private isCustomerDetailsValid(): boolean {
    return (
      this.checkout.name.trim().length >= 3 &&
      /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(this.checkout.email.trim()) &&
      /^[0-9]{10}$/.test(this.checkout.phone.trim()) &&
      this.checkout.address.trim().length >= 10
    );
  }

  private isRegisterDetailsValid(): boolean {
    return (
      this.register.name.trim().length >= 3 &&
      /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(this.register.email.trim()) &&
      this.register.password.trim().length >= 6
    );
  }

  private isPaymentDetailsValid(): boolean {
    if (this.payment.method === 'cod') return true;
    if (this.payment.method === 'upi') return /^[\w.-]+@[\w.-]+$/.test(this.payment.upiId.trim());
    if (this.payment.method === 'netbanking') return Boolean(this.payment.bank);
    return (
      this.payment.cardName.trim().length >= 3 &&
      /^[0-9]{16}$/.test(this.payment.cardNumber.replace(/\s/g, '')) &&
      /^(0[1-9]|1[0-2])\/[0-9]{2}$/.test(this.payment.expiry.trim()) &&
      /^[0-9]{3}$/.test(this.payment.cvv.trim())
    );
  }

  private resetPayment(): void {
    this.payment = {
      method: 'card',
      cardName: '',
      cardNumber: '',
      expiry: '',
      cvv: '',
      upiId: '',
      bank: 'State Bank of India'
    };
  }

  private showMessage(message: string, type: 'success' | 'danger' | 'info'): void {
    this.message.set(message);
    this.messageType.set(type);
  }

  private syncViewWithUrl(url: string): void {
    const view = this.viewForUrl(url);
    if (view !== this.view()) {
      this.setView(view, false);
    }
  }

  private viewForUrl(url: string): ViewName {
    const path = url.split('?')[0].split('#')[0].replace(/^\/+/, '').split('/')[0];
    if (
      path === 'products' ||
      path === 'cart' ||
      path === 'checkout' ||
      path === 'register' ||
      path === 'admin' ||
      path === 'success'
    ) {
      return path;
    }
    return 'home';
  }

  private routeForView(view: ViewName): string {
    return view === 'home' ? '/' : `/${view}`;
  }

  private emptyProduct(): Product {
    return { id: 0, name: '', category: 'ShopEZ', description: '', price: 0, image: '', stock: 0 };
  }
}
