import { CartItem } from './cart.model';

export interface CreateOrderDto {
  userId: number;
  items: { productId: number; quantity: number }[];
}

export interface OrderRead {
  orderId: number;
  userId?: number;
  customerName: string;
  orderDate: string;
  totalAmount: number;
  items: { productName: string; quantity: number; price?: number; lineTotal: number }[];
}

export interface CheckoutDetails {
  name: string;
  email: string;
  phone: string;
  address: string;
}

export interface OrderSuccessDetails {
  order: OrderRead;
  customer: CheckoutDetails;
  cartItems: CartItem[];
  payment: {
    method: string;
    transactionId: string;
    paidAt: string;
    status: string;
    amount: number;
  };
}
