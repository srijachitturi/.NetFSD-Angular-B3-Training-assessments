export interface ApiProduct {
  productId?: number;
  ProductId?: number;
  name?: string;
  Name?: string;
  description?: string;
  Description?: string;
  price?: number;
  Price?: number;
  imageUrl?: string;
  ImageUrl?: string;
  stock?: number;
  Stock?: number;
}

export interface Product {
  id: number;
  name: string;
  category: string;
  description: string;
  price: number;
  image: string;
  stock: number;
  rating?: number;
  reviewCount?: number;
  originalPrice?: number;
  discountPercent?: number;
}

export interface ProductWriteDto {
  name: string;
  description: string;
  price: number;
  imageUrl: string;
  stock: number;
}
