export type PaymentMethod = 'card' | 'upi' | 'netbanking' | 'cod';

export interface PaymentDetails {
  method: PaymentMethod;
  cardName: string;
  cardNumber: string;
  expiry: string;
  cvv: string;
  upiId: string;
  bank: string;
}

export interface PaymentReceipt {
  method: string;
  transactionId: string;
  paidAt: string;
  status: string;
  amount: number;
}
