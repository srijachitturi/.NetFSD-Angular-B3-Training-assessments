import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { NavView } from '../navbar/navbar.component';

@Component({
  selector: 'app-footer',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './footer.component.html'
})
export class FooterComponent {
  @Input({ required: true }) categories: string[] = [];

  @Output() navigate = new EventEmitter<NavView>();
  @Output() categorySelected = new EventEmitter<string>();
}
