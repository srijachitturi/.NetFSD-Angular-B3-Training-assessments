import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CartItem } from '../../models/cart.model';

@Component({
  selector: 'app-cart-item',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './cart-item.component.html'
})
export class CartItemComponent {
  @Input({ required: true }) item!: CartItem;
  @Input({ required: true }) formatPrice!: (price: number) => string;

  @Output() quantityChange = new EventEmitter<number>();
  @Output() remove = new EventEmitter<void>();
}
