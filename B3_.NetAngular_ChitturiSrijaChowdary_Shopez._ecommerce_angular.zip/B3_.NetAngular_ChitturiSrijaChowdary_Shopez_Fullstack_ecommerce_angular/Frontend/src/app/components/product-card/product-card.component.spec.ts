import { ComponentFixture, TestBed } from '@angular/core/testing';
import { vi } from 'vitest';
import { Product } from '../../models/product.model';
import { ProductCardComponent } from './product-card.component';

describe('ProductCardComponent', () => {
  let fixture: ComponentFixture<ProductCardComponent>;
  let component: ProductCardComponent;

  const product: Product = {
    id: 1,
    name: 'Mechanical Keyboard',
    category: 'Electronics',
    description: 'Compact keyboard with tactile keys.',
    price: 2499,
    image: 'keyboard.jpg',
    stock: 2
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ProductCardComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(ProductCardComponent);
    component = fixture.componentInstance;
    component.product = product;
    fixture.detectChanges();
  });

  it('renders product details with Indian currency formatting', () => {
    const compiled = fixture.nativeElement as HTMLElement;

    expect(compiled.querySelector('h3')?.textContent).toContain('Mechanical Keyboard');
    expect(compiled.textContent).toContain(component.formatPrice(product.price));
    expect(compiled.textContent).toContain('Only 2 left');
  });

  it('emits the product when add to cart is clicked', () => {
    const emitSpy = vi.spyOn(component.addToCart, 'emit');
    const button = fixture.nativeElement.querySelector('.add-to-cart-btn') as HTMLButtonElement;

    button.click();

    expect(emitSpy).toHaveBeenCalledWith(product);
  });
});
