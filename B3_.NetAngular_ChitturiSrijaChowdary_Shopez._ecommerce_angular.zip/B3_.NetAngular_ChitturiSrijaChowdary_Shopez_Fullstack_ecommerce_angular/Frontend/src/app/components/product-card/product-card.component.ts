import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Product } from '../../models/product.model';

@Component({
  selector: 'app-product-card',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './product-card.component.html',
  styleUrl: './product-card.component.css'
})
export class ProductCardComponent {
  @Input({ required: true }) product!: Product;
  @Output() addToCart = new EventEmitter<Product>();
  @Output() viewProduct = new EventEmitter<Product>();

  stockClass(stock: number): string {
    if (stock === 0) return 'out-stock';
    if (stock <= 3) return 'low-stock';
    return 'in-stock';
  }

  stockLabel(stock: number): string {
    if (stock === 0) return 'Out of Stock';
    if (stock <= 3) return `Only ${stock} left`;
    return 'In Stock';
  }

  formatPrice(price: number): string {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(Number(price));
  }

  formatReviews(count: number | undefined): string {
    return Number(count ?? 0).toLocaleString('en-IN');
  }
}
