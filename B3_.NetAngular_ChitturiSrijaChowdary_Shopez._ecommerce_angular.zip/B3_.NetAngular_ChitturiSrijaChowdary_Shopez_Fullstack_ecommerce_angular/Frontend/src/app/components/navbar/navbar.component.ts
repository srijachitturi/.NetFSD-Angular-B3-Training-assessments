import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';

export type NavView = 'home' | 'products' | 'cart' | 'checkout' | 'register' | 'admin' | 'success';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './navbar.component.html'
})
export class NavbarComponent {
  @Input({ required: true }) view!: NavView;
  @Input({ required: true }) cartCount = 0;
  @Input({ required: true }) search = '';

  @Output() searchChange = new EventEmitter<string>();
  @Output() navigate = new EventEmitter<NavView>();
}
