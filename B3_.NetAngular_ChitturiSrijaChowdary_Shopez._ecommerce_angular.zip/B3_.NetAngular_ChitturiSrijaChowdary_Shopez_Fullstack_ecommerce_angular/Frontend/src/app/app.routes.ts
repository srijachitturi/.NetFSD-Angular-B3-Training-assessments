import { Routes } from '@angular/router';
import { RoutePageComponent } from './route-page.component';

export const routes: Routes = [
  { path: '', component: RoutePageComponent, title: 'ShopEZ' },
  { path: 'products', component: RoutePageComponent, title: 'Products | ShopEZ' },
  { path: 'cart', component: RoutePageComponent, title: 'Cart | ShopEZ' },
  { path: 'checkout', component: RoutePageComponent, title: 'Checkout | ShopEZ' },
  { path: 'register', component: RoutePageComponent, title: 'Register | ShopEZ' },
  { path: 'admin', component: RoutePageComponent, title: 'Admin | ShopEZ' },
  { path: 'success', component: RoutePageComponent, title: 'Order Confirmed | ShopEZ' },
  { path: '**', redirectTo: '' }
];
