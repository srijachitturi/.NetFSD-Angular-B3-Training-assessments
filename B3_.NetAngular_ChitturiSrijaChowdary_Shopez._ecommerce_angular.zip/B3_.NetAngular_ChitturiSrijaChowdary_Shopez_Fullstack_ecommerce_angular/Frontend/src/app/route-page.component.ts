import { Component } from '@angular/core';

@Component({
  selector: 'app-route-page',
  standalone: true,
  template: ''
})
export class RoutePageComponent {}
