# ShopEZ Full Stack E-Commerce Application

This workspace follows the full-stack submission layout:

- `Backend/ShopEZ/ShopEZ.Api` contains the ASP.NET Core Web API.
- `Frontend` contains the Angular application.
- `ShopEZ_Database_Setup.sql` contains the baseline SQL Server database setup.

Run the backend:

```bash
cd Backend/ShopEZ/ShopEZ.Api
dotnet run --launch-profile http
```

Run the frontend:

```bash
cd Frontend
npm install
npm start
```
