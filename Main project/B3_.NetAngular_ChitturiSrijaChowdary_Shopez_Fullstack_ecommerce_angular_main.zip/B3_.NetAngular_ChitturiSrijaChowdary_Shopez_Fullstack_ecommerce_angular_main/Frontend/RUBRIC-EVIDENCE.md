# ShopEZ Rubric Evidence

This file maps the submitted project to the evaluation rubric.

| Category | Evidence |
| --- | --- |
| Project Architecture & Design | Angular code is split into `components`, `pages`, `services`, `models`, `guards`, `interceptors`, and `validators`. Backend microservices are split under `Backend/ShopEZ/services` into `api-gateway`, `user-service`, `product-service`, `cart-service`, and `order-service`, each using controllers, services, repositories, DTOs, and models. |
| ASP.NET Core Web API Implementation | Each backend service exposes its own REST API. `product-service` exposes product catalog/search endpoints, `user-service` exposes auth endpoints, `cart-service` exposes cart endpoints, and `order-service` exposes order workflow/history endpoints. Controllers return HTTP results such as `Ok`, `Created`, `NotFound`, and validation/error responses. |
| Database Integration | `product-service` uses SQL Server through a Dapper repository and connection factory. The Docker Compose file includes a SQL Server container for the product database. Other services use repository abstractions so they remain independently testable. |
| Microservices Communication | `api-gateway/ShopEZ.ApiGateway` uses Ocelot routes for `/api/auth/*`, `/api/products/*`, `/api/cart/*`, and `/api/orders/*`. `order-service` communicates with `cart-service` through `Services__Cart=http://cart-service:8080` in `docker-compose.microservices.yml`. Angular uses `/api`, so it can call the gateway without UI changes. |
| Dapper Integration | `product-service/ShopEZ.ProductService/Repositories/DapperProductRepository.cs` uses Dapper for product listing, search/filtering, pagination, lookup, and creation. `DapperProductQueryTests.cs` validates important SQL query behavior. |
| Authentication & Security | Authentication logic is isolated in `user-service`. Angular stores/restores tokens and uses `auth.interceptor.ts` to attach bearer tokens automatically. |
| Docker & Deployment | `Backend/ShopEZ/services/docker-compose.microservices.yml` orchestrates API gateway, user service, product service, cart service, order service, and SQL Server. Each backend service has its own Dockerfile. `Backend/ShopEZ/services/README.md` also documents an Azure deployment option. |
| Unit Testing | Angular tests cover app creation, product cards, cart behavior, checkout guard, auth guard, product service, and payment service. Backend xUnit/Moq tests cover user auth, product catalog/controller behavior, Dapper queries, cart manager rules, and order workflow edge cases. |
| Code Quality & Best Practices | Shared models, typed services, standalone components, route guards, validation helpers, local-storage recovery, stock-limit checks, and centralized API logic keep behavior consistent. |
| Git & Version Control | Project is not currently inside a Git repository in this workspace. To satisfy this row during submission, initialize Git at the project root, commit source files, and include the repository link or commit history. |

## Verified Commands

```bash
cd Backend/ShopEZ/services
dotnet test ShopEZ.Microservices.sln --collect "XPlat Code Coverage"
cd Frontend
npm run build
npm test -- --watch=false
cd ../Backend/ShopEZ/services
docker compose -f docker-compose.microservices.yml up --build
```

Latest local verification:

- Backend microservice tests: 12 tests passed with coverage files generated.
- Frontend production build: succeeded.
- Frontend unit tests: 7 test files and 17 tests passed.
