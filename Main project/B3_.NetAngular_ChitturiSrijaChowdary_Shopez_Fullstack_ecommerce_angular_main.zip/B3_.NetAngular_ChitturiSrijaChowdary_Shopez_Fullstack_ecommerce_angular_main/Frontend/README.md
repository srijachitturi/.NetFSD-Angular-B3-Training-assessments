# ShopEZ Ecommerce Angular Mini Project

ShopEZ is a clean ecommerce mini project built with Angular 21. It connects to the ShopEZ ASP.NET Core Web API and covers the complete shopping flow: product browsing, search, filtering, cart management, checkout, demo payment, order placement, and admin product CRUD.

## Features

- Home page with featured products and category sections
- Enhanced product listing with search, category filters, rating filter, sort, and price range
- Product cards with image, category, stock status, price, and add-to-cart action
- Persistent cart using browser local storage
- Quantity update, remove item, stock-limit checks, and total calculation
- Checkout form with customer validation
- Demo payment gateway with Card, UPI, Net Banking, and Cash on Delivery modes
- Order success receipt with customer, payment, transaction, and ordered item details
- Secure login with customer/admin roles
- Admin screen for product add, edit, delete, and order viewing
- Footer with quick links, categories, and support links
- API fallback demo products when the backend is offline, so the UI remains presentable
- Responsive layout for desktop and mobile

## Tech Stack

- Angular 21
- TypeScript
- Angular state handling
- Angular Forms
- Angular HttpClient
- Lazy loaded Angular routes
- Route guards
- Automatic login token support for API requests
- ASP.NET Core Web API integration
- Vitest unit testing

## Project Structure

```text
src/app/
  components/product-card/   Reusable product card
  models/                    Product, cart, auth, order, and payment models
  guards/                    Checkout and authentication route guards
  interceptors/              Automatic login token support for API calls
  services/                  API, auth, cart, order, and payment services
  pages/                     Lazy route entry components
  app.html                   Main UI template
  app.css                    Main responsive styling
  app.ts                     Main application logic
```

## Backend API

The Angular app proxies `/api` requests to:

```text
http://localhost:5073
```

Start the backend first from the API folder:

```text
C:\Users\admin\Downloads\ShopEZ.Api
```

Typical command:

```bash
dotnet run --launch-profile http
```

If SQL Server is unavailable, update `C:\Users\admin\Downloads\ShopEZ.Api\appsettings.json` with your SQL Server or SQL Express connection string.

## Demo Logins

Customer:

```text
Email: srija@gmail.com
Password: Pass@123
```

Admin:

```text
Email: admin@gmail.com
Password: Admin@123
```

## Run Frontend

Install dependencies:

```bash
npm install
```

Start Angular:

```bash
npm start
```

Open:

```text
http://localhost:4200
```

## Docker Frontend Build

Build and run the Angular frontend container:

```bash
docker build -t shopez-frontend .
docker run --rm -p 4200:80 shopez-frontend
```

The nginx container serves Angular routes with SPA fallback and proxies `/api` calls to the `api-gateway` service for compose-based deployments.

## Docker Compose Deployment

Run the full container set from the `Frontend` folder:

```bash
docker compose up --build
```

Open:

```text
http://localhost:4200
```

Compose starts four services:

- `frontend`: Angular app served by nginx
- `api-gateway`: nginx gateway for `/api` traffic
- `shopez-api`: ASP.NET Core Web API
- `sqlserver`: SQL Server 2022 database

Communication paths covered for the microservices rubric:

- Gateway communication: browser -> `frontend` -> `api-gateway` -> `shopez-api`
- Direct service communication: `shopez-api` -> `sqlserver`

Fault-handling evidence:

- API SQL Server provider uses retry-on-failure.
- Containers have restart policies.
- Gateway has proxy timeouts and retries for transient upstream failures.

## Verify

Production build:

```bash
npm run build
```

Unit tests:

```bash
npm test -- --watch=false
```

Backend build:

```bash
cd ../Backend/ShopEZ
dotnet build
```

Project score checklist:

```text
RUBRIC-EVIDENCE.md
```

## Evaluation Checklist

- Build succeeds
- Unit tests pass: 7 spec files, 17 tests
- Lazy route chunks are generated for Home, Products, Cart, Checkout, Register, Admin, and Success routes
- Checkout route is protected from empty-cart navigation
- Login token is added automatically for API calls
- Admin product form has field-level validation and error messages
- Cart state is persisted safely with local storage recovery for invalid saved data
- Admin dashboard includes product metrics, inventory status, recent orders, and project readiness
- Product API integration works through proxy
- Cart and checkout flow works end to end
- Customer login can place orders
- Admin login can manage products
- Responsive UI works on mobile and desktop
- Demo can still show products if API is temporarily offline

## Git Submission Notes

Before uploading to GitHub, initialize Git from the project root and avoid committing generated files:

```bash
cd ..
git init
git add .
git commit -m "Complete ShopEZ full stack ecommerce project"
```

Keep `node_modules`, `dist`, `bin`, `obj`, logs, and local IDE files ignored.
