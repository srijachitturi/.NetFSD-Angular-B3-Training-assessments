import { isPlatformBrowser } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Injectable, PLATFORM_ID, computed, inject, signal } from '@angular/core';
import { Observable, tap } from 'rxjs';
import { LoginRequest, LoginResponse, RegisterRequest, UserSummary } from '../models/auth.model';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly http = inject(HttpClient);
  private readonly platformId = inject(PLATFORM_ID);
  private readonly isBrowser = isPlatformBrowser(this.platformId);
  private readonly apiBase = this.isBrowser ? '/api' : 'http://localhost:5073/api';
  private readonly tokenKey = 'shopez_token';
  private readonly userIdKey = 'shopez_user_id';
  private readonly userKey = 'shopez_user';
  private readonly emailKey = 'shopez_email';
  private readonly roleKey = 'shopez_role';

  readonly token = signal('');
  readonly userId = signal(0);
  readonly userName = signal('');
  readonly email = signal('');
  readonly role = signal('');
  readonly isAdmin = computed(() => this.role() === 'Admin');
  readonly isHigherAdmin = computed(() => this.email().toLowerCase() === 'admin@gmail.com');
  readonly isLoggedIn = computed(() => Boolean(this.token()));

  restoreSession(): void {
    if (!this.isBrowser) return;
    this.token.set(localStorage.getItem(this.tokenKey) ?? '');
    this.userId.set(Number(localStorage.getItem(this.userIdKey) ?? 0));
    this.userName.set(localStorage.getItem(this.userKey) ?? '');
    this.email.set(localStorage.getItem(this.emailKey) ?? '');
    this.role.set(localStorage.getItem(this.roleKey) ?? '');
  }

  login(credentials: LoginRequest): Observable<LoginResponse> {
    return this.http.post<LoginResponse>(`${this.apiBase}/Auth/login`, credentials).pipe(
      tap((response) => this.storeSession(response))
    );
  }

  register(details: RegisterRequest): Observable<LoginResponse> {
    return this.http.post<LoginResponse>(`${this.apiBase}/Auth/register`, details).pipe(
      tap((response) => this.storeSession(response))
    );
  }

  getUsers(headers: Record<string, string>): Observable<UserSummary[]> {
    return this.http.get<UserSummary[]>(`${this.apiBase}/Auth/users`, { headers });
  }

  promoteUser(userId: number, headers: Record<string, string>): Observable<UserSummary> {
    return this.http.post<UserSummary>(`${this.apiBase}/Auth/users/${userId}/promote`, {}, { headers });
  }

  demoteAdmin(userId: number, headers: Record<string, string>): Observable<UserSummary> {
    return this.http.post<UserSummary>(`${this.apiBase}/Auth/users/${userId}/demote`, {}, { headers });
  }

  logout(): void {
    this.token.set('');
    this.userId.set(0);
    this.userName.set('');
    this.email.set('');
    this.role.set('');
    if (this.isBrowser) {
      localStorage.removeItem(this.tokenKey);
      localStorage.removeItem(this.userIdKey);
      localStorage.removeItem(this.userKey);
      localStorage.removeItem(this.emailKey);
      localStorage.removeItem(this.roleKey);
    }
  }

  authHeaders(): Record<string, string> {
    return { Authorization: `Bearer ${this.token()}` };
  }

  private storeSession(response: LoginResponse): void {
    this.token.set(response.token);
    this.userId.set(response.userId);
    this.userName.set(response.user);
    this.email.set(response.email);
    this.role.set(response.role);
    if (!this.isBrowser) return;
    localStorage.setItem(this.tokenKey, response.token);
    localStorage.setItem(this.userIdKey, String(response.userId));
    localStorage.setItem(this.userKey, response.user);
    localStorage.setItem(this.emailKey, response.email);
    localStorage.setItem(this.roleKey, response.role);
  }
}
