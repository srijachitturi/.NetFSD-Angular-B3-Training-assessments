import { TestBed } from '@angular/core/testing';
import { firstValueFrom } from 'rxjs';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { PaymentDetails } from '../models/payment.model';
import { PaymentService } from './payment.service';

describe('PaymentService', () => {
  let service: PaymentService;
  let http: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()]
    });
    service = TestBed.inject(PaymentService);
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => http.verify());

  it('returns a successful receipt for card payments', async () => {
    const payment: PaymentDetails = {
      method: 'card',
      cardName: 'Srija',
      cardNumber: '4111111111111111',
      expiry: '12/30',
      cvv: '123',
      upiId: '',
      bank: 'State Bank of India'
    };

    const receiptPromise = firstValueFrom(service.processPayment(payment, 2499, 1, { Authorization: 'Bearer token' }));
    const request = http.expectOne('/api/payment');
    request.flush({
      method: 'card',
      transactionId: 'TXN-1',
      createdAtUtc: new Date().toISOString(),
      status: 'Payment successful',
      amount: 2499
    });

    const receipt = await receiptPromise;

    expect(receipt.status).toBe('Payment successful');
    expect(receipt.method).toBe('Credit / Debit Card');
    expect(receipt.transactionId).toContain('TXN-');
    expect(receipt.amount).toBe(2499);
  });

  it('marks cash on delivery receipts as payable later', async () => {
    const payment: PaymentDetails = {
      method: 'cod',
      cardName: '',
      cardNumber: '',
      expiry: '',
      cvv: '',
      upiId: '',
      bank: ''
    };

    const receiptPromise = firstValueFrom(service.processPayment(payment, 799, 1, { Authorization: 'Bearer token' }));
    const request = http.expectOne('/api/payment');
    request.flush({
      method: 'cod',
      transactionId: 'COD-1',
      createdAtUtc: new Date().toISOString(),
      status: 'Payable on delivery',
      amount: 799
    });

    const receipt = await receiptPromise;

    expect(receipt.status).toBe('Payable on delivery');
    expect(receipt.transactionId).toContain('COD-');
  });
});
