import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { ProductService } from './product.service';

describe('ProductService', () => {
  let service: ProductService;
  let http: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()]
    });
    service = TestBed.inject(ProductService);
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    http.verify();
  });

  it('loads, normalizes, categorizes, and de-duplicates API products', () => {
    service.loadProducts().subscribe();

    const request = http.expectOne('/api/Products');
    request.flush([
      {
        productId: 12,
        name: 'Bluetooth Speaker',
        description: 'Portable speaker with deep bass',
        price: 1999,
        imageUrl: 'https://images.unsplash.com/photo-1',
        stock: 6
      },
      {
        productId: 13,
        name: 'Bluetooth Speaker',
        description: 'Duplicate product',
        price: 2999,
        imageUrl: '',
        stock: 2
      },
      {
        productId: 14,
        name: 'Tumbler',
        description: 'Hidden test product',
        price: 499,
        imageUrl: '',
        stock: 1
      }
    ]);

    expect(service.products().length).toBe(1);
    expect(service.products()[0]).toMatchObject({
      id: 12,
      name: 'Bluetooth Speaker',
      category: 'Audio',
      price: 1999,
      stock: 6
    });
    expect(service.products()[0].image).toContain('?auto=format&fit=crop&w=900&q=80');
    expect(service.usingFallback()).toBe(false);
    expect(service.loading()).toBe(false);
  });

  it('uses fallback products when the API fails', () => {
    service.loadProducts().subscribe({ error: () => undefined });

    const request = http.expectOne('/api/Products');
    request.flush('Server down', { status: 500, statusText: 'Server Error' });

    expect(service.products().length).toBeGreaterThan(0);
    expect(service.usingFallback()).toBe(true);
    expect(service.loading()).toBe(false);
  });

  it('converts UI products to API write DTOs', () => {
    const dto = service.toWriteDto({
      id: 5,
      name: 'Mechanical Keyboard',
      category: 'Electronics',
      description: 'Compact keyboard',
      price: 2499,
      image: 'assets/keyboard.jpg',
      stock: 8,
      rating: 4.5
    });

    expect(dto).toEqual({
      name: 'Mechanical Keyboard',
      category: 'Electronics',
      description: 'Compact keyboard',
      price: 2499,
      imageUrl: 'assets/keyboard.jpg',
      stock: 8
    });
  });
});
