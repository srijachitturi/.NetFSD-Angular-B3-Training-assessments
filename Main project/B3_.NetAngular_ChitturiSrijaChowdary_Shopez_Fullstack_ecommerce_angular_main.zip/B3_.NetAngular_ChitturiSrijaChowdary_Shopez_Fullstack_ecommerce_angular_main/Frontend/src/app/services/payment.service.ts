import { HttpClient } from '@angular/common/http';
import { isPlatformBrowser } from '@angular/common';
import { Injectable, PLATFORM_ID, inject } from '@angular/core';
import { Observable, map } from 'rxjs';
import { PaymentDetails, PaymentReceipt } from '../models/payment.model';

@Injectable({ providedIn: 'root' })
export class PaymentService {
  private readonly platformId = inject(PLATFORM_ID);
  private readonly apiBase = isPlatformBrowser(this.platformId) ? '/api' : 'http://localhost:5073/api';
  private readonly apiUrl = `${this.apiBase}/payment`;

  constructor(private readonly http: HttpClient) {}

  processPayment(payment: PaymentDetails, amount: number, userId: number, headers: Record<string, string>): Observable<PaymentReceipt> {
    const methodLabels: Record<string, string> = {
      card: 'Credit / Debit Card',
      upi: 'UPI',
      netbanking: 'Net Banking',
      cod: 'Cash on Delivery'
    };

    return this.http.post<{
      transactionId: string;
      amount: number;
      method: string;
      status: string;
      createdAtUtc: string;
    }>(this.apiUrl, { userId, orderId: 0, amount, method: payment.method }, { headers }).pipe(
      map((receipt) => ({
        method: methodLabels[payment.method] ?? receipt.method,
        transactionId: receipt.transactionId,
        paidAt: new Date(receipt.createdAtUtc).toLocaleString('en-IN'),
        status: receipt.status,
        amount: receipt.amount
      }))
    );
  }
}
