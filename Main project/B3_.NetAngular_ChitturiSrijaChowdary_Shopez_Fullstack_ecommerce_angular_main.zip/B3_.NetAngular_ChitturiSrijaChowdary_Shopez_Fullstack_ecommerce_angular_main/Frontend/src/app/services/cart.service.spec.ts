import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { Product } from '../models/product.model';
import { CartService } from './cart.service';

describe('CartService', () => {
  const product: Product = {
    id: 10,
    name: 'USB-C Charger',
    category: 'Accessories',
    description: 'Fast charger',
    price: 999,
    image: 'assets/charger.jpg',
    stock: 2
  };

  let service: CartService;
  let http: HttpTestingController;

  beforeEach(() => {
    localStorage.clear();
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()]
    });
    service = TestBed.inject(CartService);
    http = TestBed.inject(HttpTestingController);
    service.clearCart();
  });

  afterEach(() => {
    http.verify();
    localStorage.clear();
  });

  it('adds products and keeps derived cart totals in sync', () => {
    expect(service.addToCart(product)).toBe('added');
    expect(service.addToCart(product)).toBe('added');

    expect(service.cartCount()).toBe(2);
    expect(service.cartTotal()).toBe(1998);
    expect(service.cart()[0].quantity).toBe(2);
  });

  it('prevents adding beyond product stock', () => {
    service.addToCart(product);
    service.addToCart(product);

    expect(service.addToCart(product)).toBe('stock-limit');
    expect(service.cartCount()).toBe(2);
  });

  it('rejects out-of-stock products', () => {
    expect(service.addToCart({ ...product, stock: 0 })).toBe('out-of-stock');
    expect(service.cart()).toEqual([]);
  });

  it('removes invalid saved cart JSON instead of crashing restore', () => {
    localStorage.setItem('shopez_cart', '{bad json');

    service.restoreCart();

    expect(service.cart()).toEqual([]);
    expect(localStorage.getItem('shopez_cart')).toBeNull();
  });

  it('syncs cart items through the gateway', () => {
    service.syncCart(1, [{ ...product, quantity: 2 }], { Authorization: 'Bearer token' }).subscribe();

    const request = http.expectOne('/api/cart');
    expect(request.request.method).toBe('POST');
    expect(request.request.body).toMatchObject({
      userId: 1,
      productId: 10,
      productName: 'USB-C Charger',
      quantity: 2,
      price: 999
    });
    request.flush([]);
  });
});
