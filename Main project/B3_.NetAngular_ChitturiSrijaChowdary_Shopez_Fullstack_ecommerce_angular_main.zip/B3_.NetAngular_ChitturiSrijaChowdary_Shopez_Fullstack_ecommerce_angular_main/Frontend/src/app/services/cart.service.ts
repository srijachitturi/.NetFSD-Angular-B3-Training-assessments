import { isPlatformBrowser } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Injectable, PLATFORM_ID, computed, inject, signal } from '@angular/core';
import { Observable, forkJoin, of } from 'rxjs';
import { CartItem } from '../models/cart.model';
import { Product } from '../models/product.model';

@Injectable({ providedIn: 'root' })
export class CartService {
  private readonly platformId = inject(PLATFORM_ID);
  private readonly isBrowser = isPlatformBrowser(this.platformId);
  private readonly http = inject(HttpClient);
  private readonly apiBase = this.isBrowser ? '/api' : 'http://localhost:5073/api';
  private readonly cartKey = 'shopez_cart';

  readonly cart = signal<CartItem[]>([]);
  readonly cartCount = computed(() => this.cart().reduce((total, item) => total + item.quantity, 0));
  readonly cartTotal = computed(() => this.cart().reduce((total, item) => total + item.price * item.quantity, 0));

  restoreCart(): void {
    if (!this.isBrowser) return;
    const raw = localStorage.getItem(this.cartKey);
    if (!raw) {
      this.cart.set([]);
      return;
    }

    try {
      const parsed = JSON.parse(raw) as CartItem[];
      this.cart.set(Array.isArray(parsed) ? parsed : []);
    } catch {
      localStorage.removeItem(this.cartKey);
      this.cart.set([]);
    }
  }

  addToCart(product: Product): 'added' | 'out-of-stock' | 'stock-limit' {
    if (product.stock === 0) return 'out-of-stock';

    const cart = [...this.cart()];
    const existing = cart.find((item) => item.id === product.id);
    if (existing) {
      if (existing.quantity >= product.stock) return 'stock-limit';
      existing.quantity += 1;
    } else {
      cart.push({ ...product, quantity: 1 });
    }

    this.saveCart(cart);
    return 'added';
  }

  updateQuantity(productId: number, change: number): 'updated' | 'removed' | 'stock-limit' | 'missing' {
    const cart = [...this.cart()];
    const item = cart.find((cartItem) => cartItem.id === productId);
    if (!item) return 'missing';

    const quantity = item.quantity + change;
    if (quantity <= 0) {
      this.removeFromCart(productId);
      return 'removed';
    }
    if (quantity > item.stock) return 'stock-limit';

    item.quantity = quantity;
    this.saveCart(cart);
    return 'updated';
  }

  removeFromCart(productId: number): void {
    this.saveCart(this.cart().filter((item) => item.id !== productId));
  }

  clearCart(): void {
    this.saveCart([]);
  }

  syncCart(userId: number, items: CartItem[], headers: Record<string, string>): Observable<unknown[]> {
    if (!items.length) return of([]);

    return forkJoin(
      items.map((item) =>
        this.http.post(`${this.apiBase}/cart`, {
          userId,
          productId: item.id,
          productName: item.name,
          quantity: item.quantity,
          price: item.price
        }, { headers })
      )
    );
  }

  private saveCart(cart: CartItem[]): void {
    this.cart.set(cart);
    if (this.isBrowser) {
      localStorage.setItem(this.cartKey, JSON.stringify(cart));
    }
  }
}
