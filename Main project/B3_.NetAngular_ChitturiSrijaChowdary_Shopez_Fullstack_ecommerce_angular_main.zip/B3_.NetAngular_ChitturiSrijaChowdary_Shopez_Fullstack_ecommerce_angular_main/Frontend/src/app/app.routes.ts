import { Routes } from '@angular/router';
import { checkoutGuard } from './guards/checkout.guard';

export const routes: Routes = [
  {
    path: '',
    loadComponent: () => import('./pages/home/home.component').then((component) => component.HomeComponent),
    title: 'ShopEZ'
  },
  {
    path: 'products',
    loadComponent: () => import('./pages/products/products.component').then((component) => component.ProductsComponent),
    title: 'Products | ShopEZ'
  },
  {
    path: 'cart',
    loadComponent: () => import('./pages/cart/cart.component').then((component) => component.CartComponent),
    title: 'Cart | ShopEZ'
  },
  {
    path: 'checkout',
    canActivate: [checkoutGuard],
    loadComponent: () => import('./pages/checkout/checkout.component').then((component) => component.CheckoutComponent),
    title: 'Checkout | ShopEZ'
  },
  {
    path: 'login',
    loadComponent: () => import('./pages/login/login.component').then((component) => component.LoginComponent),
    title: 'Login | ShopEZ'
  },
  {
    path: 'register',
    loadComponent: () => import('./pages/register/register.component').then((component) => component.RegisterComponent),
    title: 'Register | ShopEZ'
  },
  {
    path: 'admin',
    loadComponent: () => import('./pages/admin/admin.component').then((component) => component.AdminComponent),
    title: 'Admin | ShopEZ'
  },
  {
    path: 'success',
    loadComponent: () => import('./pages/orders/orders.component').then((component) => component.OrdersComponent),
    title: 'Order Confirmed | ShopEZ'
  },
  { path: '**', redirectTo: '' }
];
