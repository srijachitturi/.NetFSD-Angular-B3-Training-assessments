import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { CartService } from '../services/cart.service';

export const checkoutGuard: CanActivateFn = () => {
  const cart = inject(CartService);
  const router = inject(Router);

  cart.restoreCart();

  return cart.cartCount() > 0 ? true : router.createUrlTree(['/cart']);
};
