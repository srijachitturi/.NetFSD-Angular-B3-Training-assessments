import { TestBed } from '@angular/core/testing';
import { provideRouter, Router, UrlTree } from '@angular/router';
import { Product } from '../models/product.model';
import { CartService } from '../services/cart.service';
import { checkoutGuard } from './checkout.guard';

describe('checkoutGuard', () => {
  const product: Product = {
    id: 1,
    name: 'Wireless Mouse',
    category: 'Electronics',
    description: 'Mouse',
    price: 799,
    image: 'assets/mouse.jpg',
    stock: 5
  };

  beforeEach(() => {
    localStorage.clear();
    TestBed.configureTestingModule({
      providers: [provideRouter([])]
    });
  });

  afterEach(() => {
    localStorage.clear();
  });

  it('redirects checkout navigation when the cart is empty', () => {
    const result = TestBed.runInInjectionContext(() => checkoutGuard({} as never, {} as never));

    expect(result instanceof UrlTree).toBe(true);
    expect(TestBed.inject(Router).serializeUrl(result as UrlTree)).toBe('/cart');
  });

  it('allows checkout navigation when cart has items', () => {
    TestBed.inject(CartService).addToCart(product);

    const result = TestBed.runInInjectionContext(() => checkoutGuard({} as never, {} as never));

    expect(result).toBe(true);
  });
});
