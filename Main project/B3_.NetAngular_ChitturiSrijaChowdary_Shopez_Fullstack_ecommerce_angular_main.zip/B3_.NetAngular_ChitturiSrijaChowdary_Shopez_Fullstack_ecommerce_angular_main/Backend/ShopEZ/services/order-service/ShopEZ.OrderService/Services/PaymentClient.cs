using System.Net.Http.Headers;

namespace ShopEZ.OrderService.Services;

public sealed class PaymentClient(HttpClient httpClient, IHttpContextAccessor httpContextAccessor) : IPaymentClient
{
    public async Task<PaymentSnapshot> ProcessAsync(int userId, int orderId, decimal amount, string paymentMethod)
    {
        var token = httpContextAccessor.HttpContext?.Request.Headers.Authorization.ToString();
        if (!string.IsNullOrWhiteSpace(token))
        {
            httpClient.DefaultRequestHeaders.Authorization = AuthenticationHeaderValue.Parse(token);
        }

        var response = await httpClient.PostAsJsonAsync("/api/payment", new
        {
            userId,
            orderId,
            amount,
            method = paymentMethod
        });

        response.EnsureSuccessStatusCode();
        return await response.Content.ReadFromJsonAsync<PaymentSnapshot>() ??
               throw new InvalidOperationException("Payment service returned an empty response.");
    }
}
