namespace ShopEZ.OrderService.Services;

public interface IPaymentClient
{
    Task<PaymentSnapshot> ProcessAsync(int userId, int orderId, decimal amount, string paymentMethod);
}

public sealed record PaymentSnapshot(string TransactionId, string Status, decimal Amount);
