namespace ShopEZ.OrderService.Services;

public interface ICartClient
{
    Task<IReadOnlyList<CartItemSnapshot>> GetCartItemsAsync(int userId);
}

public sealed record CartItemSnapshot(int ProductId, string ProductName, int Quantity, decimal Price);
