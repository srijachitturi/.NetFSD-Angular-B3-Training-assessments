using System.ComponentModel.DataAnnotations;

namespace ShopEZ.OrderService.DTOs;

public sealed class CreateOrderDto
{
    [Range(1, int.MaxValue)]
    public int UserId { get; set; }

    [Required, StringLength(30)]
    public string PaymentMethod { get; set; } = "cod";
}

public sealed record OrderItemDto(int ProductId, string ProductName, int Quantity, decimal Price);

public sealed record OrderReadDto(
    int OrderId,
    int UserId,
    DateTime CreatedAtUtc,
    decimal TotalAmount,
    string PaymentStatus,
    string TransactionId,
    IReadOnlyList<OrderItemDto> Items);
