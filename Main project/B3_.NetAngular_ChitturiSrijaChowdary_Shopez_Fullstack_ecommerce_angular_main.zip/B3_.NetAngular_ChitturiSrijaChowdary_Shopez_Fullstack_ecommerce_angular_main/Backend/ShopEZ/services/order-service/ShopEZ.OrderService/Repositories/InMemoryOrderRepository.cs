using ShopEZ.OrderService.Models;

namespace ShopEZ.OrderService.Repositories;

public sealed class InMemoryOrderRepository : IOrderRepository
{
    private readonly List<Order> _orders = [];
    private int _nextId;

    public Task<Order> CreateAsync(Order order)
    {
        order.OrderId = Interlocked.Increment(ref _nextId);
        _orders.Add(order);
        return Task.FromResult(order);
    }

    public Task<IReadOnlyList<Order>> GetByUserAsync(int userId) =>
        Task.FromResult<IReadOnlyList<Order>>(_orders.Where(o => o.UserId == userId).ToList());
}
