using Microsoft.AspNetCore.Mvc;
using ShopEZ.OrderService.DTOs;
using ShopEZ.OrderService.Services;

namespace ShopEZ.OrderService.Controllers;

[ApiController]
[Route("api/orders")]
public sealed class OrdersController(IOrderWorkflowService orderService) : ControllerBase
{
    [HttpPost]
    public async Task<IActionResult> Create(CreateOrderDto dto)
    {
        if (!ModelState.IsValid)
        {
            return ValidationProblem(ModelState);
        }

        try
        {
            var order = await orderService.CreateAsync(dto);
            return CreatedAtAction(nameof(GetByUser), new { userId = order.UserId }, order);
        }
        catch (InvalidOperationException ex)
        {
            return BadRequest(new { message = ex.Message });
        }
    }

    [HttpGet("user/{userId:int}")]
    public async Task<IActionResult> GetByUser(int userId) =>
        Ok(await orderService.GetByUserAsync(userId));
}
