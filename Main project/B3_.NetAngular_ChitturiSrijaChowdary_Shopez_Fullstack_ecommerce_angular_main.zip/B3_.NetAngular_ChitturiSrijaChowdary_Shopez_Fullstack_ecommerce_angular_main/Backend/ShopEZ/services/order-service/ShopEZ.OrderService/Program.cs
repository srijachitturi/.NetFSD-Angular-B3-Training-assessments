using ShopEZ.OrderService.Repositories;
using ShopEZ.OrderService.Security;
using ShopEZ.OrderService.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddCors(options => options.AddPolicy("Angular", policy =>
    policy.AllowAnyHeader().AllowAnyMethod().WithOrigins(
        builder.Configuration["Cors:AngularOrigin"] ?? "http://localhost:4200")));
builder.Services.AddSingleton<IOrderRepository, InMemoryOrderRepository>();
builder.Services.AddSingleton<JwtTokenValidator>();
builder.Services.AddHttpContextAccessor();
builder.Services.AddHttpClient<ICartClient, CartClient>(client =>
{
    client.BaseAddress = new Uri(builder.Configuration["Services:Cart"] ?? "http://cart-service:8080");
});
builder.Services.AddHttpClient<IPaymentClient, PaymentClient>(client =>
{
    client.BaseAddress = new Uri(builder.Configuration["Services:Payment"] ?? "http://payment-service:8080");
});
builder.Services.AddScoped<IOrderWorkflowService, OrderWorkflowService>();

var app = builder.Build();

app.UseExceptionHandler(errorApp => errorApp.Run(async context =>
{
    context.Response.StatusCode = StatusCodes.Status500InternalServerError;
    await context.Response.WriteAsJsonAsync(new { message = "An unexpected order service error occurred." });
}));
app.UseStatusCodePages(async context =>
{
    if (context.HttpContext.Response.StatusCode == StatusCodes.Status404NotFound)
    {
        await context.HttpContext.Response.WriteAsJsonAsync(new { message = "Order endpoint was not found." });
    }
});

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseCors("Angular");
app.Use(async (context, next) =>
{
    if (HttpMethods.IsPost(context.Request.Method) &&
        context.Request.Path.StartsWithSegments("/api/orders") &&
        !context.RequestServices.GetRequiredService<JwtTokenValidator>().IsValid(context.Request.Headers.Authorization))
    {
        context.Response.StatusCode = StatusCodes.Status401Unauthorized;
        await context.Response.WriteAsJsonAsync(new { message = "A valid JWT bearer token is required." });
        return;
    }

    await next();
});

app.MapGet("/health", () => Results.Ok(new { service = "order-service", status = "healthy" }));
app.MapControllers();

app.Run();

public partial class Program { }
