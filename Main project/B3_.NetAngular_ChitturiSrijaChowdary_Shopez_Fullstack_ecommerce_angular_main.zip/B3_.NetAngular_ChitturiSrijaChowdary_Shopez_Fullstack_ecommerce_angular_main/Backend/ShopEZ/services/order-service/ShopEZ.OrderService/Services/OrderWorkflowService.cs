using ShopEZ.OrderService.DTOs;
using ShopEZ.OrderService.Models;
using ShopEZ.OrderService.Repositories;

namespace ShopEZ.OrderService.Services;

public sealed class OrderWorkflowService(
    IOrderRepository orders,
    ICartClient cartClient,
    IPaymentClient paymentClient,
    ILogger<OrderWorkflowService> logger) : IOrderWorkflowService
{
    public async Task<OrderReadDto> CreateAsync(CreateOrderDto dto)
    {
        var cartItems = await cartClient.GetCartItemsAsync(dto.UserId);
        if (cartItems.Count == 0)
        {
            throw new InvalidOperationException("Cannot create an order from an empty cart.");
        }

        var order = await orders.CreateAsync(new Order
        {
            UserId = dto.UserId,
            Items = cartItems.Select(i => new OrderItem
            {
                ProductId = i.ProductId,
                ProductName = i.ProductName,
                Quantity = i.Quantity,
                Price = i.Price
            }).ToList(),
            TotalAmount = cartItems.Sum(i => i.Price * i.Quantity)
        });

        var payment = await paymentClient.ProcessAsync(order.UserId, order.OrderId, order.TotalAmount, dto.PaymentMethod);
        logger.LogInformation("Order {OrderId} created with payment transaction {TransactionId}", order.OrderId, payment.TransactionId);

        return Map(order, payment);
    }

    public async Task<IReadOnlyList<OrderReadDto>> GetByUserAsync(int userId)
    {
        var userOrders = await orders.GetByUserAsync(userId);
        return userOrders.Select(order => Map(order, new PaymentSnapshot(string.Empty, "Payment status available from payment service", order.TotalAmount))).ToList();
    }

    private static OrderReadDto Map(Order order, PaymentSnapshot payment) =>
        new(order.OrderId, order.UserId, order.CreatedAtUtc, order.TotalAmount, payment.Status, payment.TransactionId,
            order.Items.Select(i => new OrderItemDto(i.ProductId, i.ProductName, i.Quantity, i.Price)).ToList());
}
