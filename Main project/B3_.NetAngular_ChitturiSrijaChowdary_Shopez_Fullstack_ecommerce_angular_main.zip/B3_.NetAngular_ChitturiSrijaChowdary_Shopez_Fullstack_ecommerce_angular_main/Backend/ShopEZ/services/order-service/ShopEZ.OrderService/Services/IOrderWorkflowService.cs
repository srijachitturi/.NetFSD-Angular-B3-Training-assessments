using ShopEZ.OrderService.DTOs;

namespace ShopEZ.OrderService.Services;

public interface IOrderWorkflowService
{
    Task<OrderReadDto> CreateAsync(CreateOrderDto dto);
    Task<IReadOnlyList<OrderReadDto>> GetByUserAsync(int userId);
}
