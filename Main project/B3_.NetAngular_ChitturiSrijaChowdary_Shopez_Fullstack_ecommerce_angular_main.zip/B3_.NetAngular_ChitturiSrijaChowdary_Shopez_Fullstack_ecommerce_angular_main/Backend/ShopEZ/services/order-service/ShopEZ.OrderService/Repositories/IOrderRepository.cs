using ShopEZ.OrderService.Models;

namespace ShopEZ.OrderService.Repositories;

public interface IOrderRepository
{
    Task<Order> CreateAsync(Order order);
    Task<IReadOnlyList<Order>> GetByUserAsync(int userId);
}
