namespace ShopEZ.OrderService.Services;

public sealed class CartClient(HttpClient httpClient) : ICartClient
{
    public async Task<IReadOnlyList<CartItemSnapshot>> GetCartItemsAsync(int userId)
    {
        var items = await httpClient.GetFromJsonAsync<IReadOnlyList<CartItemSnapshot>>($"/api/cart/{userId}");
        return items ?? [];
    }
}
