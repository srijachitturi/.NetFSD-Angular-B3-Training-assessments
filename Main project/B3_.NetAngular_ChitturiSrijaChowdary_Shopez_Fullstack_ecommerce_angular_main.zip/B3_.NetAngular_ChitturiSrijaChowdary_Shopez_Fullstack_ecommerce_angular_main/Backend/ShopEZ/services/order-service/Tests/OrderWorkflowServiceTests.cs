using Moq;
using Microsoft.Extensions.Logging.Abstractions;
using ShopEZ.OrderService.DTOs;
using ShopEZ.OrderService.Models;
using ShopEZ.OrderService.Repositories;
using ShopEZ.OrderService.Services;

namespace ShopEZ.OrderService.Tests;

public sealed class OrderWorkflowServiceTests
{
    [Fact]
    public async Task CreateAsync_EmptyCart_Throws()
    {
        var orders = new Mock<IOrderRepository>();
        var cart = new Mock<ICartClient>();
        var payment = new Mock<IPaymentClient>();
        cart.Setup(c => c.GetCartItemsAsync(1)).ReturnsAsync([]);

        var service = new OrderWorkflowService(orders.Object, cart.Object, payment.Object, NullLogger<OrderWorkflowService>.Instance);

        await Assert.ThrowsAsync<InvalidOperationException>(() => service.CreateAsync(new CreateOrderDto { UserId = 1 }));
    }

    [Fact]
    public async Task CreateAsync_WithCartItems_CalculatesTotal()
    {
        var orders = new Mock<IOrderRepository>();
        var cart = new Mock<ICartClient>();
        var payment = new Mock<IPaymentClient>();
        cart.Setup(c => c.GetCartItemsAsync(1)).ReturnsAsync([new CartItemSnapshot(2, "Phone", 2, 100)]);
        orders.Setup(o => o.CreateAsync(It.IsAny<Order>()))
            .ReturnsAsync((Order order) =>
            {
                order.OrderId = 10;
                return order;
            });
        payment.Setup(p => p.ProcessAsync(1, 10, 200, "cod"))
            .ReturnsAsync(new PaymentSnapshot("COD-1", "Payable on delivery", 200));

        var service = new OrderWorkflowService(orders.Object, cart.Object, payment.Object, NullLogger<OrderWorkflowService>.Instance);
        var result = await service.CreateAsync(new CreateOrderDto { UserId = 1 });

        Assert.Equal(200, result.TotalAmount);
        Assert.Equal(10, result.OrderId);
        Assert.Equal("COD-1", result.TransactionId);
    }
}
