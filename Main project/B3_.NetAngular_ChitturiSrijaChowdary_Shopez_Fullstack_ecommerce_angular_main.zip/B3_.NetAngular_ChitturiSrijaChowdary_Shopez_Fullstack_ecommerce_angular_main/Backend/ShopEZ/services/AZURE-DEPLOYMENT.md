# ShopEZ Azure Deployment Guide

This project can be deployed to Azure Container Apps using Azure Container Registry for images and Azure SQL Database for the product database.

## 1. Prerequisites

- Azure CLI installed
- Docker running locally
- Azure subscription access

Login:

```bash
az login
```

Set common names:

```bash
RG=shopez-rg
LOCATION=centralindia
ACR=shopezregistry$RANDOM
ENV=shopez-env
SQLSERVER=shopez-sql-$RANDOM
SQLDB=ShopEZProductDb
SQLUSER=sqladmin
SQLPASS='ShopEZ@12345Strong'
```

## 2. Create Azure Resources

```bash
az group create --name $RG --location $LOCATION
az acr create --resource-group $RG --name $ACR --sku Basic --admin-enabled true
az containerapp env create --name $ENV --resource-group $RG --location $LOCATION
```

Create Azure SQL:

```bash
az sql server create --name $SQLSERVER --resource-group $RG --location $LOCATION --admin-user $SQLUSER --admin-password $SQLPASS
az sql db create --resource-group $RG --server $SQLSERVER --name $SQLDB --service-objective Basic
az sql server firewall-rule create --resource-group $RG --server $SQLSERVER --name AllowAzureServices --start-ip-address 0.0.0.0 --end-ip-address 0.0.0.0
```

Create the `Products` table in `ShopEZProductDb` before testing the Product Service:

```sql
CREATE TABLE Products (
    ProductId INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(100) NOT NULL,
    Description NVARCHAR(500) NOT NULL,
    Price DECIMAL(18,2) NOT NULL,
    ImageUrl NVARCHAR(1000) NOT NULL,
    Stock INT NOT NULL
);

INSERT INTO Products (Name, Description, Price, ImageUrl, Stock)
VALUES
('Wireless Mouse', 'Ergonomic wireless mouse with USB receiver.', 799, 'https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?auto=format&fit=crop&w=900&q=80', 25),
('Mechanical Keyboard', 'Compact keyboard with backlight and tactile keys.', 2499, 'https://images.unsplash.com/photo-1511467687858-23d96c32e4ae?auto=format&fit=crop&w=900&q=80', 18);
```

## 3. Build And Push Images

Run from `Backend/ShopEZ/services`:

```bash
az acr build --registry $ACR --image shopez-api-gateway:latest --file api-gateway/ShopEZ.ApiGateway/Dockerfile .
az acr build --registry $ACR --image shopez-user-service:latest --file user-service/ShopEZ.UserService/Dockerfile .
az acr build --registry $ACR --image shopez-product-service:latest --file product-service/ShopEZ.ProductService/Dockerfile .
az acr build --registry $ACR --image shopez-cart-service:latest --file cart-service/ShopEZ.CartService/Dockerfile .
az acr build --registry $ACR --image shopez-order-service:latest --file order-service/ShopEZ.OrderService/Dockerfile .
```

## 4. Deploy Internal Services

```bash
ACR_LOGIN_SERVER=$(az acr show --name $ACR --query loginServer --output tsv)
ACR_USER=$(az acr credential show --name $ACR --query username --output tsv)
ACR_PASS=$(az acr credential show --name $ACR --query passwords[0].value --output tsv)
PRODUCT_DB="Server=tcp:$SQLSERVER.database.windows.net,1433;Initial Catalog=$SQLDB;Persist Security Info=False;User ID=$SQLUSER;Password=$SQLPASS;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;"
```

```bash
az containerapp create --name user-service --resource-group $RG --environment $ENV --image $ACR_LOGIN_SERVER/shopez-user-service:latest --registry-server $ACR_LOGIN_SERVER --registry-username $ACR_USER --registry-password $ACR_PASS --target-port 8080 --ingress internal --env-vars ASPNETCORE_URLS=http://+:8080

az containerapp create --name product-service --resource-group $RG --environment $ENV --image $ACR_LOGIN_SERVER/shopez-product-service:latest --registry-server $ACR_LOGIN_SERVER --registry-username $ACR_USER --registry-password $ACR_PASS --target-port 8080 --ingress internal --env-vars ASPNETCORE_URLS=http://+:8080 ConnectionStrings__ProductDb="$PRODUCT_DB"

az containerapp create --name cart-service --resource-group $RG --environment $ENV --image $ACR_LOGIN_SERVER/shopez-cart-service:latest --registry-server $ACR_LOGIN_SERVER --registry-username $ACR_USER --registry-password $ACR_PASS --target-port 8080 --ingress internal --env-vars ASPNETCORE_URLS=http://+:8080

az containerapp create --name order-service --resource-group $RG --environment $ENV --image $ACR_LOGIN_SERVER/shopez-order-service:latest --registry-server $ACR_LOGIN_SERVER --registry-username $ACR_USER --registry-password $ACR_PASS --target-port 8080 --ingress internal --env-vars ASPNETCORE_URLS=http://+:8080 Services__Cart=http://cart-service:8080
```

## 5. Deploy Public Ocelot API Gateway

```bash
az containerapp create --name api-gateway --resource-group $RG --environment $ENV --image $ACR_LOGIN_SERVER/shopez-api-gateway:latest --registry-server $ACR_LOGIN_SERVER --registry-username $ACR_USER --registry-password $ACR_PASS --target-port 8080 --ingress external --env-vars ASPNETCORE_URLS=http://+:8080
```

Get the gateway URL:

```bash
az containerapp show --name api-gateway --resource-group $RG --query properties.configuration.ingress.fqdn --output tsv
```

## 6. Verify Deployment

```bash
curl https://<gateway-fqdn>/health
curl https://<gateway-fqdn>/api/products
```

For frontend deployment, update the Angular API base/proxy to use:

```text
https://<gateway-fqdn>/api
```

Then build and deploy the Angular app to Azure Static Web Apps, Azure App Service, or any static hosting service.

## 7. Cleanup

```bash
az group delete --name $RG --yes --no-wait
```
