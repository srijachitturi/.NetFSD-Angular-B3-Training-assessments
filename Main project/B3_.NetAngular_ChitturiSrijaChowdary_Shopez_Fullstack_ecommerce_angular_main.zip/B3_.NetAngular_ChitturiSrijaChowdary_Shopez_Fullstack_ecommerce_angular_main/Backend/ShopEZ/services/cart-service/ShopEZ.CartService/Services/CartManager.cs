using ShopEZ.CartService.DTOs;
using ShopEZ.CartService.Models;
using ShopEZ.CartService.Repositories;

namespace ShopEZ.CartService.Services;

public sealed class CartManager(ICartRepository repository) : ICartService
{
    public async Task<IReadOnlyList<CartItemDto>> GetAsync(int userId) =>
        Map(await repository.GetByUserAsync(userId));

    public async Task<IReadOnlyList<CartItemDto>> AddAsync(AddCartItemDto dto)
    {
        var existing = (await repository.GetByUserAsync(dto.UserId)).FirstOrDefault(i => i.ProductId == dto.ProductId);
        var quantity = (existing?.Quantity ?? 0) + dto.Quantity;

        await repository.UpsertAsync(new CartItem
        {
            UserId = dto.UserId,
            ProductId = dto.ProductId,
            ProductName = dto.ProductName.Trim(),
            Quantity = quantity,
            Price = dto.Price
        });

        return await GetAsync(dto.UserId);
    }

    public async Task<IReadOnlyList<CartItemDto>> UpdateQuantityAsync(int userId, int productId, int quantity)
    {
        if (quantity == 0)
        {
            return await RemoveAsync(userId, productId);
        }

        var existing = (await repository.GetByUserAsync(userId)).FirstOrDefault(i => i.ProductId == productId)
            ?? throw new InvalidOperationException("Cart item was not found.");

        existing.Quantity = quantity;
        await repository.UpsertAsync(existing);
        return await GetAsync(userId);
    }

    public async Task<IReadOnlyList<CartItemDto>> RemoveAsync(int userId, int productId)
    {
        await repository.RemoveAsync(userId, productId);
        return await GetAsync(userId);
    }

    private static IReadOnlyList<CartItemDto> Map(IReadOnlyList<CartItem> items) =>
        items.Select(i => new CartItemDto(i.ProductId, i.ProductName, i.Quantity, i.Price)).ToList();
}
