using Microsoft.AspNetCore.Mvc;
using ShopEZ.CartService.DTOs;
using ShopEZ.CartService.Services;

namespace ShopEZ.CartService.Controllers;

[ApiController]
[Route("api/cart")]
public sealed class CartController(ICartService cartService) : ControllerBase
{
    [HttpGet("{userId:int}")]
    public async Task<IActionResult> Get(int userId) => Ok(await cartService.GetAsync(userId));

    [HttpPost]
    public async Task<IActionResult> AddRoot(AddCartItemDto dto) => await Add(dto);

    [HttpPost("items")]
    public async Task<IActionResult> Add(AddCartItemDto dto)
    {
        if (!ModelState.IsValid)
        {
            return ValidationProblem(ModelState);
        }

        return Ok(await cartService.AddAsync(dto));
    }

    [HttpPut("{userId:int}/items/{productId:int}")]
    public async Task<IActionResult> Update(int userId, int productId, UpdateCartItemDto dto)
    {
        try
        {
            return Ok(await cartService.UpdateQuantityAsync(userId, productId, dto.Quantity));
        }
        catch (InvalidOperationException ex)
        {
            return NotFound(new { message = ex.Message });
        }
    }

    [HttpDelete("{userId:int}/items/{productId:int}")]
    public async Task<IActionResult> Remove(int userId, int productId) =>
        Ok(await cartService.RemoveAsync(userId, productId));
}
