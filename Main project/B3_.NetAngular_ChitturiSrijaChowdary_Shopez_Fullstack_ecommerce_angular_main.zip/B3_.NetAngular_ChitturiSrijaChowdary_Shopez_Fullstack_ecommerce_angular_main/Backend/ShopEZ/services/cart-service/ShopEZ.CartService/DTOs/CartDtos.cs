using System.ComponentModel.DataAnnotations;

namespace ShopEZ.CartService.DTOs;

public sealed class AddCartItemDto
{
    [Range(1, int.MaxValue)]
    public int UserId { get; set; }

    [Range(1, int.MaxValue)]
    public int ProductId { get; set; }

    [Required, StringLength(150)]
    public string ProductName { get; set; } = string.Empty;

    [Range(1, 100)]
    public int Quantity { get; set; } = 1;

    [Range(0.01, 999999.99)]
    public decimal Price { get; set; }
}

public sealed class UpdateCartItemDto
{
    [Range(0, 100)]
    public int Quantity { get; set; }
}

public sealed record CartItemDto(int ProductId, string ProductName, int Quantity, decimal Price);
