using System.Collections.Concurrent;
using ShopEZ.CartService.Models;

namespace ShopEZ.CartService.Repositories;

public sealed class InMemoryCartRepository : ICartRepository
{
    private readonly ConcurrentDictionary<(int UserId, int ProductId), CartItem> _items = new();

    public Task<IReadOnlyList<CartItem>> GetByUserAsync(int userId) =>
        Task.FromResult<IReadOnlyList<CartItem>>(_items.Values.Where(i => i.UserId == userId).ToList());

    public Task UpsertAsync(CartItem item)
    {
        _items[(item.UserId, item.ProductId)] = item;
        return Task.CompletedTask;
    }

    public Task RemoveAsync(int userId, int productId)
    {
        _items.TryRemove((userId, productId), out _);
        return Task.CompletedTask;
    }
}
