using ShopEZ.CartService.DTOs;

namespace ShopEZ.CartService.Services;

public interface ICartService
{
    Task<IReadOnlyList<CartItemDto>> GetAsync(int userId);
    Task<IReadOnlyList<CartItemDto>> AddAsync(AddCartItemDto dto);
    Task<IReadOnlyList<CartItemDto>> UpdateQuantityAsync(int userId, int productId, int quantity);
    Task<IReadOnlyList<CartItemDto>> RemoveAsync(int userId, int productId);
}
