using ShopEZ.CartService.Models;

namespace ShopEZ.CartService.Repositories;

public interface ICartRepository
{
    Task<IReadOnlyList<CartItem>> GetByUserAsync(int userId);
    Task UpsertAsync(CartItem item);
    Task RemoveAsync(int userId, int productId);
}
