using Moq;
using ShopEZ.CartService.DTOs;
using ShopEZ.CartService.Models;
using ShopEZ.CartService.Repositories;
using ShopEZ.CartService.Services;

namespace ShopEZ.CartService.Tests;

public sealed class CartManagerTests
{
    [Fact]
    public async Task AddAsync_ExistingItem_IncreasesQuantity()
    {
        var repository = new Mock<ICartRepository>();
        repository.Setup(r => r.GetByUserAsync(1))
            .ReturnsAsync([new CartItem { UserId = 1, ProductId = 5, ProductName = "Phone", Quantity = 1, Price = 100 }]);

        var service = new CartManager(repository.Object);
        await service.AddAsync(new AddCartItemDto { UserId = 1, ProductId = 5, ProductName = "Phone", Quantity = 2, Price = 100 });

        repository.Verify(r => r.UpsertAsync(It.Is<CartItem>(i => i.Quantity == 3)), Times.Once);
    }

    [Fact]
    public async Task UpdateQuantityAsync_Zero_RemovesItem()
    {
        var repository = new Mock<ICartRepository>();
        repository.Setup(r => r.GetByUserAsync(1)).ReturnsAsync([]);

        var service = new CartManager(repository.Object);
        await service.UpdateQuantityAsync(1, 5, 0);

        repository.Verify(r => r.RemoveAsync(1, 5), Times.Once);
    }
}
