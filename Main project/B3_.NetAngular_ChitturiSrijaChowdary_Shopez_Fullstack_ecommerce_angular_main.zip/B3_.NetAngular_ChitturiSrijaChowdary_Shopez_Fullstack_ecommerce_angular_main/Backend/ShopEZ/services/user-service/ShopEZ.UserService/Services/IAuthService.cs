using ShopEZ.UserService.DTOs;

namespace ShopEZ.UserService.Services;

public interface IAuthService
{
    Task<AuthResponse> RegisterAsync(RegisterDto dto);
    Task<AuthResponse?> LoginAsync(LoginDto dto);
}
