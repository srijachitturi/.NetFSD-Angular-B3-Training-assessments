using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using ShopEZ.UserService.Models;

namespace ShopEZ.UserService.Security;

public sealed class JwtTokenService(IConfiguration configuration)
{
    public string CreateToken(User user)
    {
        var now = DateTimeOffset.UtcNow;
        var header = new Dictionary<string, object>
        {
            ["alg"] = "HS256",
            ["typ"] = "JWT"
        };
        var payload = new Dictionary<string, object>
        {
            ["sub"] = user.UserId.ToString(),
            [ClaimTypes.Name] = user.Name,
            [ClaimTypes.Email] = user.Email,
            [ClaimTypes.Role] = user.Role,
            ["role"] = user.Role,
            ["iss"] = Issuer,
            ["aud"] = Audience,
            ["iat"] = now.ToUnixTimeSeconds(),
            ["exp"] = now.AddHours(8).ToUnixTimeSeconds()
        };

        var unsigned = $"{Base64Url(JsonSerializer.SerializeToUtf8Bytes(header))}.{Base64Url(JsonSerializer.SerializeToUtf8Bytes(payload))}";
        return $"{unsigned}.{Sign(unsigned)}";
    }

    private string Issuer => configuration["Jwt:Issuer"] ?? "ShopEZ";
    private string Audience => configuration["Jwt:Audience"] ?? "ShopEZ.Client";
    private string Secret => configuration["Jwt:Secret"] ?? "ShopEZ-development-secret-key-change-me";

    private string Sign(string value)
    {
        using var hmac = new HMACSHA256(Encoding.UTF8.GetBytes(Secret));
        return Base64Url(hmac.ComputeHash(Encoding.UTF8.GetBytes(value)));
    }

    private static string Base64Url(byte[] bytes) =>
        Convert.ToBase64String(bytes).TrimEnd('=').Replace('+', '-').Replace('/', '_');
}
