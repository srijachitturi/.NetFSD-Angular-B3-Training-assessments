using ShopEZ.UserService.DTOs;
using ShopEZ.UserService.Models;
using ShopEZ.UserService.Repositories;
using ShopEZ.UserService.Security;

namespace ShopEZ.UserService.Services;

public sealed class AuthService(IUserRepository users, JwtTokenService jwtTokens, ILogger<AuthService> logger) : IAuthService
{
    public async Task<AuthResponse> RegisterAsync(RegisterDto dto)
    {
        var email = dto.Email.Trim().ToLowerInvariant();
        if (await users.FindByEmailAsync(email) is not null)
        {
            throw new InvalidOperationException("An account with this email already exists.");
        }

        var user = await users.CreateAsync(new User
        {
            Name = dto.Name.Trim(),
            Email = email,
            Password = dto.Password,
            Role = "Customer"
        });

        logger.LogInformation("Registered user {UserId} with role {Role}", user.UserId, user.Role);
        return CreateResponse(user);
    }

    public async Task<AuthResponse?> LoginAsync(LoginDto dto)
    {
        var user = await users.FindByEmailAsync(dto.Email.Trim().ToLowerInvariant());
        if (user is null || user.Password != dto.Password)
        {
            logger.LogWarning("Failed login attempt for {Email}", dto.Email);
            return null;
        }

        logger.LogInformation("User {UserId} logged in", user.UserId);
        return CreateResponse(user);
    }

    private AuthResponse CreateResponse(User user) =>
        new(user.UserId, user.Name, user.Role, jwtTokens.CreateToken(user));
}
