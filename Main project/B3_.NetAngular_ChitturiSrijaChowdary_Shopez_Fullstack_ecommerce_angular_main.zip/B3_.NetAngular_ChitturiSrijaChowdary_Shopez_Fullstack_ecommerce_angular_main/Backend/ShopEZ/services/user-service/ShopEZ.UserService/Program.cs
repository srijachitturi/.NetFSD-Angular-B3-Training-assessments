using ShopEZ.UserService.Repositories;
using ShopEZ.UserService.Security;
using ShopEZ.UserService.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddCors(options => options.AddPolicy("Angular", policy =>
    policy.AllowAnyHeader().AllowAnyMethod().WithOrigins(
        builder.Configuration["Cors:AngularOrigin"] ?? "http://localhost:4200")));
builder.Services.AddSingleton<IUserRepository, InMemoryUserRepository>();
builder.Services.AddSingleton<JwtTokenService>();
builder.Services.AddScoped<IAuthService, AuthService>();

var app = builder.Build();

app.UseExceptionHandler(errorApp => errorApp.Run(async context =>
{
    context.Response.StatusCode = StatusCodes.Status500InternalServerError;
    await context.Response.WriteAsJsonAsync(new { message = "An unexpected user service error occurred." });
}));
app.UseStatusCodePages(async context =>
{
    if (context.HttpContext.Response.StatusCode == StatusCodes.Status404NotFound)
    {
        await context.HttpContext.Response.WriteAsJsonAsync(new { message = "User endpoint was not found." });
    }
});

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseCors("Angular");
app.MapGet("/health", () => Results.Ok(new { service = "user-service", status = "healthy" }));
app.MapControllers();

app.Run();

public partial class Program { }
