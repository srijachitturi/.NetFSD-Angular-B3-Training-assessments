using System.Collections.Concurrent;
using ShopEZ.UserService.Models;

namespace ShopEZ.UserService.Repositories;

public sealed class InMemoryUserRepository : IUserRepository
{
    private readonly ConcurrentDictionary<string, User> _users = new(StringComparer.OrdinalIgnoreCase);
    private int _nextId = 2;

    public InMemoryUserRepository()
    {
        _users["admin@gmail.com"] = new User
        {
            UserId = 1,
            Name = "Admin",
            Email = "admin@gmail.com",
            Password = "Admin@123",
            Role = "Admin"
        };
    }

    public Task<User?> FindByEmailAsync(string email)
    {
        _users.TryGetValue(email.Trim().ToLowerInvariant(), out var user);
        return Task.FromResult(user);
    }

    public Task<User> CreateAsync(User user)
    {
        user.UserId = Interlocked.Increment(ref _nextId);
        _users[user.Email] = user;
        return Task.FromResult(user);
    }
}
