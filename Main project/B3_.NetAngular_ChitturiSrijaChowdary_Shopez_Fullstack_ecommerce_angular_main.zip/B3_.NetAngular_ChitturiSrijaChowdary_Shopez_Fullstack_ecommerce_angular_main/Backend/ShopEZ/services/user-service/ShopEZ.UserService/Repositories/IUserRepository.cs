using ShopEZ.UserService.Models;

namespace ShopEZ.UserService.Repositories;

public interface IUserRepository
{
    Task<User?> FindByEmailAsync(string email);
    Task<User> CreateAsync(User user);
}
