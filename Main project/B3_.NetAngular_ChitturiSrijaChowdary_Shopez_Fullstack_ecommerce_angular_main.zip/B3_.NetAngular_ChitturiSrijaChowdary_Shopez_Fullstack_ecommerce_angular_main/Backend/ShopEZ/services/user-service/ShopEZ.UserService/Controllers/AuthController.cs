using Microsoft.AspNetCore.Mvc;
using ShopEZ.UserService.DTOs;
using ShopEZ.UserService.Services;

namespace ShopEZ.UserService.Controllers;

[ApiController]
[Route("api/auth")]
public sealed class AuthController(IAuthService authService) : ControllerBase
{
    [HttpPost("register")]
    public async Task<IActionResult> Register(RegisterDto dto)
    {
        if (!ModelState.IsValid)
        {
            return ValidationProblem(ModelState);
        }

        try
        {
            return Ok(await authService.RegisterAsync(dto));
        }
        catch (InvalidOperationException ex)
        {
            return Conflict(new { message = ex.Message });
        }
    }

    [HttpPost("login")]
    public async Task<IActionResult> Login(LoginDto dto)
    {
        if (!ModelState.IsValid)
        {
            return ValidationProblem(ModelState);
        }

        var response = await authService.LoginAsync(dto);
        return response is null ? Unauthorized(new { message = "Invalid email or password." }) : Ok(response);
    }
}
