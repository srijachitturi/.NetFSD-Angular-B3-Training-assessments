using Moq;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging.Abstractions;
using ShopEZ.UserService.DTOs;
using ShopEZ.UserService.Models;
using ShopEZ.UserService.Repositories;
using ShopEZ.UserService.Security;
using ShopEZ.UserService.Services;

namespace ShopEZ.UserService.Tests;

public sealed class AuthServiceTests
{
    [Fact]
    public async Task RegisterAsync_DuplicateEmail_Throws()
    {
        var users = new Mock<IUserRepository>();
        users.Setup(r => r.FindByEmailAsync("test@example.com"))
            .ReturnsAsync(new User { Email = "test@example.com" });

        var service = CreateService(users.Object);

        await Assert.ThrowsAsync<InvalidOperationException>(() =>
            service.RegisterAsync(new RegisterDto { Name = "Test", Email = "test@example.com", Password = "Pass@123" }));
    }

    [Fact]
    public async Task LoginAsync_InvalidPassword_ReturnsNull()
    {
        var users = new Mock<IUserRepository>();
        users.Setup(r => r.FindByEmailAsync("test@example.com"))
            .ReturnsAsync(new User { Email = "test@example.com", Password = "Pass@123" });

        var service = CreateService(users.Object);
        var result = await service.LoginAsync(new LoginDto { Email = "test@example.com", Password = "bad" });

        Assert.Null(result);
    }

    private static AuthService CreateService(IUserRepository users)
    {
        var configuration = new ConfigurationBuilder()
            .AddInMemoryCollection(new Dictionary<string, string?>
            {
                ["Jwt:Secret"] = "ShopEZ-development-secret-key-change-me"
            })
            .Build();

        return new AuthService(users, new JwtTokenService(configuration), NullLogger<AuthService>.Instance);
    }
}
