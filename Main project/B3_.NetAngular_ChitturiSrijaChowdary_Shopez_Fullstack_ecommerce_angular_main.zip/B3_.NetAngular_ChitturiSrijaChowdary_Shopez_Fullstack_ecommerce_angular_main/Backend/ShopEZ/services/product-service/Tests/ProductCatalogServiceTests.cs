using Moq;
using ShopEZ.ProductService.DTOs;
using ShopEZ.ProductService.Exceptions;
using ShopEZ.ProductService.Models;
using ShopEZ.ProductService.Repositories;
using ShopEZ.ProductService.Services;

namespace ShopEZ.ProductService.Tests;

public sealed class ProductCatalogServiceTests
{
    [Fact]
    public async Task SearchAsync_ReturnsFilteredRepositoryResults()
    {
        var repository = new Mock<IProductRepository>();
        repository.Setup(r => r.SearchAsync(It.Is<ProductSearchQuery>(q => q.Search == "phone")))
            .ReturnsAsync([new Product { ProductId = 1, Name = "Phone", Description = "5G", Price = 999, ImageUrl = "phone.jpg", Stock = 5 }]);

        var service = new ProductCatalogService(repository.Object);
        var results = await service.SearchAsync(new ProductSearchQuery { Search = "phone" });

        Assert.Single(results);
        Assert.Equal("Phone", results[0].Name);
    }

    [Fact]
    public async Task GetByIdAsync_MissingProduct_ThrowsNotFound()
    {
        var repository = new Mock<IProductRepository>();
        repository.Setup(r => r.GetByIdAsync(99)).ReturnsAsync((Product?)null);

        var service = new ProductCatalogService(repository.Object);

        await Assert.ThrowsAsync<NotFoundException>(() => service.GetByIdAsync(99));
    }
}
