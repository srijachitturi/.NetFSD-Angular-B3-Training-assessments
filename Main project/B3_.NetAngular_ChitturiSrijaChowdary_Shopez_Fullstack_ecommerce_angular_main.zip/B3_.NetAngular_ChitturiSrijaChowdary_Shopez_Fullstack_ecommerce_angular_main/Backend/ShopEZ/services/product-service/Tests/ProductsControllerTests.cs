using Microsoft.AspNetCore.Mvc;
using Moq;
using ShopEZ.ProductService.Controllers;
using ShopEZ.ProductService.DTOs;
using ShopEZ.ProductService.Exceptions;
using ShopEZ.ProductService.Services;

namespace ShopEZ.ProductService.Tests;

public sealed class ProductsControllerTests
{
    [Fact]
    public async Task GetById_Returns404_WhenProductIsMissing()
    {
        var service = new Mock<IProductCatalogService>();
        service.Setup(s => s.GetByIdAsync(10)).ThrowsAsync(new NotFoundException("missing"));

        var result = await new ProductsController(service.Object).GetById(10);

        Assert.IsType<NotFoundObjectResult>(result);
    }

    [Fact]
    public async Task Search_Returns200()
    {
        var service = new Mock<IProductCatalogService>();
        service.Setup(s => s.SearchAsync(It.IsAny<ProductSearchQuery>()))
            .ReturnsAsync([new ProductReadDto(1, "Phone", "Electronics", "5G", 999, "phone.jpg", 3)]);

        var result = await new ProductsController(service.Object).Search(new ProductSearchQuery());

        Assert.IsType<OkObjectResult>(result);
    }
}
