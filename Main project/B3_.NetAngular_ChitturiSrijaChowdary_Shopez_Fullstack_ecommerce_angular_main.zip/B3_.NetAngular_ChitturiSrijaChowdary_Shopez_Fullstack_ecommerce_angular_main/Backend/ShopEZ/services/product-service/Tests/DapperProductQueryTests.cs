using ShopEZ.ProductService.Repositories;

namespace ShopEZ.ProductService.Tests;

public sealed class DapperProductQueryTests
{
    [Fact]
    public void SearchProducts_IncludesFilteringAndPagination()
    {
        Assert.Contains("Name LIKE '%' + @Search + '%'", DapperProductQueries.SearchProducts);
        Assert.Contains("@MinPrice", DapperProductQueries.SearchProducts);
        Assert.Contains("OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY", DapperProductQueries.SearchProducts);
    }

    [Fact]
    public void CreateProduct_ReturnsInsertedIdentity()
    {
        Assert.Contains("OUTPUT INSERTED.ProductId", DapperProductQueries.CreateProduct);
    }

    [Fact]
    public void GetByCategory_FiltersOnCategoryAndSortsByName()
    {
        Assert.Contains("WHERE Category = @Category", DapperProductQueries.GetByCategory);
        Assert.Contains("ORDER BY Name ASC", DapperProductQueries.GetByCategory);
    }
}
