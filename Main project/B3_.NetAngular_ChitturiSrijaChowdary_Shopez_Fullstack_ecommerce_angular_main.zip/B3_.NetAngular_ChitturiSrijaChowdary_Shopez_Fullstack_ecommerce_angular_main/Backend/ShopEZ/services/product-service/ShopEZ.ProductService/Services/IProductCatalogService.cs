using ShopEZ.ProductService.DTOs;

namespace ShopEZ.ProductService.Services;

public interface IProductCatalogService
{
    Task<IReadOnlyList<ProductReadDto>> SearchAsync(ProductSearchQuery query);
    Task<ProductReadDto> GetByIdAsync(int id);
    Task<ProductReadDto> CreateAsync(ProductCreateDto dto);
    Task<ProductReadDto> UpdateAsync(int id, ProductCreateDto dto);
    Task DeleteAsync(int id);
}
