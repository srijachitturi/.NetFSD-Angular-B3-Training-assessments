using Microsoft.Data.SqlClient;

namespace ShopEZ.ProductService.Repositories;

public sealed class ProductDatabaseInitializer(
    IConfiguration configuration,
    ILogger<ProductDatabaseInitializer> logger) : IHostedService
{
    private const int MaxAttempts = 30;
    private static readonly TimeSpan RetryDelay = TimeSpan.FromSeconds(2);

    public async Task StartAsync(CancellationToken cancellationToken)
    {
        var connectionString = configuration.GetConnectionString("ProductDb")
            ?? configuration.GetConnectionString("DefaultConnection")
            ?? throw new InvalidOperationException("Product database connection string is missing.");

        var builder = new SqlConnectionStringBuilder(connectionString);
        var databaseName = builder.InitialCatalog;

        if (string.IsNullOrWhiteSpace(databaseName))
        {
            throw new InvalidOperationException("Product database name is missing from the connection string.");
        }

        await RunWithRetryAsync(() => EnsureDatabaseAsync(builder, databaseName, cancellationToken), cancellationToken);
        await RunWithRetryAsync(() => EnsureSchemaAsync(connectionString, cancellationToken), cancellationToken);
        await RunWithRetryAsync(() => SeedDataAsync(connectionString, cancellationToken), cancellationToken);
    }

    public Task StopAsync(CancellationToken cancellationToken) => Task.CompletedTask;

    private async Task RunWithRetryAsync(Func<Task> action, CancellationToken cancellationToken)
    {
        for (var attempt = 1; attempt <= MaxAttempts; attempt++)
        {
            try
            {
                await action();
                return;
            }
            catch (SqlException ex) when (attempt < MaxAttempts)
            {
                logger.LogWarning(ex, "Product database is not ready. Retrying attempt {Attempt}/{MaxAttempts}.", attempt, MaxAttempts);
                await Task.Delay(RetryDelay, cancellationToken);
            }
        }
    }

    private static async Task EnsureDatabaseAsync(SqlConnectionStringBuilder builder, string databaseName, CancellationToken cancellationToken)
    {
        builder.InitialCatalog = "master";

        await using var connection = new SqlConnection(builder.ConnectionString);
        await connection.OpenAsync(cancellationToken);

        await using var existsCommand = connection.CreateCommand();
        existsCommand.CommandText = "SELECT DB_ID(@DatabaseName);";
        existsCommand.Parameters.AddWithValue("@DatabaseName", databaseName);

        if (await existsCommand.ExecuteScalarAsync(cancellationToken) is not DBNull and not null)
        {
            return;
        }

        await using var createCommand = connection.CreateCommand();
        createCommand.CommandText = $"CREATE DATABASE {QuoteSqlIdentifier(databaseName)};";
        await createCommand.ExecuteNonQueryAsync(cancellationToken);
    }

    private static async Task EnsureSchemaAsync(string connectionString, CancellationToken cancellationToken)
    {
        await using var connection = new SqlConnection(connectionString);
        await connection.OpenAsync(cancellationToken);

        await using var command = connection.CreateCommand();
        command.CommandText = """
            IF OBJECT_ID('dbo.Products', 'U') IS NULL
            BEGIN
                CREATE TABLE dbo.Products
                (
                    ProductId INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
                    Name NVARCHAR(150) NOT NULL,
                    Category NVARCHAR(80) NOT NULL CONSTRAINT DF_Products_Category DEFAULT ('General'),
                    Description NVARCHAR(500) NOT NULL,
                    Price DECIMAL(18,2) NOT NULL,
                    ImageUrl NVARCHAR(500) NOT NULL,
                    Stock INT NOT NULL
                );
            END;

            IF COL_LENGTH('dbo.Products', 'Category') IS NULL
            BEGIN
                ALTER TABLE dbo.Products
                    ADD Category NVARCHAR(80) NOT NULL CONSTRAINT DF_Products_Category DEFAULT ('General');
            END;
            """;

        await command.ExecuteNonQueryAsync(cancellationToken);
    }

    private static string QuoteSqlIdentifier(string identifier) => $"[{identifier.Replace("]", "]]")}]";

    private static async Task SeedDataAsync(string connectionString, CancellationToken cancellationToken)
    {
        await using var connection = new SqlConnection(connectionString);
        await connection.OpenAsync(cancellationToken);

        // Remove any old placeholder-image rows so fresh data is always seeded
        await using var cleanCmd = connection.CreateCommand();
        cleanCmd.CommandText = "DELETE FROM dbo.Products WHERE ImageUrl LIKE '%placeholder%';";
        await cleanCmd.ExecuteNonQueryAsync(cancellationToken);

        await using var command = connection.CreateCommand();
        command.CommandText = """
            IF NOT EXISTS (SELECT 1 FROM dbo.Products)
            BEGIN
                DBCC CHECKIDENT ('dbo.Products', RESEED, 0);

                INSERT INTO dbo.Products (Name, Category, Description, Price, ImageUrl, Stock) VALUES
                ('Laptop',              'Electronics', 'High-performance gaming laptop with RTX 4060 GPU',           75000.00, 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&w=900&q=80', 20),
                ('Smartphone',          'Electronics', 'Latest Android smartphone with 5G connectivity',             30000.00, 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=900&q=80', 50),
                ('Wireless Headphones', 'Electronics', 'Noise-cancelling over-ear wireless headphones',               8000.00, 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=900&q=80', 35),
                ('Running Shoes',       'Footwear',    'Lightweight breathable running shoes for all terrains',       3500.00, 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=900&q=80', 60),
                ('Backpack',            'Accessories', 'Durable 30L travel backpack with padded laptop sleeve',      2500.00, 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=900&q=80', 45),
                ('Coffee Maker',        'Appliances',  'Programmable 12-cup drip coffee maker with timer',           4500.00, 'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=900&q=80', 25),
                ('Desk Chair',          'Furniture',   'Ergonomic mesh office chair with lumbar support',           12000.00, 'https://images.unsplash.com/photo-1580480055273-228ff5388ef8?auto=format&fit=crop&w=900&q=80', 15),
                ('Mechanical Keyboard', 'Electronics', 'TKL mechanical keyboard with RGB backlight',                  5500.00, 'https://images.unsplash.com/photo-1587829741301-dc798b83add3?auto=format&fit=crop&w=900&q=80', 30),
                ('Smart Watch',         'Electronics', 'Fitness smartwatch with heart rate monitor and GPS',          6000.00, 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=900&q=80', 40),
                ('Sunglasses',          'Accessories', 'UV400 polarised sunglasses with lightweight titanium frame',  1800.00, 'https://images.unsplash.com/photo-1572635196237-14b3f281503f?auto=format&fit=crop&w=900&q=80', 55),
                ('Denim Jacket',        'Clothing',    'Classic slim-fit denim jacket for men and women',             3200.00, 'https://images.unsplash.com/photo-1551537482-f2075a1d41f2?auto=format&fit=crop&w=900&q=80', 38),
                ('Wireless Mouse',      'Electronics', 'Ergonomic silent wireless mouse with 12-month battery life',  1500.00, 'https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?auto=format&fit=crop&w=900&q=80', 70),
                ('Yoga Mat',            'Sports',      'Non-slip 6mm thick eco-friendly yoga and exercise mat',       1200.00, 'https://images.unsplash.com/photo-1601925228008-b4af8161c1c1?auto=format&fit=crop&w=900&q=80', 50),
                ('Table Lamp',          'Furniture',   'Minimalist LED desk lamp with adjustable colour temperature', 2200.00, 'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=900&q=80', 30),
                ('Perfume',             'Beauty',      'Long-lasting eau de parfum with floral and woody notes',      3800.00, 'https://images.unsplash.com/photo-1541643600914-78b084683702?auto=format&fit=crop&w=900&q=80', 25),
                ('Bluetooth Speaker',   'Electronics', '360-degree waterproof portable Bluetooth speaker',             4200.00, 'https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?auto=format&fit=crop&w=900&q=80', 28),
                ('Water Bottle',        'Sports',      'Insulated stainless steel water bottle 1 litre',               850.00, 'https://images.unsplash.com/photo-1602143407151-7111542de6e8?auto=format&fit=crop&w=900&q=80', 90),
                ('Wristwatch',          'Accessories', 'Premium analogue wristwatch with sapphire crystal glass',     9500.00, 'https://images.unsplash.com/photo-1587836374828-4dbafa94cf0e?auto=format&fit=crop&w=900&q=80', 18),
                ('Gaming Console',      'Electronics', 'Next-gen gaming console with 4K HDR and fast SSD',          49999.00, 'https://images.unsplash.com/photo-1486401899868-0e435ed85128?auto=format&fit=crop&w=900&q=80', 12),
                ('Sneakers',            'Footwear',    'Stylish everyday sneakers with memory foam insole',           4500.00, 'https://images.unsplash.com/photo-1518894781321-630e638d0742?auto=format&fit=crop&w=900&q=80', 65),
                ('Leather Wallet',      'Accessories', 'Slim genuine leather bifold wallet with RFID blocking',       1200.00, 'https://images.unsplash.com/photo-1627123424574-724758594785?auto=format&fit=crop&w=900&q=80', 80),
                ('Air Purifier',        'Appliances',  'HEPA air purifier covers rooms up to 400 sq ft',             8500.00, 'https://images.unsplash.com/photo-1585771724684-38269d6639fd?auto=format&fit=crop&w=900&q=80', 20),
                ('Cycling Helmet',      'Sports',      'Lightweight aerodynamic cycling helmet with ventilation',     3000.00, 'https://images.unsplash.com/photo-1557803175-b9ab7a86e3f4?auto=format&fit=crop&w=900&q=80', 33),
                ('Graphic T-Shirt',     'Clothing',    'Premium cotton unisex graphic tee in various prints',          799.00, 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=900&q=80', 120),
                ('Scented Candle',      'Beauty',      'Hand-poured soy wax candle with calming lavender scent',      950.00, 'https://images.unsplash.com/photo-1602178506498-9d6df0f02b75?auto=format&fit=crop&w=900&q=80', 60);
            END;
            """;

        await command.ExecuteNonQueryAsync(cancellationToken);
    }
}
