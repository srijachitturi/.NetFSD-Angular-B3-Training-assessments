using ShopEZ.ProductService.DTOs;
using ShopEZ.ProductService.Exceptions;
using ShopEZ.ProductService.Models;
using ShopEZ.ProductService.Repositories;

namespace ShopEZ.ProductService.Services;

public sealed class ProductCatalogService(IProductRepository repository) : IProductCatalogService
{
    public async Task<IReadOnlyList<ProductReadDto>> SearchAsync(ProductSearchQuery query)
    {
        var products = await repository.SearchAsync(query);
        return products.Select(Map).ToList();
    }

    public async Task<ProductReadDto> GetByIdAsync(int id)
    {
        var product = await repository.GetByIdAsync(id);
        return product is null ? throw new NotFoundException($"Product {id} was not found.") : Map(product);
    }

    public async Task<ProductReadDto> CreateAsync(ProductCreateDto dto)
    {
        var product = await repository.CreateAsync(new Product
        {
            Name = dto.Name.Trim(),
            Category = dto.Category.Trim(),
            Description = dto.Description.Trim(),
            Price = dto.Price,
            ImageUrl = dto.ImageUrl.Trim(),
            Stock = dto.Stock
        });

        return Map(product);
    }

    public async Task<ProductReadDto> UpdateAsync(int id, ProductCreateDto dto)
    {
        var product = new Product
        {
            ProductId = id,
            Name = dto.Name.Trim(),
            Category = dto.Category.Trim(),
            Description = dto.Description.Trim(),
            Price = dto.Price,
            ImageUrl = dto.ImageUrl.Trim(),
            Stock = dto.Stock
        };

        return await repository.UpdateAsync(product)
            ? Map(product)
            : throw new NotFoundException($"Product {id} was not found.");
    }

    public async Task DeleteAsync(int id)
    {
        if (!await repository.DeleteAsync(id))
        {
            throw new NotFoundException($"Product {id} was not found.");
        }
    }

    private static ProductReadDto Map(Product product) =>
        new(product.ProductId, product.Name, product.Category, product.Description, product.Price, product.ImageUrl, product.Stock);
}
