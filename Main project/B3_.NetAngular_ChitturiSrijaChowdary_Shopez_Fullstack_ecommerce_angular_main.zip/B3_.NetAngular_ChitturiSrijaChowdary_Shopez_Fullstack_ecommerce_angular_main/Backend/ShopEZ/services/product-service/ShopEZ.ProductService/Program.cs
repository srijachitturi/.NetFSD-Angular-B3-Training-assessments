using ShopEZ.ProductService.Repositories;
using ShopEZ.ProductService.Security;
using ShopEZ.ProductService.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddCors(options => options.AddPolicy("Angular", policy =>
    policy.AllowAnyHeader().AllowAnyMethod().WithOrigins(
        builder.Configuration["Cors:AngularOrigin"] ?? "http://localhost:4200")));
builder.Services.AddSingleton<JwtTokenValidator>();
builder.Services.AddHostedService<ProductDatabaseInitializer>();
builder.Services.AddScoped<ISqlConnectionFactory, SqlConnectionFactory>();
builder.Services.AddScoped<IProductRepository, DapperProductRepository>();
builder.Services.AddScoped<IProductCatalogService, ProductCatalogService>();

var app = builder.Build();

app.UseExceptionHandler(errorApp => errorApp.Run(async context =>
{
    context.Response.StatusCode = StatusCodes.Status500InternalServerError;
    await context.Response.WriteAsJsonAsync(new { message = "An unexpected product service error occurred." });
}));
app.UseStatusCodePages(async context =>
{
    if (context.HttpContext.Response.StatusCode == StatusCodes.Status404NotFound)
    {
        await context.HttpContext.Response.WriteAsJsonAsync(new { message = "Product endpoint was not found." });
    }
});

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseCors("Angular");
app.Use(async (context, next) =>
{
    if ((HttpMethods.IsPost(context.Request.Method) ||
         HttpMethods.IsPut(context.Request.Method) ||
         HttpMethods.IsDelete(context.Request.Method)) &&
        context.Request.Path.StartsWithSegments("/api/products") &&
        !context.RequestServices.GetRequiredService<JwtTokenValidator>().IsInRole(context.Request.Headers.Authorization, "Admin"))
    {
        context.Response.StatusCode = StatusCodes.Status403Forbidden;
        await context.Response.WriteAsJsonAsync(new { message = "Admin role is required to manage products." });
        return;
    }

    await next();
});
app.MapGet("/health", () => Results.Ok(new { service = "product-service", status = "healthy" }));
app.MapControllers();

app.Run();

public partial class Program { }
