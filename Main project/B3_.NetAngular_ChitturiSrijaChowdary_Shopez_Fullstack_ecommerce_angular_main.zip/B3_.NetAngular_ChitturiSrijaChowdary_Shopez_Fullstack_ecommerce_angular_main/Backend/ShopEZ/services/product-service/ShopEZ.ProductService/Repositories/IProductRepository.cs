using ShopEZ.ProductService.DTOs;
using ShopEZ.ProductService.Models;

namespace ShopEZ.ProductService.Repositories;

public interface IProductRepository
{
    Task<IReadOnlyList<Product>> SearchAsync(ProductSearchQuery query);
    Task<Product?> GetByIdAsync(int id);
    Task<Product> CreateAsync(Product product);
    Task<bool> UpdateAsync(Product product);
    Task<bool> DeleteAsync(int id);
}
