namespace ShopEZ.ProductService.Repositories;

public static class DapperProductQueries
{
    public const string SearchProducts = """
        SELECT ProductId, Name, Category, Description, Price, ImageUrl, Stock
        FROM Products
        WHERE (@Search IS NULL OR Name LIKE '%' + @Search + '%' OR Description LIKE '%' + @Search + '%')
          AND (@Name IS NULL OR Name LIKE '%' + @Name + '%')
          AND (@Category IS NULL OR Category = @Category)
          AND (@MinPrice IS NULL OR Price >= @MinPrice)
          AND (@MaxPrice IS NULL OR Price <= @MaxPrice)
        ORDER BY ProductId DESC
        OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY;
        """;

    public const string GetProductById = "SELECT ProductId, Name, Category, Description, Price, ImageUrl, Stock FROM Products WHERE ProductId = @Id;";

    public const string CreateProduct = """
        INSERT INTO Products (Name, Category, Description, Price, ImageUrl, Stock)
        OUTPUT INSERTED.ProductId
        VALUES (@Name, @Category, @Description, @Price, @ImageUrl, @Stock);
        """;

    public const string UpdateProduct = """
        UPDATE Products
        SET Name = @Name,
            Category = @Category,
            Description = @Description,
            Price = @Price,
            ImageUrl = @ImageUrl,
            Stock = @Stock
        WHERE ProductId = @ProductId;
        """;

    public const string DeleteProduct = "DELETE FROM Products WHERE ProductId = @Id;";

    public const string GetByCategory = """
        SELECT ProductId, Name, Category, Description, Price, ImageUrl, Stock
        FROM Products
        WHERE Category = @Category
        ORDER BY Name ASC;
        """;
}
