using System.ComponentModel.DataAnnotations;

namespace ShopEZ.ProductService.DTOs;

public sealed record ProductReadDto(int ProductId, string Name, string Category, string Description, decimal Price, string ImageUrl, int Stock);

public sealed class ProductCreateDto
{
    [Required, StringLength(150)]
    public string Name { get; set; } = string.Empty;

    [Required, StringLength(80)]
    public string Category { get; set; } = "General";

    [Required, StringLength(500)]
    public string Description { get; set; } = string.Empty;

    [Range(0.01, 999999.99)]
    public decimal Price { get; set; }

    [Required, StringLength(500)]
    public string ImageUrl { get; set; } = string.Empty;

    [Range(0, int.MaxValue)]
    public int Stock { get; set; }
}

public sealed class ProductSearchQuery
{
    public string? Search { get; set; }
    public string? Name { get; set; }
    public string? Category { get; set; }
    public decimal? MinPrice { get; set; }
    public decimal? MaxPrice { get; set; }
    public int Page { get; set; } = 1;
    public int PageSize { get; set; } = 12;
}
