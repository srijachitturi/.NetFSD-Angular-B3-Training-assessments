using System.Data;
using Microsoft.Data.SqlClient;

namespace ShopEZ.ProductService.Repositories;

public interface ISqlConnectionFactory
{
    IDbConnection CreateConnection();
}

public sealed class SqlConnectionFactory(IConfiguration configuration) : ISqlConnectionFactory
{
    public IDbConnection CreateConnection()
    {
        var connectionString = configuration.GetConnectionString("ProductDb")
            ?? configuration.GetConnectionString("DefaultConnection")
            ?? throw new InvalidOperationException("Product database connection string is missing.");

        return new SqlConnection(connectionString);
    }
}
