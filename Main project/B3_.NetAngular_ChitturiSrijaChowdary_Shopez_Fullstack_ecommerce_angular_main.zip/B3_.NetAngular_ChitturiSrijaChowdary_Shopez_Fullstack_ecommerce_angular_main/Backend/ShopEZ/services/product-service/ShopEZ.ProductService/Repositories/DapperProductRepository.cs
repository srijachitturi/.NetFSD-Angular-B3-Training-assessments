using Dapper;
using ShopEZ.ProductService.DTOs;
using ShopEZ.ProductService.Models;

namespace ShopEZ.ProductService.Repositories;

public sealed class DapperProductRepository(ISqlConnectionFactory connectionFactory) : IProductRepository
{
    public async Task<IReadOnlyList<Product>> SearchAsync(ProductSearchQuery query)
    {
        using var connection = connectionFactory.CreateConnection();
        var products = await connection.QueryAsync<Product>(DapperProductQueries.SearchProducts, new
        {
            Search = string.IsNullOrWhiteSpace(query.Search) ? null : query.Search.Trim(),
            Name = string.IsNullOrWhiteSpace(query.Name) ? null : query.Name.Trim(),
            Category = string.IsNullOrWhiteSpace(query.Category) ? null : query.Category.Trim(),
            query.MinPrice,
            query.MaxPrice,
            Offset = (Math.Max(query.Page, 1) - 1) * Math.Clamp(query.PageSize, 1, 100),
            PageSize = Math.Clamp(query.PageSize, 1, 100)
        });

        return products.ToList();
    }

    public async Task<Product?> GetByIdAsync(int id)
    {
        using var connection = connectionFactory.CreateConnection();
        return await connection.QuerySingleOrDefaultAsync<Product>(DapperProductQueries.GetProductById, new { Id = id });
    }

    public async Task<Product> CreateAsync(Product product)
    {
        using var connection = connectionFactory.CreateConnection();
        product.ProductId = await connection.ExecuteScalarAsync<int>(DapperProductQueries.CreateProduct, product);
        return product;
    }

    public async Task<bool> UpdateAsync(Product product)
    {
        using var connection = connectionFactory.CreateConnection();
        return await connection.ExecuteAsync(DapperProductQueries.UpdateProduct, product) > 0;
    }

    public async Task<bool> DeleteAsync(int id)
    {
        using var connection = connectionFactory.CreateConnection();
        return await connection.ExecuteAsync(DapperProductQueries.DeleteProduct, new { Id = id }) > 0;
    }
}
