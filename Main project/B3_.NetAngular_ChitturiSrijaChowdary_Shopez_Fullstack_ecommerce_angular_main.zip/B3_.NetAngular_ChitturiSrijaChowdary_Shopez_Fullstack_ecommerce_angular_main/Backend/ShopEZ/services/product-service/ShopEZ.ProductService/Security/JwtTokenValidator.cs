using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace ShopEZ.ProductService.Security;

public sealed class JwtTokenValidator(IConfiguration configuration)
{
    public bool IsInRole(string? authorizationHeader, string role)
    {
        if (!TryReadPayload(authorizationHeader, out var payload))
        {
            return false;
        }

        return payload.TryGetProperty("role", out var roleValue) &&
               roleValue.GetString()?.Equals(role, StringComparison.OrdinalIgnoreCase) == true;
    }

    private bool TryReadPayload(string? authorizationHeader, out JsonElement payload)
    {
        payload = default;
        if (string.IsNullOrWhiteSpace(authorizationHeader) ||
            !authorizationHeader.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
        {
            return false;
        }

        var token = authorizationHeader["Bearer ".Length..].Trim();
        var parts = token.Split('.');
        if (parts.Length != 3)
        {
            return false;
        }

        var unsigned = $"{parts[0]}.{parts[1]}";
        if (!CryptographicOperations.FixedTimeEquals(
                Encoding.ASCII.GetBytes(Sign(unsigned)),
                Encoding.ASCII.GetBytes(parts[2])))
        {
            return false;
        }

        using var document = JsonDocument.Parse(Base64UrlDecode(parts[1]));
        if (!document.RootElement.TryGetProperty("exp", out var exp) ||
            exp.GetInt64() <= DateTimeOffset.UtcNow.ToUnixTimeSeconds())
        {
            return false;
        }

        payload = document.RootElement.Clone();
        return true;
    }

    private string Sign(string value)
    {
        var secret = configuration["Jwt:Secret"] ?? "ShopEZ-development-secret-key-change-me";
        using var hmac = new HMACSHA256(Encoding.UTF8.GetBytes(secret));
        return Base64Url(hmac.ComputeHash(Encoding.UTF8.GetBytes(value)));
    }

    private static byte[] Base64UrlDecode(string value)
    {
        var padded = value.Replace('-', '+').Replace('_', '/');
        padded = padded.PadRight(padded.Length + (4 - padded.Length % 4) % 4, '=');
        return Convert.FromBase64String(padded);
    }

    private static string Base64Url(byte[] bytes) =>
        Convert.ToBase64String(bytes).TrimEnd('=').Replace('+', '-').Replace('/', '_');
}
