IF DB_ID('ShopEZProductDb') IS NULL
BEGIN
    CREATE DATABASE ShopEZProductDb;
END
GO

USE ShopEZProductDb;
GO

IF OBJECT_ID('dbo.Products', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.Products
    (
        ProductId INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        Name NVARCHAR(150) NOT NULL,
        Category NVARCHAR(80) NOT NULL CONSTRAINT DF_Products_Category DEFAULT ('General'),
        Description NVARCHAR(500) NOT NULL,
        Price DECIMAL(18,2) NOT NULL,
        ImageUrl NVARCHAR(500) NOT NULL,
        Stock INT NOT NULL
    );
END
GO

IF COL_LENGTH('dbo.Products', 'Category') IS NULL
BEGIN
    ALTER TABLE dbo.Products
        ADD Category NVARCHAR(80) NOT NULL CONSTRAINT DF_Products_Category DEFAULT ('General');
END
GO

DELETE FROM dbo.Products WHERE ImageUrl LIKE '%placeholder%';

    IF NOT EXISTS (SELECT 1 FROM dbo.Products)
BEGIN
    INSERT INTO dbo.Products (Name, Category, Description, Price, ImageUrl, Stock) VALUES
    ('Laptop',              'Electronics',  'High-performance gaming laptop with RTX 4060',          75000.00, 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&w=900&q=80', 20),
    ('Smartphone',          'Electronics',  'Latest Android smartphone with 5G connectivity',         30000.00, 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=900&q=80', 50),
    ('Wireless Headphones', 'Electronics',  'Noise-cancelling over-ear wireless headphones',           8000.00, 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=900&q=80', 35),
    ('Running Shoes',       'Footwear',     'Lightweight breathable running shoes for all terrains',   3500.00, 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=900&q=80', 60),
    ('Backpack',            'Accessories',  'Durable 30L travel backpack with laptop sleeve',          2500.00, 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=900&q=80', 45),
    ('Coffee Maker',        'Appliances',   'Programmable 12-cup drip coffee maker',                   4500.00, 'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=900&q=80', 25),
    ('Desk Chair',          'Furniture',    'Ergonomic mesh office chair with lumbar support',         12000.00, 'https://images.unsplash.com/photo-1580480055273-228ff5388ef8?auto=format&fit=crop&w=900&q=80', 15),
    ('Mechanical Keyboard', 'Electronics',  'TKL mechanical keyboard with RGB backlight',               5500.00, 'https://images.unsplash.com/photo-1587829741301-dc798b83add3?auto=format&fit=crop&w=900&q=80', 30),
    ('Smart Watch',         'Electronics',  'Fitness smartwatch with heart rate and GPS tracking',      6000.00, 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=900&q=80', 40),
    ('Sunglasses',          'Accessories',  'UV400 polarised sunglasses with lightweight frame',        1800.00, 'https://images.unsplash.com/photo-1572635196237-14b3f281503f?auto=format&fit=crop&w=900&q=80', 55),
    ('Denim Jacket',        'Clothing',     'Classic slim-fit denim jacket for men and women',          3200.00, 'https://images.unsplash.com/photo-1551537482-f2075a1d41f2?auto=format&fit=crop&w=900&q=80', 38),
    ('Wireless Mouse',      'Electronics',  'Ergonomic silent wireless mouse with long battery life',   1500.00, 'https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?auto=format&fit=crop&w=900&q=80', 70),
    ('Yoga Mat',            'Sports',       'Non-slip 6mm thick eco-friendly yoga and exercise mat',    1200.00, 'https://images.unsplash.com/photo-1601925228008-b4af8161c1c1?auto=format&fit=crop&w=900&q=80', 50),
    ('Table Lamp',          'Furniture',    'Minimalist LED desk lamp with adjustable colour temperature', 2200.00, 'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=900&q=80', 30),
    ('Perfume',             'Beauty',       'Long-lasting eau de parfum with floral and woody notes',   3800.00, 'https://images.unsplash.com/photo-1541643600914-78b084683702?auto=format&fit=crop&w=900&q=80', 25),
    ('Bluetooth Speaker',   'Electronics',  '360-degree waterproof portable Bluetooth speaker',          4200.00, 'https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?auto=format&fit=crop&w=900&q=80', 28),
    ('Water Bottle',        'Sports',       'Insulated stainless steel water bottle – 1 litre',          850.00, 'https://images.unsplash.com/photo-1602143407151-7111542de6e8?auto=format&fit=crop&w=900&q=80', 90),
    ('Wristwatch',          'Accessories',  'Premium analogue wristwatch with sapphire glass',          9500.00, 'https://images.unsplash.com/photo-1587836374828-4dbafa94cf0e?auto=format&fit=crop&w=900&q=80', 18);
END
GO
