using Ocelot.DependencyInjection;
using Ocelot.Middleware;

var builder = WebApplication.CreateBuilder(args);

builder.Configuration.AddJsonFile("ocelot.json", optional: false, reloadOnChange: true);
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddOcelot(builder.Configuration);

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI();

// Health must be registered BEFORE UseOcelot — Ocelot is terminal middleware
app.MapGet("/health", () => Results.Ok(new { service = "api-gateway", status = "healthy" }));

await app.UseOcelot();

app.Run();

public partial class Program { }
