using Microsoft.Extensions.Logging.Abstractions;
using ShopEZ.PaymentService.DTOs;
using ShopEZ.PaymentService.Repositories;
using ShopEZ.PaymentService.Services;

namespace ShopEZ.PaymentService.Tests;

public sealed class PaymentProcessorTests
{
    [Fact]
    public async Task ProcessAsync_ValidPayment_ReturnsTransaction()
    {
        var service = new PaymentProcessor(new InMemoryPaymentRepository(), NullLogger<PaymentProcessor>.Instance);

        var result = await service.ProcessAsync(new ProcessPaymentDto
        {
            UserId = 1,
            OrderId = 10,
            Amount = 499,
            Method = "upi"
        });

        Assert.StartsWith("TXN-", result.TransactionId);
        Assert.Equal("Payment successful", result.Status);
    }

    [Fact]
    public async Task ProcessAsync_InvalidPayment_Throws()
    {
        var service = new PaymentProcessor(new InMemoryPaymentRepository(), NullLogger<PaymentProcessor>.Instance);

        await Assert.ThrowsAsync<InvalidOperationException>(() => service.ProcessAsync(new ProcessPaymentDto
        {
            UserId = 1,
            OrderId = 10,
            Amount = 0,
            Method = "card"
        }));
    }
}
