namespace ShopEZ.PaymentService.Models;

public sealed class PaymentTransaction
{
    public string TransactionId { get; set; } = string.Empty;
    public int UserId { get; set; }
    public int OrderId { get; set; }
    public decimal Amount { get; set; }
    public string Method { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;
}
