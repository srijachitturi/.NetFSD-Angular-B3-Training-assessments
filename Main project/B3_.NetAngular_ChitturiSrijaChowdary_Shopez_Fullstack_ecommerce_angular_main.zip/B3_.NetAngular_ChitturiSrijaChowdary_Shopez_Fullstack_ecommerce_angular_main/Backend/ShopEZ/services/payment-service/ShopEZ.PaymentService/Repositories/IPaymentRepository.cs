using ShopEZ.PaymentService.Models;

namespace ShopEZ.PaymentService.Repositories;

public interface IPaymentRepository
{
    Task<PaymentTransaction> AddAsync(PaymentTransaction transaction);
    Task<PaymentTransaction?> GetByTransactionIdAsync(string transactionId);
    Task<IReadOnlyList<PaymentTransaction>> GetByUserAsync(int userId);
}
