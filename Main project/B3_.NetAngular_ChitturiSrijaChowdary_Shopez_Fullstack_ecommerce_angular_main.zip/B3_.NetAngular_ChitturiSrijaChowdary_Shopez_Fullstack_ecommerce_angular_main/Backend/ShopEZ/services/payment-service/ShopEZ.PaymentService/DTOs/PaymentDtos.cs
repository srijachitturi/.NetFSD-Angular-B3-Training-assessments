using System.ComponentModel.DataAnnotations;

namespace ShopEZ.PaymentService.DTOs;

public sealed class ProcessPaymentDto
{
    [Range(1, int.MaxValue)]
    public int UserId { get; set; }

    [Range(0, int.MaxValue)]
    public int OrderId { get; set; }

    [Range(0.01, 999999.99)]
    public decimal Amount { get; set; }

    [Required, StringLength(30)]
    public string Method { get; set; } = string.Empty;
}

public sealed record PaymentReadDto(
    string TransactionId,
    int UserId,
    int OrderId,
    decimal Amount,
    string Method,
    string Status,
    DateTime CreatedAtUtc);
