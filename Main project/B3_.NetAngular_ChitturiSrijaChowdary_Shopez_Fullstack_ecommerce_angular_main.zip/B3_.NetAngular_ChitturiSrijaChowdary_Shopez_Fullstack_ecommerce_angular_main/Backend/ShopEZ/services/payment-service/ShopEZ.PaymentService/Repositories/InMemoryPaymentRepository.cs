using ShopEZ.PaymentService.Models;

namespace ShopEZ.PaymentService.Repositories;

public sealed class InMemoryPaymentRepository : IPaymentRepository
{
    private readonly List<PaymentTransaction> transactions = [];

    public Task<PaymentTransaction> AddAsync(PaymentTransaction transaction)
    {
        transactions.Add(transaction);
        return Task.FromResult(transaction);
    }

    public Task<PaymentTransaction?> GetByTransactionIdAsync(string transactionId) =>
        Task.FromResult(transactions.FirstOrDefault(t =>
            t.TransactionId.Equals(transactionId, StringComparison.OrdinalIgnoreCase)));

    public Task<IReadOnlyList<PaymentTransaction>> GetByUserAsync(int userId) =>
        Task.FromResult<IReadOnlyList<PaymentTransaction>>(transactions.Where(t => t.UserId == userId).ToList());
}
