using Microsoft.AspNetCore.Mvc;
using ShopEZ.PaymentService.DTOs;
using ShopEZ.PaymentService.Services;

namespace ShopEZ.PaymentService.Controllers;

[ApiController]
[Route("api/payment")]
public sealed class PaymentController(IPaymentProcessor payments) : ControllerBase
{
    [HttpPost]
    public async Task<IActionResult> Process(ProcessPaymentDto dto)
    {
        if (!ModelState.IsValid)
        {
            return ValidationProblem(ModelState);
        }

        try
        {
            return Ok(await payments.ProcessAsync(dto));
        }
        catch (InvalidOperationException ex)
        {
            return BadRequest(new { message = ex.Message });
        }
    }

    [HttpGet("status/{transactionId}")]
    public async Task<IActionResult> Status(string transactionId)
    {
        var payment = await payments.GetStatusAsync(transactionId);
        return payment is null ? NotFound(new { message = "Payment transaction was not found." }) : Ok(payment);
    }

    [HttpGet("history/{userId:int}")]
    public async Task<IActionResult> History(int userId) => Ok(await payments.GetHistoryAsync(userId));
}
