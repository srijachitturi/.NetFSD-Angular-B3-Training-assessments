using ShopEZ.PaymentService.DTOs;

namespace ShopEZ.PaymentService.Services;

public interface IPaymentProcessor
{
    Task<PaymentReadDto> ProcessAsync(ProcessPaymentDto dto);
    Task<PaymentReadDto?> GetStatusAsync(string transactionId);
    Task<IReadOnlyList<PaymentReadDto>> GetHistoryAsync(int userId);
}
