using ShopEZ.PaymentService.DTOs;
using ShopEZ.PaymentService.Models;
using ShopEZ.PaymentService.Repositories;

namespace ShopEZ.PaymentService.Services;

public sealed class PaymentProcessor(IPaymentRepository payments, ILogger<PaymentProcessor> logger) : IPaymentProcessor
{
    private static readonly HashSet<string> SupportedMethods = new(StringComparer.OrdinalIgnoreCase)
    {
        "card",
        "upi",
        "netbanking",
        "cod"
    };

    public async Task<PaymentReadDto> ProcessAsync(ProcessPaymentDto dto)
    {
        if (dto.Amount <= 0)
        {
            logger.LogWarning("Rejected payment for user {UserId}: invalid amount {Amount}", dto.UserId, dto.Amount);
            throw new InvalidOperationException("Payment amount must be greater than zero.");
        }

        if (!SupportedMethods.Contains(dto.Method))
        {
            logger.LogWarning("Rejected payment for user {UserId}: invalid method {Method}", dto.UserId, dto.Method);
            throw new InvalidOperationException("Unsupported payment method.");
        }

        var transaction = await payments.AddAsync(new PaymentTransaction
        {
            TransactionId = dto.Method.Equals("cod", StringComparison.OrdinalIgnoreCase)
                ? $"COD-{DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()}"
                : $"TXN-{DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()}",
            UserId = dto.UserId,
            OrderId = dto.OrderId,
            Amount = dto.Amount,
            Method = dto.Method.ToLowerInvariant(),
            Status = dto.Method.Equals("cod", StringComparison.OrdinalIgnoreCase) ? "Payable on delivery" : "Payment successful"
        });

        logger.LogInformation("Processed payment {TransactionId} for order {OrderId}", transaction.TransactionId, transaction.OrderId);
        return Map(transaction);
    }

    public async Task<PaymentReadDto?> GetStatusAsync(string transactionId)
    {
        var transaction = await payments.GetByTransactionIdAsync(transactionId);
        return transaction is null ? null : Map(transaction);
    }

    public async Task<IReadOnlyList<PaymentReadDto>> GetHistoryAsync(int userId)
    {
        var history = await payments.GetByUserAsync(userId);
        return history.Select(Map).ToList();
    }

    private static PaymentReadDto Map(PaymentTransaction transaction) =>
        new(
            transaction.TransactionId,
            transaction.UserId,
            transaction.OrderId,
            transaction.Amount,
            transaction.Method,
            transaction.Status,
            transaction.CreatedAtUtc);
}
