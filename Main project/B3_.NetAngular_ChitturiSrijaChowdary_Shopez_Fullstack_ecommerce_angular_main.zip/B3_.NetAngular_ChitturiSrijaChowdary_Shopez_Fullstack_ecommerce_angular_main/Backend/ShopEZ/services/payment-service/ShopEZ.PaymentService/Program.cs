using ShopEZ.PaymentService.Repositories;
using ShopEZ.PaymentService.Security;
using ShopEZ.PaymentService.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddCors(options => options.AddPolicy("Angular", policy =>
    policy.AllowAnyHeader().AllowAnyMethod().WithOrigins(
        builder.Configuration["Cors:AngularOrigin"] ?? "http://localhost:4200")));
builder.Services.AddSingleton<IPaymentRepository, InMemoryPaymentRepository>();
builder.Services.AddSingleton<JwtTokenValidator>();
builder.Services.AddScoped<IPaymentProcessor, PaymentProcessor>();

var app = builder.Build();

app.UseExceptionHandler(errorApp => errorApp.Run(async context =>
{
    context.Response.StatusCode = StatusCodes.Status500InternalServerError;
    await context.Response.WriteAsJsonAsync(new { message = "An unexpected payment service error occurred." });
}));
app.UseStatusCodePages(async context =>
{
    if (context.HttpContext.Response.StatusCode == StatusCodes.Status404NotFound)
    {
        await context.HttpContext.Response.WriteAsJsonAsync(new { message = "Payment endpoint was not found." });
    }
});

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseCors("Angular");
app.Use(async (context, next) =>
{
    if (HttpMethods.IsPost(context.Request.Method) &&
        context.Request.Path.StartsWithSegments("/api/payment") &&
        !context.RequestServices.GetRequiredService<JwtTokenValidator>().IsValid(context.Request.Headers.Authorization))
    {
        context.Response.StatusCode = StatusCodes.Status401Unauthorized;
        await context.Response.WriteAsJsonAsync(new { message = "A valid JWT bearer token is required." });
        return;
    }

    await next();
});

app.MapGet("/health", () => Results.Ok(new { service = "payment-service", status = "healthy" }));
app.MapControllers();

app.Run();

public partial class Program { }
