# ShopEZ Microservices

This folder contains the backend refactor for Mini Project 4.

## Services

- `api-gateway/ShopEZ.ApiGateway`: Ocelot gateway routing `/api/*` traffic.
- `user-service/ShopEZ.UserService`: registration and login.
- `product-service/ShopEZ.ProductService`: catalog, search, filtering, pagination, and product creation.
- `cart-service/ShopEZ.CartService`: cart item add, update, remove, and lookup.
- `order-service/ShopEZ.OrderService`: order creation and order history.

## Dapper

`product-service` uses Dapper in `Repositories/DapperProductRepository.cs` for read-heavy product listing, search, price filtering, pagination, and lookup queries.

## Testing

Run unit tests:

```bash
dotnet test product-service/Tests/ShopEZ.ProductService.Tests.csproj --collect:"XPlat Code Coverage"
dotnet test user-service/Tests/ShopEZ.UserService.Tests.csproj --collect:"XPlat Code Coverage"
dotnet test cart-service/Tests/ShopEZ.CartService.Tests.csproj --collect:"XPlat Code Coverage"
dotnet test order-service/Tests/ShopEZ.OrderService.Tests.csproj --collect:"XPlat Code Coverage"
```

The test projects use xUnit and Moq and cover service-layer rules plus controller status codes. `ShopEZ.Microservices.sln` and `ShopEZ.Microservices.slnx` are included for IDE navigation; the per-service commands above are the most reliable CLI entry points in this .NET 10 environment.

## Docker

Run the backend microservices locally:

```bash
docker compose -f docker-compose.microservices.yml up --build
```

Gateway URL:

```text
http://localhost:8080
```

Routes:

- `/api/auth/*` -> User Service
- `/api/products/*` -> Product Service
- `/api/cart/*` -> Cart Service
- `/api/orders/*` -> Order Service

## Azure Deployment Option

For a simple cloud deployment, publish each service container to Azure Container Registry and deploy them to Azure App Service for Containers. For an advanced setup, deploy the same images to AKS and expose only the API Gateway through an ingress controller.
