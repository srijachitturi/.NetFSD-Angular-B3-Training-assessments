using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using ShopEZ.Api.Data;
using ShopEZ.Api.DTOs;
using ShopEZ.Api.Models;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace ShopEZ.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        private readonly IConfiguration _configuration;

        public AuthController(ApplicationDbContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }

        [HttpPost("login")]
        public IActionResult Login([FromBody] LoginDto dto)
        {
            if (!ModelState.IsValid)
                return ValidationProblem(ModelState);

            var user = _context.Users.FirstOrDefault(u =>
                u.Email == dto.Email && u.Password == dto.Password);

            if (user == null)
                return Unauthorized(new { message = "Invalid email or password." });

            return Ok(CreateAuthResponse(user));
        }

        [Authorize(Roles = "Admin")]
        [HttpGet("users")]
        public IActionResult GetUsers()
        {
            var users = _context.Users
                .OrderBy(u => u.Role == "Admin" ? 0 : 1)
                .ThenBy(u => u.Name)
                .Select(u => new
                {
                    userId = u.UserId,
                    name = u.Name,
                    email = u.Email,
                    role = u.Role,
                    orderCount = u.Orders.Count
                })
                .ToList();

            return Ok(users);
        }

        [Authorize(Roles = "Admin")]
        [HttpPost("users/{id:int}/promote")]
        public IActionResult PromoteUser(int id)
        {
            var user = _context.Users.Find(id);
            if (user == null)
                return NotFound(new { message = "User not found." });

            user.Role = "Admin";
            _context.SaveChanges();

            return Ok(new
            {
                userId = user.UserId,
                name = user.Name,
                email = user.Email,
                role = user.Role
            });
        }

        [Authorize(Roles = "Admin")]
        [HttpPost("users/{id:int}/demote")]
        public IActionResult DemoteAdmin(int id)
        {
            if (!IsHigherAdmin())
                return Forbid();

            var currentUserId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (currentUserId == id.ToString())
                return BadRequest(new { message = "You cannot change your own admin role." });

            var user = _context.Users.Find(id);
            if (user == null)
                return NotFound(new { message = "User not found." });

            if (user.Role != "Admin")
                return BadRequest(new { message = "Only admins can be changed back to customers." });

            var adminCount = _context.Users.Count(u => u.Role == "Admin");
            if (adminCount <= 1)
                return BadRequest(new { message = "At least one admin account must remain." });

            user.Role = "Customer";
            _context.SaveChanges();

            return Ok(new
            {
                userId = user.UserId,
                name = user.Name,
                email = user.Email,
                role = user.Role
            });
        }

        [HttpPost("register")]
        public IActionResult Register([FromBody] RegisterDto dto)
        {
            if (!ModelState.IsValid)
                return ValidationProblem(ModelState);

            var normalizedEmail = dto.Email.Trim().ToLower();
            var exists = _context.Users.Any(u => u.Email.ToLower() == normalizedEmail);

            if (exists)
                return Conflict(new { message = "An account with this email already exists." });

            var user = new User
            {
                Name = dto.Name.Trim(),
                Email = normalizedEmail,
                Password = dto.Password,
                Role = "Customer"
            };

            _context.Users.Add(user);
            _context.SaveChanges();

            return Ok(CreateAuthResponse(user));
        }

        private object CreateAuthResponse(User user)
        {
            var claims = new[]
            {
                new Claim(ClaimTypes.NameIdentifier, user.UserId.ToString()),
                new Claim(ClaimTypes.Name, user.Name),
                new Claim(ClaimTypes.Email, user.Email),
                new Claim(ClaimTypes.Role, user.Role)
            };

            var key = new SymmetricSecurityKey(
                Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]!));

            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: _configuration["Jwt:Issuer"],
                audience: _configuration["Jwt:Audience"],
                claims: claims,
                expires: DateTime.UtcNow.AddHours(1),
                signingCredentials: creds);

            return new
            {
                userId = user.UserId,
                token = new JwtSecurityTokenHandler().WriteToken(token),
                user = user.Name,
                email = user.Email,
                role = user.Role
            };
        }

        private bool IsHigherAdmin()
        {
            return string.Equals(
                User.FindFirstValue(ClaimTypes.Email),
                "admin@gmail.com",
                StringComparison.OrdinalIgnoreCase);
        }
    }
}
