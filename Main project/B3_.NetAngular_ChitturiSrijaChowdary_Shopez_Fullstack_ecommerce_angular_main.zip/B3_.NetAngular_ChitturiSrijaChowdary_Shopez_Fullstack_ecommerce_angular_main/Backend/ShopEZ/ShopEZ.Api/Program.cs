using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using ShopEZ.Api.Data;
using ShopEZ.Api.Middleware;
using ShopEZ.Api.Models;
using ShopEZ.Api.Repositories;
using ShopEZ.Api.Repositories.Interfaces;
using ShopEZ.Api.Services;
using ShopEZ.Api.Services.Interfaces;
using System.Text;

namespace ShopEZ.Api
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            builder.Services.AddControllers();
            builder.Services.AddEndpointsApiExplorer();

            builder.Services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v1", new OpenApiInfo
                {
                    Title = "ShopEZ API",
                    Version = "v1"
                });

                options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
                {
                    Name = "Authorization",
                    Type = SecuritySchemeType.Http,
                    Scheme = "bearer",
                    BearerFormat = "JWT",
                    In = ParameterLocation.Header,
                    Description = "Enter: Bearer <your_token>"
                });

                options.AddSecurityRequirement(new OpenApiSecurityRequirement
                {
                    {
                        new OpenApiSecurityScheme
                        {
                            Reference = new OpenApiReference
                            {
                                Type = ReferenceType.SecurityScheme,
                                Id = "Bearer"
                            }
                        },
                        Array.Empty<string>()
                    }
                });
            });

            builder.Services.AddDbContext<ApplicationDbContext>(options =>
                options.UseSqlServer(
                    builder.Configuration.GetConnectionString("DefaultConnection"),
                    sqlOptions => sqlOptions.EnableRetryOnFailure(5, TimeSpan.FromSeconds(10), null)));

            builder.Services.AddScoped<IProductRepository, ProductRepository>();
            builder.Services.AddScoped<IOrderRepository, OrderRepository>();
            builder.Services.AddScoped<IProductService, ProductService>();
            builder.Services.AddScoped<IOrderService, OrderService>();

            var jwtKey = builder.Configuration["Jwt:Key"]
                         ?? throw new InvalidOperationException("JWT Key is missing in appsettings.json.");
            var jwtIssuer = builder.Configuration["Jwt:Issuer"]
                            ?? throw new InvalidOperationException("JWT Issuer is missing in appsettings.json.");
            var jwtAudience = builder.Configuration["Jwt:Audience"]
                              ?? throw new InvalidOperationException("JWT Audience is missing in appsettings.json.");

            var keyBytes = Encoding.UTF8.GetBytes(jwtKey);

            builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
                .AddJwtBearer(options =>
                {
                    options.RequireHttpsMetadata = false;
                    options.SaveToken = true;

                    options.TokenValidationParameters = new TokenValidationParameters
                    {
                        ValidateIssuer = true,
                        ValidIssuer = jwtIssuer,

                        ValidateAudience = true,
                        ValidAudience = jwtAudience,

                        ValidateLifetime = true,
                        ClockSkew = TimeSpan.Zero,

                        ValidateIssuerSigningKey = true,
                        IssuerSigningKey = new SymmetricSecurityKey(keyBytes)
                    };
                });

            builder.Services.AddAuthorization();

            var app = builder.Build();

            app.UseMiddleware<ExceptionHandlingMiddleware>();

            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            // Force CORS for the Angular development client.
            app.Use(async (context, next) =>
            {
                context.Response.Headers["Access-Control-Allow-Origin"] = "*";
                context.Response.Headers["Access-Control-Allow-Headers"] = "*";
                context.Response.Headers["Access-Control-Allow-Methods"] = "*";

                if (context.Request.Method == "OPTIONS")
                {
                    context.Response.StatusCode = 200;
                    return;
                }

                await next();
            });

            app.UseRouting();

            app.UseAuthentication();
            app.UseAuthorization();

            app.MapControllers();

            using (var scope = app.Services.CreateScope())
            {
                var dbContext = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
                dbContext.Database.EnsureCreated();
                EnsureProductCategoryColumn(dbContext);
                SeedUsers(dbContext);
                DeleteOldSeedProducts(dbContext);
            }

            app.Run();
        }

        private static void SeedUsers(ApplicationDbContext dbContext)
        {
            var oldSeedEmails = new[]
            {
                "ayesha.khan@gmail.com",
                "khusi@gmail.com",
                "durga.priya@gmail.com",
                "geetha.lakshmi@gmail.com",
                "isha.landge@gmail.com",
                "srija@gmail.com",
                "narasimha@gmail.com"
            };

            var oldSeedUsers = dbContext.Users
                .Where(user => oldSeedEmails.Contains(user.Email) && !user.Orders.Any())
                .ToList();

            dbContext.Users.RemoveRange(oldSeedUsers);

            var users = new[]
            {
                new User { Name = "Rahul Sharma", Email = "rahul.sharma@gmail.com", Password = "Pass@123", Role = "Customer" },
                new User { Name = "Nikhil Reddy", Email = "nikhil.reddy@gmail.com", Password = "Pass@123", Role = "Customer" },
                new User { Name = "Mounika Devi", Email = "mounika.devi@gmail.com", Password = "Pass@123", Role = "Customer" },
                new User { Name = "Vishnu Kumar", Email = "vishnu.kumar@gmail.com", Password = "Pass@123", Role = "Customer" },
                new User { Name = "Akhil Varma", Email = "akhil.varma@gmail.com", Password = "Pass@123", Role = "Customer" },
                new User { Name = "Kavya Sree", Email = "kavya.sree@gmail.com", Password = "Pass@123", Role = "Customer" },
                new User { Name = "Admin User", Email = "admin@gmail.com", Password = "Admin@123", Role = "Admin" },
                new User { Name = "Store Admin", Email = "manager@gmail.com", Password = "Admin@123", Role = "Admin" }
            };

            foreach (var seededUser in users)
            {
                var existingUser = dbContext.Users.FirstOrDefault(user => user.Email == seededUser.Email);
                if (existingUser == null)
                {
                    dbContext.Users.Add(seededUser);
                    continue;
                }

                existingUser.Name = seededUser.Name;
                existingUser.Password = seededUser.Password;
                existingUser.Role = seededUser.Role;
            }

            dbContext.SaveChanges();
        }

        private static void EnsureProductCategoryColumn(ApplicationDbContext dbContext)
        {
            dbContext.Database.ExecuteSqlRaw("""
                IF COL_LENGTH('dbo.Products', 'Category') IS NULL
                BEGIN
                    ALTER TABLE dbo.Products
                    ADD Category nvarchar(100) NOT NULL CONSTRAINT DF_Products_Category DEFAULT 'Electronics'
                END
                """);

            dbContext.Database.ExecuteSqlRaw("""
                IF COL_LENGTH('dbo.Products', 'IsDeleted') IS NULL
                BEGIN
                    ALTER TABLE dbo.Products
                    ADD IsDeleted bit NOT NULL CONSTRAINT DF_Products_IsDeleted DEFAULT 0
                END
                """);

            dbContext.Database.ExecuteSqlRaw("""
                UPDATE dbo.Products
                SET Category =
                    CASE
                        WHEN LOWER(Name + ' ' + Description) LIKE '%chocolate%'
                          OR LOWER(Name + ' ' + Description) LIKE '%food%'
                          OR LOWER(Name + ' ' + Description) LIKE '%snack%'
                          OR LOWER(Name + ' ' + Description) LIKE '%biscuit%'
                          OR LOWER(Name + ' ' + Description) LIKE '%cookie%'
                          OR LOWER(Name + ' ' + Description) LIKE '%cake%' THEN 'Food'
                        WHEN LOWER(Name + ' ' + Description) LIKE '%headphone%'
                          OR LOWER(Name + ' ' + Description) LIKE '%earbud%'
                          OR LOWER(Name + ' ' + Description) LIKE '%speaker%' THEN 'Audio'
                        WHEN LOWER(Name + ' ' + Description) LIKE '%watch%'
                          OR LOWER(Name + ' ' + Description) LIKE '%fitness band%' THEN 'Wearables'
                        WHEN LOWER(Name + ' ' + Description) LIKE '%charger%'
                          OR LOWER(Name + ' ' + Description) LIKE '%ssd%'
                          OR LOWER(Name + ' ' + Description) LIKE '%stand%'
                          OR LOWER(Name + ' ' + Description) LIKE '%cable%'
                          OR LOWER(Name + ' ' + Description) LIKE '%cover%'
                          OR LOWER(Name + ' ' + Description) LIKE '%case%' THEN 'Accessories'
                        WHEN LOWER(Name + ' ' + Description) LIKE '%camera%'
                          OR LOWER(Name + ' ' + Description) LIKE '%webcam%' THEN 'Camera'
                        WHEN LOWER(Name + ' ' + Description) LIKE '%tablet%'
                          OR LOWER(Name + ' ' + Description) LIKE '%ipad%' THEN 'Tablets'
                        WHEN LOWER(Name + ' ' + Description) LIKE '%gaming%'
                          OR LOWER(Name + ' ' + Description) LIKE '%console%' THEN 'Gaming'
                        ELSE Category
                    END
                WHERE Category = 'Electronics'
                """);
        }

        private static void DeleteOldSeedProducts(ApplicationDbContext dbContext)
        {
            var oldSeedProductNames = new[]
            {
                "Wireless Mouse",
                "Mechanical Keyboard",
                "Bluetooth Headphones",
                "USB-C Charger",
                "Laptop Stand",
                "Smart Watch",
                "Portable SSD",
                "Webcam HD"
            };

            var oldSeedProducts = dbContext.Products
                .Where(product => oldSeedProductNames.Contains(product.Name) && !product.OrderItems.Any())
                .ToList();

            dbContext.Products.RemoveRange(oldSeedProducts);
            dbContext.SaveChanges();
        }
    }
}
