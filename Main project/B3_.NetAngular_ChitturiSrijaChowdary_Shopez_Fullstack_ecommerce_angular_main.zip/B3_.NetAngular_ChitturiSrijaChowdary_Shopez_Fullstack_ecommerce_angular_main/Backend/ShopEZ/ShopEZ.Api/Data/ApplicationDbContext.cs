﻿using Microsoft.EntityFrameworkCore;
using ShopEZ.Api.Models;

namespace ShopEZ.Api.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<User> Users => Set<User>();
        public DbSet<Product> Products => Set<Product>();
        public DbSet<Order> Orders => Set<Order>();
        public DbSet<OrderItem> OrderItems => Set<OrderItem>();

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<User>()
                .HasMany(u => u.Orders)
                .WithOne(o => o.User)
                .HasForeignKey(o => o.UserId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Order>()
                .HasMany(o => o.OrderItems)
                .WithOne(oi => oi.Order)
                .HasForeignKey(oi => oi.OrderId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Product>()
                .HasMany(p => p.OrderItems)
                .WithOne(oi => oi.Product)
                .HasForeignKey(oi => oi.ProductId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<User>().HasData(
                new User
                {
                    UserId = 1,
                    Name = "Rahul Sharma",
                    Email = "rahul.sharma@gmail.com",
                    Password = "Pass@123",
                    Role = "Customer"
                },
                new User
                {
                    UserId = 2,
                    Name = "Nikhil Reddy",
                    Email = "nikhil.reddy@gmail.com",
                    Password = "Pass@123",
                    Role = "Customer"
                },
                new User
                {
                    UserId = 3,
                    Name = "Mounika Devi",
                    Email = "mounika.devi@gmail.com",
                    Password = "Pass@123",
                    Role = "Customer"
                },
                new User
                {
                    UserId = 4,
                    Name = "Vishnu Kumar",
                    Email = "vishnu.kumar@gmail.com",
                    Password = "Pass@123",
                    Role = "Customer"
                },
                new User
                {
                    UserId = 5,
                    Name = "Akhil Varma",
                    Email = "akhil.varma@gmail.com",
                    Password = "Pass@123",
                    Role = "Customer"
                },
                new User
                {
                    UserId = 6,
                    Name = "Kavya Sree",
                    Email = "kavya.sree@gmail.com",
                    Password = "Pass@123",
                    Role = "Customer"
                },
                new User
                {
                    UserId = 7,
                    Name = "Admin User",
                    Email = "admin@gmail.com",
                    Password = "Admin@123",
                    Role = "Admin"
                },
                new User
                {
                    UserId = 8,
                    Name = "Store Admin",
                    Email = "manager@gmail.com",
                    Password = "Admin@123",
                    Role = "Admin"
                }
            );

        }
    }
}
