# ShopEZ Full Stack E-Commerce Application

A microservices-based e-commerce platform built with ASP.NET Core (.NET 10) and Angular.

---

## Prerequisites

- [.NET 10 SDK](https://dotnet.microsoft.com/download)
- [Node.js 18+](https://nodejs.org/)
- [SQL Server Express](https://www.microsoft.com/en-us/sql-server/sql-server-downloads) (installed with **Mixed Mode Authentication**)
- [SQL Server Management Studio (SSMS)](https://learn.microsoft.com/sql/ssms/download-sql-server-management-studio-ssms)

---

## Step 1 — SQL Server Setup

1. Install **SQL Server Express** with **Mixed Mode Authentication**
2. Set the `sa` password to: `Admin@123`
3. Open `services.msc` and ensure **SQL Server (SQLEXPRESS)** and **SQL Server Browser** are **Running**
4. Open SSMS → connect to `localhost\SQLEXPRESS` using SQL Server Authentication (`sa` / `Admin@123`)
5. Run the provided script: `ShopEZ_Database_Setup.sql`

---

## Step 2 — Run the Backend (Main API)

```bash
cd Backend/ShopEZ/ShopEZ.Api
dotnet run --launch-profile http
```

The API starts at **http://localhost:5073**  
Swagger UI: **http://localhost:5073/swagger**

---

## Step 3 — Run the Microservices (optional, for full feature set)

Open separate terminals for each:

```bash
# Product Service — http://localhost:5211
cd Backend/ShopEZ/services/product-service/ShopEZ.ProductService
dotnet run --launch-profile http

# User Service — http://localhost:5016
cd Backend/ShopEZ/services/user-service/ShopEZ.UserService
dotnet run --launch-profile http

# Cart Service — http://localhost:5034
cd Backend/ShopEZ/services/cart-service/ShopEZ.CartService
dotnet run --launch-profile http

# Order Service — http://localhost:5166
cd Backend/ShopEZ/services/order-service/ShopEZ.OrderService
dotnet run --launch-profile http

# Payment Service — http://localhost:5166 (see launchSettings)
cd Backend/ShopEZ/services/payment-service/ShopEZ.PaymentService
dotnet run --launch-profile http
```

---

## Step 4 — Run the Frontend

```bash
cd Frontend
npm install
npm start
```

Angular app starts at **http://localhost:4200**  
The proxy (`proxy.conf.json`) forwards `/api/*` to the Main API at `http://localhost:5073`.

---

## Connection Strings (already configured)

All `appsettings.json` files are pre-configured with:

```
Server=localhost\SQLEXPRESS;User Id=sa;Password=Admin@123;TrustServerCertificate=True;
```

If your `sa` password differs, update it in each service's `appsettings.json`.

---

## Troubleshooting

| Error | Fix |
|---|---|
| `Login failed for user 'Guest'` | SQL Server using Windows Auth. Switch to Mixed Mode or use the `sa` connection string (already done). |
| `ECONNREFUSED /api/Products` | Main API is not running. Run `dotnet run` in `Backend/ShopEZ/ShopEZ.Api`. |
| `Cannot open database` | Run `ShopEZ_Database_Setup.sql` in SSMS first. |
| `SSL certificate error` | `TrustServerCertificate=True` is already set in all connection strings. |
