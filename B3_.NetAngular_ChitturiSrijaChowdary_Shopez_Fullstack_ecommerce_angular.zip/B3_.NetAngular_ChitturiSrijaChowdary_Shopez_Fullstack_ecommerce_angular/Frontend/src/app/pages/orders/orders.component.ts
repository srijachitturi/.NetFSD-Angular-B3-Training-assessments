import { Component } from '@angular/core';

@Component({
  selector: 'app-orders',
  standalone: true,
  template: '',
  styleUrl: './orders.component.css'
})
export class OrdersComponent {}
