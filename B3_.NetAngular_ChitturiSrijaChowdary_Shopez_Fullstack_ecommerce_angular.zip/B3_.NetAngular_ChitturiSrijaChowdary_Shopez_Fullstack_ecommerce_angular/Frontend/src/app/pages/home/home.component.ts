import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  standalone: true,
  template: '',
  styleUrl: './home.component.css'
})
export class HomeComponent {}
