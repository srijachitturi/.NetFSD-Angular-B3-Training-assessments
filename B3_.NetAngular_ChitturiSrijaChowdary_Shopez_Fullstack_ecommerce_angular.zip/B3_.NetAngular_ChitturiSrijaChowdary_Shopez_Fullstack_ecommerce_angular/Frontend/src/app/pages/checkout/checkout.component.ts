import { Component } from '@angular/core';

@Component({
  selector: 'app-checkout',
  standalone: true,
  template: '',
  styleUrl: './checkout.component.css'
})
export class CheckoutComponent {}
