import { Component } from '@angular/core';

@Component({
  selector: 'app-register',
  standalone: true,
  template: '',
  styleUrl: './register.component.css'
})
export class RegisterComponent {}
