import { Component } from '@angular/core';

@Component({
  selector: 'app-products',
  standalone: true,
  template: '',
  styleUrl: './products.component.css'
})
export class ProductsComponent {}
