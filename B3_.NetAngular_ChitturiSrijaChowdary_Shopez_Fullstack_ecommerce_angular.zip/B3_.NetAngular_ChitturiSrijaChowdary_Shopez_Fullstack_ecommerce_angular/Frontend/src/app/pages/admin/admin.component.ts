import { Component } from '@angular/core';

@Component({
  selector: 'app-admin',
  standalone: true,
  template: '',
  styleUrl: './admin.component.css'
})
export class AdminComponent {}
