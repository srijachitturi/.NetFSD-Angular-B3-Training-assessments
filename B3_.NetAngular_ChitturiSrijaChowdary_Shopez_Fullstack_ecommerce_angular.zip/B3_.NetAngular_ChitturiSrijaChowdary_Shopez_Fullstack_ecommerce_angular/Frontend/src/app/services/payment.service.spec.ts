import { TestBed } from '@angular/core/testing';
import { firstValueFrom } from 'rxjs';
import { PaymentDetails } from '../models/payment.model';
import { PaymentService } from './payment.service';

describe('PaymentService', () => {
  let service: PaymentService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PaymentService);
  });

  it('returns a successful receipt for card payments', async () => {
    const payment: PaymentDetails = {
      method: 'card',
      cardName: 'Srija',
      cardNumber: '4111111111111111',
      expiry: '12/30',
      cvv: '123',
      upiId: '',
      bank: 'State Bank of India'
    };

    const receipt = await firstValueFrom(service.processPayment(payment, 2499));

    expect(receipt.status).toBe('Payment successful');
    expect(receipt.method).toBe('Credit / Debit Card');
    expect(receipt.transactionId).toContain('TXN-');
    expect(receipt.amount).toBe(2499);
  });

  it('marks cash on delivery receipts as payable later', async () => {
    const payment: PaymentDetails = {
      method: 'cod',
      cardName: '',
      cardNumber: '',
      expiry: '',
      cvv: '',
      upiId: '',
      bank: ''
    };

    const receipt = await firstValueFrom(service.processPayment(payment, 799));

    expect(receipt.status).toBe('Payable on delivery');
    expect(receipt.transactionId).toContain('COD-');
  });
});
